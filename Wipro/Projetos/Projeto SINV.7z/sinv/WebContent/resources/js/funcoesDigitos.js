/**
 * File: funcoesDigitos.js
 * Fun��es de valida��o e gera��o de d�gitos verificadores.
 */

/*
   Function: setColorBad
   Altera a cor de fundo de algum componente Utilizado pelas outras fun��es.
   Par�metros:
      el - Componente a ser alterado.
   Retorno:
      nada.
*/
function setColorBad(el) {
    if (el.style) el.style.backgroundColor = "#ffaaaa";
}

/*
   Function: setColorGood
   Altera a cor de fundo de algum componente. Utilizado pelas outras fun��es.
   Par�metros:
      el - Componente a ser alterado.
   Retorno:
      nada.
*/
function setColorGood(el) {
    if (el.style) el.style.backgroundColor = "white";
}

/*
   Function: colocaZerosEsquerda
       Fun��o auxiliar que coloca zeros � esquerda do campo caso seja necess�rio (comprimento
       seja menor que o estipulado).
   Par�metros:
      valor - N�mero a ser preenchido.
      tamanho - Tamanho desejado.
   Retorno:
      n�mero formatado.
*/
function colocaZerosEsquerda(valor, tamanho) {
    while (valor.length < tamanho) {
        valor = "0" + valor;
    }
    return valor;
}

/*
   Function: calculaModulo11
   C�lculo do m�dulo 11. Esta fun��o � utilizada pelas outras fun��es deste arquivo.
   � uma fun��o de c�lculo gen�rico de m�dulo 11.
   Caso o m�dulo seja 11 retorna 0 (n�o P).
   Par�metros:
        valor - N�mero cujo m�dulo ser� calculado.
        pesoMaximo - Valor do maior peso.
        tamanho - Tamanho a ser considerado no c�lculo.
   Retorno:
        M�dulo calculado.
*/
function calculaModulo11(valor, pesoMaximo, tamanho) {
    var peso, soma, digito, dv;
    var lnum = "";
    peso = 2;
    soma = 0;

    lnum = String(valor);

    digito = tamanho;
    while (digito >= 1) {
        soma = soma + peso * lnum.substring(digito - 1, digito);
        if (peso >= pesoMaximo) {
            peso = 2;
        } else {
            peso = peso + 1;
        }
        digito = digito - 1;
    }

    dv = 11 - (soma % 11);
    if (dv > 9) {
        dv = 0;
    }
    return String(dv);
}

/*
   Function: calculaDigitoCNPJ
       C�lculo dos 2 d�gitos verificadores do CNPJ.
   Par�metros:
        valor - N�mero cujo d�gito verificador ser� calculado.
   Retorno:
        D�gito verificador calculado.
*/
function calculaDigitoCNPJ(valor) {

    dv1 = calculaModulo11(valor, 9, 13);
    dv2 = calculaModulo11(valor + dv1, 9, 14);
    return dv1 + dv2;
}

/*
   Function: calculaDigitoCPF
       C�lculo dos 2 d�gitos verificadores do CPF.
   Par�metros:
        valor - N�mero cujo d�gito verificador ser� calculado.
   Retorno:
        D�gito verificador calculado.
*/
function calculaDigitoCPF(valor) {

    dv1 = calculaModulo11(valor, 11, 9);
    dv2 = calculaModulo11(valor + dv1, 11, 10);
    return dv1 + dv2;
}

/*
   Function: calculaDAC0
        C�lculo do d�gito verificador de contas Bradesco (convertido para 0).
        O n�mero original n�o pode ter o d�gito concatenado.
   Par�metros:
        valor - N�mero cujo d�gito verificador ser� calculado.
   Retorno:
        D�gito verificador calculado.
*/
function calculaDAC0(valor) {

    return calculaModulo11(valor, 7, valor.length);
}

/*
   Function: validaCPF
       Valida os d�gitos verificadores do CPF.
   Par�metros:
        valor - N�mero cujo d�gito verificador ser� validado.
   Retorno:
        *true* caso o d�gito esteja correto.
*/
function validaCPF(valor) {
    if (calculaDigitoCPF(valor) == valor.substring(9, 11)) {
        setColorGood(valor);
        return true;
    } else {
        alert("CPF inv�lido");
        setColorBad(valor);
        return false;
    }
}

/*
   Function: validaCNPJ
       Valida os d�gitos verificadores do CNPJ.
   Par�metros:
        valor - N�mero cujo d�gito verificador ser� validado.
   Retorno:
        *true* caso o d�gito esteja correto.
*/
function validaCNPJ(valor) {
    if (calculaDigitoCNPJ(valor) == valor.substring(13, 15)) {
        setColorGood(valor);
        return true;
    } else {
        setColorBad(valor);
        alert("CNPJ inv�lido");
        return false;
    }
}

/*
   Function: validaDAC0
       Valida o d�gito de uma conta Bradesco.
   Par�metros:
        valor - N�mero cujo d�gito verificador ser� validado.
        digito - d�gito verificador.
   Retorno:
        *true* caso o d�gito esteja correto.
*/
function validaDAC0(valor, digito) {
    if (calculaDAC0(valor) == digito) {
        setColorGood(valor);
        return true;
    } else {
        setColorBad(valor);
        alert("D�gito incorreto");
        return false;
    }
}

/**
 * N�o permite que sejam digitados caracteres diferentes de 0123456789
 * Modo de Usar: onkeypress="return somenteNumero(event);"
 * @param campo
 * @param e
 * @return N�o permite que sejam digitados caracteres diferentes de 0123456789
 */
function somenteNumero(e) {

    var tecla = (window.event) ? e.keyCode : e.which;

    if (tecla > 47 && tecla < 58) {
        return true;
    } else {
        if ((tecla != 8 || tecla != 0 || tecla != 44)) {
            return false;
        } else {
            return true;
        }
    }
}

/**
 * Completa com zeros a esquerda um determinado n�mero
 * Modo de usar: onblur="completarComZeros(this,9);"
 * @param campo
 * @param tamanhoMaximo
 * @return Completa com zeros a esquerda um campo caso o tamanho do campo seja maior que zero
 */
function completarComZeros(campo, tamanhoMaximo) {
    var valorCampo = campo.value;

    if (valorCampo.length == 0) {
        return;
    }

    campo.value = completarZerosEsquerda(valorCampo, tamanhoMaximo);
}

/**
 * Completa com zeros a esquerda um determinado n�mero
 * Apenas uso interno - n�o utilizar diretamente na tela
 * @param valorInteiro
 * @param tamanhoMaximo
 * @return 
 */
function completarZerosEsquerda(valorInteiro, tamanhoMaximo) {

    var valorCampo = valorInteiro.value;
    if (valorCampo == "") {
        return;
    }
    while (valorCampo.length < tamanhoMaximo) {
        valorCampo = "0" + valorCampo;
    }
    valorInteiro.value = valorCampo;
}

/**
 * Formata valores com virgulas e pontos.
 * @param object - Objeto ao ser formatado.
 * @param digits - Quantidade de digitos apos a virgula.
 */
function formataValor(object, digits) {
    var valor = object.value;
    var caracteresValidos = "0123456789,.";
    // Formata caracteres validos.
    for (var i=0; i<valor.length; i++) {	
		if(caracteresValidos.indexOf(valor.charAt(i)) == -1) {
			return false;
		}
	}
    // Formata valor.
    while (valor.indexOf('.') != -1 || valor.indexOf(',') != -1) {
        valor = valor.replace('.', '');
        valor = valor.replace(',', '');
    }
    var cont = 0;
    var novoValor = "";
    while (valor.substr(0, 1) == 0 && valor.length > 0) {
        valor = valor.substring(1, valor.length);
    }
    while (valor.length < 3) {
        valor = "0" + valor;
    }
    for (i = valor.length - 1; i >= 0; i--) {
        if (cont == digits) {
            novoValor = "," + novoValor;
        }
        if ((cont - digits) % 3 == 0 && (cont - digits) > 0) {
            novoValor = "." + novoValor;
        }
        novoValor = valor.substr(i, 1) + novoValor;
        cont++;
    }
    object.value = novoValor;
    return true;
}