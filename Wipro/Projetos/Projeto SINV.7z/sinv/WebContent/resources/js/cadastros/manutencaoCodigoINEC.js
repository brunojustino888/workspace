function radioButton(radio) {
    var id = radio.name.substring(radio.name.lastIndexOf(':'));
    var el = radio.form.elements;
    for (var i = 0; i < el.length; i++) {
        if (el[i].name.substring(el[i].name.lastIndexOf(':')) == id) {
            el[i].checked = false;
        }
    }
    radio.checked = true;
}


function exibirModal(status,popup) {
	if(status) {
		Richfaces.showModalPanel(popup);		
		return false;
	}
	return true;
}

function validarConsulta() { 
	var ativo = document.getElementById("manutencaoCodigoForm:codigoAtivo").value;
	if(ativo == "0") { 	 		
		return confirm('O filtro Ativo n\u00e3o foi informado, a consulta pode afetar a perfomance da aplica\u00e7\u00e3o. Deseja continuar?');
	}
	return true;
}

function validarFormAlteracao() {
    var form = "manutencaoCodigoForm";
    var idTabela = "dataTable";
    // Limpar mensagens.
    removeMessages(form);
    if (!selectRadioButton(form, idTabela)) {
    	 addMessages('Favor selecionar o Ativo a ser alterado.', 'SEVERITY_ERROR');
         return false;
    }
    return true;
}