function copyValuePeriodoInicioToFim(form, idPeriodoInicio, idPeriodoFim) { 
	var periodoInicio = form + ":" + idPeriodoInicio;
	var periodoFim = form + ":" + idPeriodoFim;
	if(document.getElementById(periodoInicio + ".day").value.length == 2 
			&& document.getElementById(periodoInicio + ".month").value.length == 2 
			&& document.getElementById(periodoInicio + ".year").value.length == 4
			&& document.getElementById(periodoFim + ".day").value.length == 0
			&& document.getElementById(periodoFim + ".month").value.length == 0
			&& document.getElementById(periodoFim + ".year").value.length == 0) {
		document.getElementById(periodoInicio).value = document.getElementById(periodoInicio + ".day").value 
													+ "/" + document.getElementById(periodoInicio + ".month").value 
													+ "/" + document.getElementById(periodoInicio + ".year").value;
		document.getElementById(periodoFim).value = document.getElementById(periodoInicio).value;
		document.getElementById(periodoFim + ".day").value = document.getElementById(periodoInicio + ".day").value; 
		document.getElementById(periodoFim + ".month").value = document.getElementById(periodoInicio + ".month").value; 
		document.getElementById(periodoFim + ".year").value = document.getElementById(periodoInicio + ".year").value; 
	}
} 

function focusPeriodoFim(form, idPeriodoInicio, idPeriodoFim) {
	var periodoInicio = form + ":" + idPeriodoInicio;
	var periodoFim = form + ":" + idPeriodoFim;
	if(document.getElementById(periodoInicio + ".day").value.length == 2 
			&& document.getElementById(periodoInicio + ".month").value.length == 2 
			&& document.getElementById(periodoInicio + ".year").value.length == 4
			&& document.selection.createRange().text.length == 0) {		
		copyValuePeriodoInicioToFim(form, idPeriodoInicio, idPeriodoFim);
		document.getElementById(periodoFim + ".day").focus();
		document.getElementById(periodoFim + ".day").select();
	}
}