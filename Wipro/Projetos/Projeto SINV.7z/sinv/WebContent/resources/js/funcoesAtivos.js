function ativarTodosAtivos(form, tabela, obj) {
	var table = document.getElementById(form + ":" + tabela);
	var checkBoxs = table.getElementsByTagName("input");	
	for (var i = 0; i < checkBoxs.length; i++){ 
		checkBoxs[i].checked = obj.checked;
	}
}

function selectCheckBox(formularioID, tabelaID) {
	var lista = document.getElementById(formularioID + ':' + tabelaID);
	var checkBoxs = lista.getElementsByTagName('input');
	for (var i = 1; i < checkBoxs.length; i++) {
		if (checkBoxs[i].checked) {
			return true;
		}
	}
	return false;
}

function clearValue(form, comp) {
	document.getElementById(form + ':' + comp).value = 0;
	
}
function desabilitar(form, button, obj) {
	document.getElementById(form + ':' + button).disabled = (obj.value != "" ? true : false);
}

function exibirModal(status) {
	if(status) {
		Richfaces.showModalPanel('popupAtivos');
		document.getElementById("popupAtivosForm:ativarTodosAtivos").checked = false;
		return false;
	}
	return true;
}