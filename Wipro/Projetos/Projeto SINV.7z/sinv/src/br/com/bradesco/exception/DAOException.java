package br.com.bradesco.exception;

/**
 * Exce��es de Data Access Objects.
 * @author Bruno Justino - brunoj - Wipro
 */
public class DAOException extends Exception {

	/**
	 * Serial version UID.
	 */
	private static final long serialVersionUID = 8841408003033779866L;

	/** 
	 * Cria uma nova inst�ncia de DaoException.
	 */
    public DAOException() {
        super();
    }

    /** 
     * Cria uma nova inst�ncia de DaoException. 
     */
    public DAOException(String msg) {
        super(msg);
    }

    /** 
     * Cria uma nova inst�ncia de DaoException.
     */
    public DAOException(Exception e) {
        super((e == null) ? null : e.toString());
    }
}