package br.com.bradesco.exception;

/**
 * Exclusivo da aplica��o para tratamento das exceptions.
 * @author Bruno Justino - brunoj - Wipro
 */
public class ExclusiveServiceBusinessException extends ExclusiveException {
 
	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 1471970131306096080L;

	/**
	 * Construtor default
	 */
	public ExclusiveServiceBusinessException() {
		super();
	}
	
	/**
	 * Construtor sobrecarregado
	 * @param arg0 - String - falha
	 */
	public ExclusiveServiceBusinessException(String arg0) {
		super(arg0);
	}
	
	/**
	 * Sobrecarga de construtor
	 * @param arg0 - Throwable - Throwable
	 */
	public ExclusiveServiceBusinessException(Throwable arg0) {
		super(arg0);
	}

	/**
	 * Sobrecarga de construtor
	 * @param arg0 - String - falha
	 * @param arg1 - Throwable - Throwable
	 */
	public ExclusiveServiceBusinessException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}