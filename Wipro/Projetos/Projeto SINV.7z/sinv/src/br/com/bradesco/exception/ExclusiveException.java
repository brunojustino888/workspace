package br.com.bradesco.exception;

import br.com.bradesco.web.aq.application.error.BradescoApplicationException;

/**
 * Exception exclusiva da aplica��o.
 * @author Bruno Justino - brunoj - Wipro
 */
public class ExclusiveException extends BradescoApplicationException {
 
	/**
	 * Serial version UID.
	 */
	private static final long serialVersionUID = -2744808697377163713L;

	/**
	 * Construtor defaul.
	 */
	public ExclusiveException() {
        super();
    }

	/**
	 * Sobrecarga do construtor.
	 * @param arg0 - String - Falha.
	 */
    public ExclusiveException(String arg0) { 
        super(arg0);
    }

    /**
     * Sobrecarga de construtor.
     * @param arg0 - Throwable - Throwable
     */
    public ExclusiveException(Throwable arg0) {
        super(arg0);
    }
    
    /**
     * Sobrecarga do construtor.
     * @param arg0 - String - Falha
     * @param arg1 - Throwable - Throwable
     */
    public ExclusiveException(String arg0, Throwable arg1) {
        super(arg0, arg1);
    }

    /**
     * Sobrecarga do construtor.
     * @param message - String - falha.
     * @param cause - Throwable - Throwable.
     * @param code - String - c�digo.
     */
    public ExclusiveException(String message, Throwable cause, String code) {
        super(message, cause, code);
        setInstrucao(ExclusiveExceptionConstants.INSTRUCAO_EXCEPCAO_GERAL);
        setLogLevel(DEFAULT_LOG_LEVEL);
        setLoggable(DEFAULT_LOGGABLE);
    } 

}