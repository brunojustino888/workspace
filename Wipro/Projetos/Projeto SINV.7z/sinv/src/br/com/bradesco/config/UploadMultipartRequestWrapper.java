package br.com.bradesco.config;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import br.com.bradesco.exception.ExclusiveException;

	public class UploadMultipartRequestWrapper extends HttpServletRequestWrapper{
	
	private Map<String,String> formParameters;
	
	@Override
	public String getHeader(String name) {
		String header = super.getHeader(name);
		return header;
	}
	
	public UploadMultipartRequestWrapper(HttpServletRequest request) {
		super(request);
		try{
			DiskFileItemFactory diskFileItemFactory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(diskFileItemFactory);
			
			List<?> fileItems = upload.parseRequest(request);
			formParameters = new HashMap<String,String>();
		
			for(int i=0;i<fileItems.size();i++){
				FileItem item = (FileItem)fileItems.get(i);
				if(item.isFormField()){
					formParameters.put(item.getFieldName(),item.getString());	
				}
				else {
					request.setAttribute(item.getFieldName(), item);
				}
			}
		}catch(FileUploadException fe){
			throw new ExclusiveException("Erro ao executar o upload", fe);
		}catch(Exception ne){
			throw new RuntimeException(ne);
		}
	}

	@Override
	public String getParameter(String name) {
		if(formParameters.get(name) != null){
			return formParameters.get(name);
		}
		return null;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Map getParameterMap() {
		return formParameters;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Enumeration getParameterNames() {
		return Collections.enumeration(formParameters.keySet());
	}

	@Override
	public String[] getParameterValues(String name) {
		List<String> params = new ArrayList<String>();
		for(String key : formParameters.keySet()){
			if (key.equals(name)) {
				params.add(formParameters.get(key));
			}
		}
		String[] values = new String[params.size()];
		params.toArray(values);
		return values;
	}
	
}