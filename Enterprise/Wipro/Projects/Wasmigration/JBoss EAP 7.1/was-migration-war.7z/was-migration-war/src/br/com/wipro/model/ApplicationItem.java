package br.com.wipro.model;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import br.com.wipro.enums.ApplicationItemEnum;

/**
 * Classe modelo para representar um determinado aplicativo.
 * @author Bruno Justino
 */
@Entity
@Table(name="WASAPPLICATIONS")
public class ApplicationItem implements Serializable {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Id do projeto
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private Long idNumber;
	
	/**
	 * Status do projeto
	 */
	@Enumerated(EnumType.STRING)
	@Column(name="STATUS")
	private ApplicationItemEnum status;
	
	/**
	 * Centro de custo do projeto
	 */
	@Column(name="CENTROCUSTO")
	private String centroCusto;
	
	/**
	 * Data prevista para a migra��o do projeto
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DATAPREVISTA")
	private Date dataPrevistaTermino;
	
	/**
	 * Data de finaliza��o da migra��o do projeto
	 */
	@Temporal(TemporalType.DATE)
	@Column(name="DATATERMINO")
	private Date dataTermino;
	
	/**
	 * Observa��o do projeto
	 */ 
	@Column(name="OBSERVACAO")
	private String observacao;
	
	/**
	 * Indicador l�gico de acesso ao projeto 
	 */
	@Column(name="ACCESSOK")
	private Boolean acessoStarteam;
	
	/**
	 * Indicador l�gico para o ramo criado da migra��o
	 */
	@Column(name="RAMOOK")
	private Boolean ramoCriado;
	
	/**
	 * Observa��o pertinente ao ramo do starteam
	 */
	@Column(name="OBSRAMO")
	private String obsRamo;
	
	/**
	 * Indicador l�gico para a disponibiliza��o de migra��o de um determinado projeto
	 */
	@Column(name="AVAILABLE")
	private Boolean disponibilizado;
	
	/**
	 * Indicador da �ltima atualiza��o do registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ULTIMA_ATUALIZACAO")
	private Date atualizacao;
	
	/**
	 * Usu�rio da �ltima atualiza��o de registro
	 */
	@Column(name="USUARIO_ULTIMA_ATUALIZACAO")
	private String usuarioUltimaAtualizacao;
	
	/**
	 * Usu�rio de cria��o do registro
	 */
	@Column(name="USUARIO_CRIACAO")
	private String usuarioCriacao;
	
	/**
	 * Data da cria��o do registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DATA_CRIACAO")
	private Date dataCriacao;

	public Long getIdNumber() {
		return this.idNumber;
	}

	public void setIdNumber(Long idNumber) {
		this.idNumber = idNumber;
	}

	public ApplicationItemEnum getStatus() {
		return this.status;
	}

	public void setStatus(ApplicationItemEnum status) {
		this.status = status;
	}

	public String getCentroCusto() {
		return this.centroCusto;
	}

	public void setCentroCusto(final String centroCusto) {
		this.centroCusto = centroCusto;
	}

	public Date getDataPrevistaTermino() {
		return this.dataPrevistaTermino;
	}

	public void setDataPrevistaTermino(final Date dataPrevistaTermino) {
		this.dataPrevistaTermino = dataPrevistaTermino;
	}

	public String getObservacao() {
		return this.observacao;
	}

	public void setObservacao(final String observacao) {
		this.observacao = observacao;
	}

	public Boolean getAcessoStarteam() {
		return this.acessoStarteam;
	}

	public void setAcessoStarteam(final Boolean acessoStarteam) {
		this.acessoStarteam = acessoStarteam;
	}

	public Boolean getRamoCriado() {
		return this.ramoCriado;
	}

	public void setRamoCriado(final Boolean ramoCriado) {
		this.ramoCriado = ramoCriado;
	}

	public String getObsRamo() {
		return this.obsRamo;
	}

	public void setObsRamo(final String obsRamo) {
		this.obsRamo = obsRamo;
	}

	public Boolean getDisponibilizado() {
		return this.disponibilizado;
	}

	public void setDisponibilizado(final Boolean disponibilizado) {
		this.disponibilizado = disponibilizado;
	}

	public Date getAtualizacao() {
		return this.atualizacao;
	}

	public void setAtualizacao(final Date atualizacao) {
		this.atualizacao = atualizacao;
	}

	public String getUsuarioUltimaAtualizacao() {
		return this.usuarioUltimaAtualizacao;
	}

	public void setUsuarioUltimaAtualizacao(final String usuarioUltimaAtualizacao) {
		this.usuarioUltimaAtualizacao = usuarioUltimaAtualizacao;
	}

	public String getUsuarioCriacao() {
		return this.usuarioCriacao;
	}

	public void setUsuarioCriacao(final String usuarioCriacao) {
		this.usuarioCriacao = usuarioCriacao;
	}

	public Date getDataCriacao() {
		return this.dataCriacao;
	}

	public void setDataCriacao(final Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public Date getDataTermino() {
		return this.dataTermino;
	}

	public void setDataTermino(final Date dataTermino) {
		this.dataTermino = dataTermino;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((acessoStarteam == null) ? 0 : acessoStarteam.hashCode());
		result = prime * result + ((atualizacao == null) ? 0 : atualizacao.hashCode());
		result = prime * result + ((centroCusto == null) ? 0 : centroCusto.hashCode());
		result = prime * result + ((dataCriacao == null) ? 0 : dataCriacao.hashCode());
		result = prime * result + ((dataPrevistaTermino == null) ? 0 : dataPrevistaTermino.hashCode());
		result = prime * result + ((dataTermino == null) ? 0 : dataTermino.hashCode());
		result = prime * result + ((disponibilizado == null) ? 0 : disponibilizado.hashCode());
		result = prime * result + ((idNumber == null) ? 0 : idNumber.hashCode());
		result = prime * result + ((obsRamo == null) ? 0 : obsRamo.hashCode());
		result = prime * result + ((observacao == null) ? 0 : observacao.hashCode());
		result = prime * result + ((ramoCriado == null) ? 0 : ramoCriado.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((usuarioCriacao == null) ? 0 : usuarioCriacao.hashCode());
		result = prime * result + ((usuarioUltimaAtualizacao == null) ? 0 : usuarioUltimaAtualizacao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ApplicationItem other = (ApplicationItem) obj;
		if (acessoStarteam == null) {
			if (other.acessoStarteam != null)
				return false;
		} else if (!acessoStarteam.equals(other.acessoStarteam))
			return false;
		if (atualizacao == null) {
			if (other.atualizacao != null)
				return false;
		} else if (!atualizacao.equals(other.atualizacao))
			return false;
		if (centroCusto == null) {
			if (other.centroCusto != null)
				return false;
		} else if (!centroCusto.equals(other.centroCusto))
			return false;
		if (dataCriacao == null) {
			if (other.dataCriacao != null)
				return false;
		} else if (!dataCriacao.equals(other.dataCriacao))
			return false;
		if (dataPrevistaTermino == null) {
			if (other.dataPrevistaTermino != null)
				return false;
		} else if (!dataPrevistaTermino.equals(other.dataPrevistaTermino))
			return false;
		if (dataTermino == null) {
			if (other.dataTermino != null)
				return false;
		} else if (!dataTermino.equals(other.dataTermino))
			return false;
		if (disponibilizado == null) {
			if (other.disponibilizado != null)
				return false;
		} else if (!disponibilizado.equals(other.disponibilizado))
			return false;
		if (idNumber == null) {
			if (other.idNumber != null)
				return false;
		} else if (!idNumber.equals(other.idNumber))
			return false;
		if (obsRamo == null) {
			if (other.obsRamo != null)
				return false;
		} else if (!obsRamo.equals(other.obsRamo))
			return false;
		if (observacao == null) {
			if (other.observacao != null)
				return false;
		} else if (!observacao.equals(other.observacao))
			return false;
		if (ramoCriado == null) {
			if (other.ramoCriado != null)
				return false;
		} else if (!ramoCriado.equals(other.ramoCriado))
			return false;
		if (status != other.status)
			return false;
		if (usuarioCriacao == null) {
			if (other.usuarioCriacao != null)
				return false;
		} else if (!usuarioCriacao.equals(other.usuarioCriacao))
			return false;
		if (usuarioUltimaAtualizacao == null) {
			if (other.usuarioUltimaAtualizacao != null)
				return false;
		} else if (!usuarioUltimaAtualizacao.equals(other.usuarioUltimaAtualizacao))
			return false;
		return true;
	}
	
}