package br.com.wipro.beans;

import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Named;

import br.com.wipro.dao.HibernateConfigurator;
import br.com.wipro.dao.HibernateJpaConfigurator;

/**
 * Respons�vel por realizar um teste de conex�o com a base de dados no in�cio da
 * aplica��o.
 * 
 * @author Bruno Justino
 */
@Named
@ViewScoped
public class IndexBean implements Serializable {

	/**
	 * Serial version UID.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Fornece uma sess�o com o hibernate ou um EnityManager.
	 * 
	 * @return isConnected - String - representa o resultado do teste de conex�o.
	 */
	public String test() {
		try {
			HibernateConfigurator.getSessionFactory().getCurrentSession();
			return "Configura��o v�lida de acesso a base de dados (Utilizando arquivo hibernate.cfg.xml).";
		} catch (Throwable error) {
			try {
				HibernateJpaConfigurator.getEntityManager();
				return "Configura��o v�lida de acesso a base de dados (Utilizando arquivo persistence.xml).";
			} catch (Throwable erro) {
				erro.printStackTrace();
			}
		}
		return "Configura��o inv�lida de acesso a base de dados.";
	}

}