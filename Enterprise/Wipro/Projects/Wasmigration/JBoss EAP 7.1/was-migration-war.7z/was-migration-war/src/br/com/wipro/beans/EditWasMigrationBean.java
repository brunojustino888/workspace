package br.com.wipro.beans;

import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Named;

import br.com.wipro.dto.ApplicationItemDTO;

/**
 * Back-end da tela home-wasmigration.xhtml
 * @author Bruno Justino
 */
@Named
@ViewScoped
public class EditWasMigrationBean implements Serializable {

	/**
	 * Serial version UID.
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Servi�o respons�vel pelas a��es da tela. 
	 */
//	private ApplicationItemService applicationItemService;

	/**
	 * Representa o ID do projeto que sofrer� as altera��es.
	 */
	private ApplicationItemDTO item;
	
	/**
	 * Construtor inicializando o servi�o correspondente � tela e buscando a entidade que dever� ser transformada em DTO para edi��o. 
	 */
	public EditWasMigrationBean() {
		System.out.println("\n\n--------------------\nID do objeto que ser� editado: " + this.item.getIdNumber());
//		this.applicationItemService = new ApplicationItemServiceImpl();
		
	}


	/**
	 * M�todo get do atributo item.
	 * @return item - ApplicationItemDTO - item que ser� editado.
	 */
	public ApplicationItemDTO getItem() {
		return item;
	}

	/**
	 * M�todo set do atributo item.
	 * @param item - ApplicationItemDTO - item que ser� editado.
	 */
	public void setItem(ApplicationItemDTO item) {
		this.item = item;
	}

}