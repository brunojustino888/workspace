package br.com.bradesco.exception;

import br.com.bradesco.web.aq.application.error.BradescoApplicationException;
import br.com.bradesco.web.aq.application.error.config.IExceptionConfig;
import br.com.bradesco.web.aq.application.error.handler.BradescoApplicationExceptionHandler;

/**
 * Handler exclusivo da aplica��o para tratamento das exceptions.
 * @author Bruno Justino - brunoj - Wipro
 */
public class ExclusiveExceptionHandler extends BradescoApplicationExceptionHandler {

    /**
     * CTE que indica a key da mensagem i18n correspondente � etiqueta
     * do campo que mostra o codigo de erro.
     */
    public static final String CODIGO_ERRO_LABEL_KEY = "sinv.erro.codigo.label";
    
    /**
     * Construtor default.
     */
    public ExclusiveExceptionHandler() {
        super();
    }

    /**
     * Executado antes de realizar alerta de erro.
     * @see br.com.bradesco.web.aq.application.error.handler.BradescoApplicationExceptionHandler#beforePerformAlert(br.com.bradesco.web.aq.application.error.BradescoApplicationException, br.com.bradesco.web.aq.application.error.config.IExceptionConfig)
     */
    protected boolean beforePerformAlert(BradescoApplicationException exception, IExceptionConfig exceptionConfig) {
        return super.beforePerformAlert(exception, exceptionConfig);
    }

    /**
     * Executado antes de realizar forward para a p�gina de error.
     * @see br.com.bradesco.web.aq.application.error.handler.BradescoApplicationExceptionHandler#beforePerformForward(br.com.bradesco.web.aq.application.error.BradescoApplicationException, br.com.bradesco.web.aq.application.error.config.IExceptionConfig)
     */
    protected boolean beforePerformForward(BradescoApplicationException exception, IExceptionConfig exceptionConfig) {
        return super.beforePerformForward(exception, exceptionConfig);
    }

    /**
     *Executado antes de realizar o logout configurado.
     * @see br.com.bradesco.web.aq.application.error.handler.BradescoApplicationExceptionHandler#beforePerformLogout(br.com.bradesco.web.aq.application.error.BradescoApplicationException, br.com.bradesco.web.aq.application.error.config.IExceptionConfig)
     */
    protected boolean beforePerformLogout(BradescoApplicationException exception, IExceptionConfig exceptionConfig) {
        return super.beforePerformLogout(exception, exceptionConfig);
    }

    /**
     * Tratamento da exce��o recebida. 
     * @see br.com.bradesco.web.aq.application.error.handler.BradescoApplicationExceptionHandler#handleException(java.lang.Exception, br.com.bradesco.web.aq.application.error.config.IExceptionConfig, boolean)
     */
    public void handleException(Exception exception, IExceptionConfig exceptionConfig, boolean redirect) {       
        if (exception instanceof ExclusiveException) {
            super.handleException(exception, exceptionConfig, redirect);          
        } else {
            super.handleException(exception, exceptionConfig, redirect);
        }
    }

    /**
     * Escreve log.
     * @see br.com.bradesco.web.aq.application.error.handler.BradescoApplicationExceptionHandler#writeLog(br.com.bradesco.web.aq.application.error.BradescoApplicationException, br.com.bradesco.web.aq.application.error.config.IExceptionConfig)
     */
    protected void writeLog(BradescoApplicationException exception, IExceptionConfig exceptionConfig) {
        super.writeLog(exception, exceptionConfig);
    }

}