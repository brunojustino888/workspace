package br.com.bradesco.exception;

import br.com.bradesco.web.aq.application.error.BradescoBaseException;

/**
 * Service exclusivo da aplica��o para tratamento das exceptions.
 * @author Bruno Justino - brunoj - Wipro
 */
public class ExclusiveServiceException extends BradescoBaseException {

    /**
     * Serial version UID.
     */
    private static final long serialVersionUID = 2079167605431107526L;
    
    /**
     * Construtor default da exce��o.
     * @param message - String - mensagem interna da exce��o.
     * @param cause - Throwable - objeto que d� origem a exce��o.
     * @param code -String - c�digo interno de exce��o.
     */
    public ExclusiveServiceException(String message, Throwable cause, String code) {} 
    
    /**
     * Sobrecarga do construtor da exce��o.
     * @param message - String - mensagem interna da exce��o.
     * @param code - String - c�digo de exce��o utilizado para obter uma mensagem i18n.
     */
    public ExclusiveServiceException(String message, String code) {
        this(message, null, code);
    }
    
}