package br.com.bradesco.sinv.application;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.bradesco.sinv.dto.ApplicationItemDTO;
import br.com.bradesco.sinv.services.ApplicationItemService;

/**
 * Implementa��o do servi�o respons�vel pelas a��es da tela home-wasmigration.xhtml
 * @author Bruno Justino
 */
public class ApplicationItemServiceImpl implements ApplicationItemService, Serializable {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<ApplicationItemDTO> listar() {
		return mockApplicationList(); 
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void cadastrar(ApplicationItemDTO item) { 
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void editar(ApplicationItemDTO item) {

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void excluir(ApplicationItemDTO item) {

	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public ApplicationItemDTO buscarPorId(Long idNumber) {
		return null;
	}
	
	/**
	 * M�todo utilizado para popular uma lista mockada de aplica��es.
	 * @return lista - List<ApplicationItemDTO> - lista de DTO mockada
	 */
	private List<ApplicationItemDTO> mockApplicationList() {
		List<ApplicationItemDTO> lista = new ArrayList<ApplicationItemDTO>();
		for(int i=0; i<28; i++) {
			ApplicationItemDTO applicationItemDTO = new ApplicationItemDTO();
			applicationItemDTO.setAcessoStarteam("Sim");
			applicationItemDTO.setCentroCusto("cccc");
			applicationItemDTO.setDataPrevistaTermino(new Date());
			applicationItemDTO.setDisponibilizado("Sim");
			applicationItemDTO.setRamoCriado("N�o");
			applicationItemDTO.setIdNumber(Long.valueOf(Integer.toString(i)));
			applicationItemDTO.setObservacao("Observa��o de teste.");
			applicationItemDTO.setObsRamo("Observa��o de teste do ramo.");
			applicationItemDTO.setStatus("Pendente");
			lista.add(applicationItemDTO);
		}
		return lista;
	}

}