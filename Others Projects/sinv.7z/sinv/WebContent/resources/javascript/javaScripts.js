/************************************************
*Function: envoy()
*Detecta si ya se ha hecho un submit en un formulario
*Par�metros:no
*Retorno:messagem alert
************************************************/       
var count=0;
function envoy() {                       
  if (count == 0){
	  count++;
      return true;
  }else {
     alert("Os dados est�o sendo processados...");
     return false;
  }
}

/************************************************
* function naoEspeciaisApenas
* Retorna apenas caracteres n�o especiais.
* Input: myfield, e 
************************************************/       
function naoEspeciaisApenas(myfield, e)
{
    var key;
    var keychar;
    
    if (window.event)
       key = window.event.keyCode;
    else if (e)
       key = e.which;
    else
       return true;
    keychar = String.fromCharCode(key);
    // control keys
    if ((key==null) || (key==0) || (key==8) || 
        (key==9) || (key==13) || (key==27) )
       return true;
    // caracteres especiais
    else if ((key==39) || (key==38) || (key==64) || 
        (key==60) || (key==62) || (key==59) || 
        (key==125) || (key==123) || (key==34))
       return false;
    else
       return true;
}

/************************************************
* function : hasValue
* Descri��o : Verifica se a string nao e composta somente de 
* espa�os.
* Input: texto 
************************************************/       
function hasValue(texto) {
    var novoTexto = ""  
    for(iTmp=0;iTmp<texto.length;iTmp++) {
        if(texto.charAt(iTmp) != " ") {
            return true;
        }
    }
    return false;
}

/************************************************
* Function  : max_car
* Descri��o : Valida campo com mais de 255 caracteres
*************************************************/
function max_car(objeto,nome) {
    var desc = new String(objeto.value);
    if (desc.length > 255) {
        alert("Campo " + nome + " excedeu os 255 caracteres permitidos");
        objeto.value=desc.substring(0,255);		
        objeto.focus();			
        return false;
    }
}

/************************************************
* Function: showtip
* Cria um ToolTip
* Input: this, evento, texto
************************************************/

function showtip(current, e, text) {
    current.style.cursor = 'hand';
    if (document.all) {
        thetitle = text.split('<br>');
        if (thetitle.length > 1) {
            thetitles = '';
            for (i = 0; i < thetitle.length; i++)
                thetitles += thetitle[i];
            current.title = thetitles;
        } else 
            current.title = text;
    } else if (document.layers) {
        document.tooltip.document.write('<layer bgColor="white" style="border:1px solid black;font-size:12px;">' + text + '</layer>');
        document.tooltip.document.close();
        document.tooltip.left = e.pageX + 5;
        document.tooltip.top = e.pageY + 5;
        document.tooltip.visibility = "show";
    }
}


/************************************************
* Function: isMember
* Input: texto, texto
************************************************/
function isMember(strValue, strArray) {
    var isMemberResult = false;
    var strArrayLen = strArray.length;
    var iStrArray;

    for (iStrArray=0; iStrArray < strArrayLen; iStrArray++) {
        if (strValue == strArray[iStrArray]) {
            isMemberResult = true;
            break;
        }
    }

    return isMemberResult;
}

/************************************************
* Function: fieldFormat
* Input: inputObj, format, allowed
************************************************/
function fieldFormat(inputObj, format, allowed) {
    var thisValue = inputObj.value;
    var thisLength = thisValue.length;
    var formatLength = format.length;
    var validArray = new Array();

    for (var i=0; i < allowed.length; i++) {
        validArray[i] = allowed.substr(i,1);
    }

    for (var i=0; i < thisLength; i++) {
        if (i < formatLength) {
            if (format.substr(i,1) == '*') {
                if (!isMember(thisValue.substr(i,1), validArray)) {
                    thisValue = thisValue.substr(0,i) + thisValue.substr(i+1);
                    thisLength = thisValue.length;
                    i--;
                }
            } else {
                if (thisValue.substr(i,1) != format.substr(i,1)) {
                    thisValue = thisValue.substr(0,i) + format.substr(i,1) + thisValue.substr(i);
                    thisLength = thisValue.length;
                }
            }
        } else {
            thisValue = thisValue.substr(0,i);
            thisLength = thisValue.length;
        }
    }

    if (inputObj.value != thisValue) {
        inputObj.value = thisValue;
    }
}

function upperCase(campo) {
	campo.value = campo.value.toUpperCase();
}

function apenasNumeros(){
	
	tecla = window.event.keyCode;
	if(tecla >= 48 && tecla <= 57){
		return true;
	}else{
		return false;
	}
}




/**
 * Conta os caracteres de um textarea
 * @param box
 * @param valor
 * @param campospan
 * @return
 */
function contarCaracteres(textArea,valorMaximo,campoSpanMsg) {

	var conta = valorMaximo - textArea.value.length;
	
	if(textArea.value.length >= valorMaximo){
		textArea.value = textArea.value.substr(0,valorMaximo);
	}	
	
	var totalDigitados = textArea.value.length;
	document.getElementById(campoSpanMsg).innerHTML = totalDigitados + " de " + valorMaximo + " Caracteres digitados";	
	
}




function limitarTamanhoTextArea(textArea, tamanhoMaximo) {
    bloqueiaCrtlV();
    if (textArea.value.length > tamanhoMaximo) {
       textArea.value = textArea.value.substring(0, tamanhoMaximo);
       tamanhoMaximo += 1;
       alert("Tamanho maximo permitido " + tamanhoMaximo + ".");
     }
}

function bloqueiaCrtlV(){
		var ctrl=window.event.ctrlKey;
		var tecla=window.event.keyCode;
		
		if (ctrl && tecla==86) {
			alert("IMPOSSIVEL COLAR TEXTO NESTE CAMPO!!!");
			event.keyCode=0; 
			event.returnValue=false;
		}
	}





/**
 * Funcao que permite apenas carcteres num�ricos
 */
function checkOnlyNumber() {

	if( (window.event.keyCode == 8 || window.event.keyCode == 9 || window.event.keyCode == 13 || window.event.keyCode == 27 || 
			window.event.keyCode == 37 || window.event.keyCode == 39 || window.event.keyCode == 46 || 
			window.event.keyCode == 110 || window.event.keyCode == 189 || window.event.keyCode == 109 ) ||
      	(window.event.keyCode >= 48 && window.event.keyCode <= 57) || 
      	(window.event.keyCode >= 96 && window.event.keyCode <= 105) ) {
    	
    	return true; 
  	} else {
    	return false;
  	}
}



function numberCharacter(key) {

	//tecla 44=v�rgula 	
    if ( (key < 48 || key > 57) && key!=44 )
        return false;
        
    return true;
    
}



function trocaCursor(tipo, btn){  
    this.document.body.style.cursor=tipo;
    btn.style.cursor="wait";
}





//JavaScript Document
function handleEnter (field, event) {
  var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
	if (keyCode == 13) {
	  var i;
	  for (i = 0; i < field.form.elements.length; i++)
	    if (field == field.form.elements[i])
		  break;
	  i = (i + 1) % field.form.elements.length;
	  while (field.form.elements[i].type == "hidden")
	    i = (i + 1) % field.form.elements.length;
	  field.form.elements[i].focus();
	  return false;
	} 
	else
	  return true;
}     
   
function focarProximo(){
  if (window.event.srcElement.type != 'submit' && window.event.srcElement.type != 'button' && window.event.srcElement.type != 'reset' && window.event.srcElement.type != 'textarea'){
	var ele = window.event.srcElement;
    var index = ele.sourceIndex;
    return handleEnter(ele, event);
  }
}










//Chamada Fake para executar uma a��o no bot�o pelo modal
function modalAnswer(caller, action){
	clear_linkDummyForm();
	document.forms['linkDummyForm'].elements['autoScroll'].value=getScrolling();
	document.forms['linkDummyForm'].elements['linkDummyForm:_link_hidden_'].value=caller.id;
	document.forms['linkDummyForm'].elements['action'].value=action;
	document.forms['linkDummyForm'].submit();
}

function modalAnswerPopupSim(){
	modalAnswerPopupPrivate(true);
}

function modalAnswerPopupNao(){
	modalAnswerPopupPrivate(false);
}

function modalAnswerPopupPrivate(flag){
	var $botaoModalConfirmEnviar = $("#formModalConfirm\\:formModalConfirmPopup");
	var $botaoModalConfirmFlag = $("#formModalConfirm\\:formModalConfirmPopupFlag");
	$botaoModalConfirmFlag.attr("value", flag);
	$botaoModalConfirmEnviar.click();
}

function modalAnswerPopupSimPopup(){
	modalAnswerPopupPrivatePopup(true);
}

function modalAnswerPopupNaoPopup(){
	modalAnswerPopupPrivatePopup(false);
}

function modalAnswerPopupPrivatePopup(flag){
	var $botaoModalConfirmEnviar = $("#formModalPopupConfirm\\:formModalPopupConfirmPopup");
	var $botaoModalConfirmFlag = $("#formModalPopupConfirm\\:formModalPopupConfirmPopupFlag");
	$botaoModalConfirmFlag.attr("value", flag);
	$botaoModalConfirmEnviar.click();
}

//Chamada Fake para executar uma a��o no bot�o pelo modal
function modalAnswerOpener(caller, action){
	window.opener.clear_linkDummyForm();
	window.opener.document.forms['linkDummyForm'].elements['autoScroll'].value=window.opener.getScrolling();
	window.opener.document.forms['linkDummyForm'].elements['linkDummyForm:_link_hidden_'].value=caller.id;
	window.opener.document.forms['linkDummyForm'].elements['action'].value=action;
	window.opener.document.forms['linkDummyForm'].submit();
}

function executarRegraFocoPesquisar(nomeCampoFoco,labelExibido, nomeBotaoClicado){
	var e = event.srcElement.tagName;
	if (event.keyCode == 8 && e != 'INPUT' && e != 'TEXTAREA'){
		event.cancelBubble = true;event.returnValue = false;
	};
	
	if (event.keyCode == 13) { 
		var retornoCampoAtivo = document.activeElement.id;
			var botaoFoco = nomeCampoFoco;
			if(retornoCampoAtivo == botaoFoco) {
				
				if(labelExibido != ""){
					alert(labelExibido);
				}
				document.getElementById(nomeBotaoClicado).click(); 
				return false; 
			}
	}
}
