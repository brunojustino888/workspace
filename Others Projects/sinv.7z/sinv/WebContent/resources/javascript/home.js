function opa()
{	        
	window.open('/br/redirect/menuvert/opa.html','opa','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,width=718,height=493,top=10,left=10');
}

function sort_trat()
{	        
	window.open('/br/redirect/sort_trat.html','bradesco','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,width=770,height=420,top=10,left=10');
}

function seg_auto_mulher()
{	        
	window.open('/br/redirect/seg_auto_mulher.html','bradesco','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,width=705,height=384,top=10,left=10');
}

function acao_voluntaria()
{	        
	window.open('/br/redirect/acao_voluntaria.html','bradesco','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,width=791,height=536,top=10,left=10');
}

function bc_resp_soc()
{	        
	window.open('/br/redirect/resp_soc_bc.html','bradesco','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,width=791,height=536,top=10,left=10');
}

function finasa()
{	        
	window.open('/br/redirect/finasa.html','bradesco','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,width=791,height=536,top=10,left=10');
}

function ibest()
{	        
	window.open('/html/hotsite/ibest/ibest.htm','ibest','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,width=707,height=436,top=10,left=10');
}
function ibest_top3()
{	        
	window.open('/html/hotsite/ibest_2006/index.html?parampag=ibest','ibest','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,width=707,height=436,top=10,left=10');
}

function hf_si()
{	        
	window.open('/br/redirect/hs_si.html','ibest','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,width=700,height=517,top=10,left=10');
}

function amex()
{	        
	window.open('/br/redirect/amex.html','amex','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,width=720,height=480,top=10,left=10');
}

function verao_completo()
{	        
	window.open('/br/redirect/verao_bc.html','verao_completo','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,width=791,height=536,top=10,left=10');
}

function sfcriancas()
{	        
	window.open('/br/redirect/menutv/sfcriancas.html','shopfacil','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,width=645,height=504,top=10,left=10');
}


function h24horas()
{	        
	window.open('/br/redirect/h24horas.html','popup24horas','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,width=600,height=400,top=10,left=10');
}

function briefinginfoemail()
{	        
	window.open('/html/hotsite/briefing_infoemail/pop_infoemail.htm','infoemail','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,width=670,height=450,top=10,left=10');
}

function sorte_completa()
{	        
	window.open('/br/redirect/sorte_completa.html','sortecompleta','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,width=779,height=436,top=10,left=10');
}


function chamahotsite()

{
        window.open('/br/redirect/banner/seguro_carro.html','win','width=600,height=393,top=100,left=40');
}


function cred_pess()
{	        
	window.open('/html/pop_up/cred_pess/index.html','bradesco','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,width=600,height=550,top=-5,left=10');
}

function seguranca_b()
{
	window.open('/html/hotsite/tut_TanCode/index.html','Seguranca', 'width='+800+', height='+600+', top='+0+', left='+0+', scrollbars=no,status=no, toolbar=no, location=no, directories=no, menubar=no,resizable=no, fullscreen=no');
}

function prev_crianc()
{	        
	window.open('/br/redirect/banner/p_jovem.htm','bradesco','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,width=650,height=400,top=10,left=10');
}


function letraacesso()
{	        
	window.open('/html/pop_up/auto_atm/nv_auto_atend.html','bradesco','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,width=720,height=500,top=10,left=10');
}

function hiperfundo_brad()
{		      
	window.open('/html/pop_up/hiperfundo_novo/outdoor.html', 'hiperfundo', 'width=707,height=436,top=0,left=10,scrollbars=0,menubar=0,toolbar=no,statusbar=no,resizable=no');
}

function apmec2005()
{
	window.open('/br/redirect/apimec2005.html', 'POP_RI','scrollbars=yes,location=no, directories=no, status=yes, menubar=no, resizable=no, toolbar=no, top=0, left=0, width=790,height=520');
}

function sc_credimob()
{
	window.open('/html/pop_up/sc_credimob/pop.html', 'SHOPCRDIT','scrollbars=yes,location=no, directories=no, status=yes, menubar=no, resizable=no, toolbar=no, top=0, left=0, width=500,height=180');
}

function si_pibb()
{		      
	window.open('/br/redirect/si_pibb.html', 'hiperfundo', 'width=700,height=520,top=0,left=10,scrollbars=0,menubar=0,toolbar=no,statusbar=no,resizable=no');
}

function si_tutor()
{		      
	window.open('/br/redirect/si_tut.html', 'Bradesco', 'width=790,height=500,top=0,left=10,scrollbars=0,menubar=0,toolbar=no,statusbar=no,resizable=no');
}

function red_atend()
{		      
	window.open('http://institucional.bradesco.com.br/hotsites/bdn/inaugura_bdn.asp', '', 'width=550,height=400,top=0,left=10,scrollbars=0,menubar=0,toolbar=no,statusbar=no,resizable=no');
}

function hs_investimentos()
{		      
	window.open('/html/pop_up/investimentos/hs_investimentos.html', '', 'width=740,height=480,top=0,left=10,scrollbars=0,menubar=0,toolbar=no,statusbar=no,resizable=no');
}

function visa_electron()
{		      
	window.open('/html/pop_up/visa_electron/visa_electron.html', '', 'width=707,height=426,top=0,left=10,scrollbars=0,menubar=0,toolbar=no,statusbar=no,resizable=no');
}

function Pesquisa_Satisfacao()
{
	window.open('/br/redirect/banner/pesquisa_satisfacao.html','pequisatisfacao','width=451, height=455, top=99, left=99, scrollbars=no, status=no, toolbar=no, location=no, directories=no, menubar=no, resizable=no, fullscreen=no');
}

function cartoes_disney()
{		      
	window.open('/html/hotsite/cartoes_disney2/index.html', '', 'width=779,height=436,top=0,left=10,scrollbars=0,menubar=0,toolbar=no,statusbar=no,resizable=no');
}


function pag_fcil_brad()
{		      
	window.open('/html/hotsite/pag_fcil_brad/pop.html', '', 'width=628,height=390,top=0,left=10,scrollbars=0,menubar=0,toolbar=no,statusbar=no,resizable=no');
}

function recarga_pf()
{		      
	window.open('/html/hotsite/pag_fcil_brad/pop.html', '', 'width=628,height=390,top=0,left=10,scrollbars=0,menubar=0,toolbar=no,statusbar=no,resizable=no');
}

function hb()
{		      
	window.open('/br/redirect/destaques/pop_home_broker.html', '', 'width=700,height=420,top=0,left=10,scrollbars=0,menubar=0,toolbar=no,statusbar=no,resizable=no');
}

function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_showHideLayers() { //v6.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) if ((obj=MM_findObj(args[i]))!=null) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}
function getElm(id) 
{
	return(document.all&&document.getElementById)?document.all[id]:document.getElementById(id);
}

function fechar_flash() 
{
	getElm('bradcompleto').style.display = 'none';
}

function cortina()
{
	flash = new Array(4);
	
	flash[0] = "/bradesco_completo/cortina/dhtml_box_cao_050720.swf";
	flash[1] = "/bradesco_completo/cortina/dhtml_box_pub_050720.swf";
	flash[2] = "/bradesco_completo/cortina/dhtml_box_vinho_050720.swf";
	flash[3] = "/bradesco_completo/cortina/bradescompleto_prime_casal_praia.swf";
	
	var index = Math.floor(Math.random() * flash.length);
	document.write(' <object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="786" height="480" id="dhtml_box_casal_COMtrilha_050603" align="middle"> ');
	document.write(' <param name="allowScriptAccess" value="sameDomain" /> ');
	document.write(' <param name="movie" value="' + flash[index] + '" /> ');
	document.write(' <param name="quality" value="high" /> <param name="wmode" value="transparent" /> ');
	document.write(' <embed src="' + flash[index] + '" quality="high" bgcolor="#ffffff" width="786" height="480" name="dhtml_box_casal_COMtrilha" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></EMBED> ');
	document.write(' </object> ');	
}

function ReloadTop() 
{ 
        try 
        { 
			parent.frames[0].frames.document.FormIB2001.AGN.focus(); 
        } 
        catch(e) 
        { 
			var detect = navigator.userAgent.toLowerCase();
			if (detect.indexOf('mac') < 1) 
			{top.location.href="http://www.bradesco.com.br/"; }
        } 
}      
