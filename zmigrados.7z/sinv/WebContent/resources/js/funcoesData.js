function isBranco(obj){a=obj.value;var err=0,tam,i,cont;tam=a.length;if (a=='')err=1;if (!tam==0) {	cont=0;while(tam){i=a.substring(tam-1,tam);if (i!=' ') cont++;tam--;}if (cont==0)err=1;}if (err==0) {return false;} else {return true;}}
function isNumero(obj){a=obj.value;var err=0,i,tam;tam=a.length;if (tam!=0){while(tam) {i=parseInt(a.substring(tam-1,tam));if (isNaN(i)) err=1;tam--;}} elseerr=1;if (err==0){return true;}if (err==1){return false;}}

function decimalParseInt(value) {
	value = value + "";
	while (value.substr(0,1) == "0")
		value = value.substr(1);
	if (value=="")
		return 0;
	else
		return parseInt(value);
}

function calculaDiasDataAtual(data){
	var dataAtual = new Date();
	var data1Obj = getDateDiaMesAnoToMesDiaAno(data);	
							
	var diferenca = dataAtual.getTime() - data1Obj.getTime();
	diferenca = diferenca / (1000 * 60 * 60 * 24);
	return diferenca;
}

function getDateDiaMesAnoToMesDiaAno(data) {
    var datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
    
    var dataValue = data.value;
    var matchArray = dataValue.match(datePattern);
    
    day   = matchArray[1];
    month = matchArray[2];
    year  = matchArray[3];

    var dataFormated = month + "/" + day + "/" + year;
    var dataObj = new Date(dataFormated);
    
    return dataObj;
}

function calculaDias(dataInicial, dataFinal){
	var data1Obj = getDateDiaMesAnoToMesDiaAno(dataInicial);
    var data2Obj = getDateDiaMesAnoToMesDiaAno(dataFinal);
	
	var diferenca = data2Obj.getTime() - data1Obj.getTime();
	diferenca = diferenca / (1000 * 60 * 60 * 24);
	return diferenca;
}

function validaIntervaloData(dataInicial, dataFinal) {
    var data1Obj = getDateDiaMesAnoToMesDiaAno(dataInicial);
    var data2Obj = getDateDiaMesAnoToMesDiaAno(dataFinal);
    
    if (data1Obj.getTime() > data2Obj.getTime()) {
    	return false;
    }
    return true;
}

function validaData(objData) {
	var vResult;
	if (!isBranco(objData) && objData.value.length == 10) {
		fieldValue = objData.value;
		var validaDateRegExp = new RegExp("^([0-3][0-9])/([0-1][0-9])/((19|2[01])[0-9]{2})$");
		var validDaysInMonths = [31,28,31,30,31,30,31,31,30,31,30,31];
		vResult = validaDateRegExp.test(fieldValue);
	
		if (vResult) {
			var arrayRegs = validaDateRegExp.exec(fieldValue);
			var dia = decimalParseInt(arrayRegs[1]);
			var mes = decimalParseInt(arrayRegs[2]);
			var ano = decimalParseInt(arrayRegs[3]);
	
			if (((ano % 4)==0) && (((ano % 100)!=0) || ((ano % 400)==0))) {
				validDaysInMonths[1]=29;
			}
			vResult = ((mes >= 1) && (mes <= 12)) &&
				  ((dia >= 1) && (dia <= validDaysInMonths[mes-1]));
		}
	}
	if (!vResult) {
		return false;
	}
	return true;
}