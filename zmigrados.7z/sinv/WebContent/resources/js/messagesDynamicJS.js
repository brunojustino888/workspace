/* @(#)messagesDynamicJS.js   
 *
 * Copyright (c) 2013 Bradesco.
 * Osasco, SP - Brazil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bradesco. ("Confidential Information").  You shall not disclose 
 * such Confidential Information and shall not use, publish, alter 
 * or otherwise make it available, directly or indirectly, without the prior 
 * written consent of InfoServer.
 */

/**
 * @author InfoSERVER - Lucas Verdi Carnevalli
 */

/*
 * Implementa��o na JSP:
 * <f:verbatim><ul id="idMessagesDynamicJS"></ul></f:verbatim>
 */

var ID_MESSAGES_DYNAMIC_JS = "idMessagesDynamicJS";

/*
 * @Param
 * type SEVERITY_ERROR : Mensagem de erro
 * type SEVERITY_WARN  : Mensagem de alerta
 * type SEVERITY_INFO  : Mensagem de informa��o
 * text 			   : Texto a ser exibido
 */
function addMessages(text, type) {
	var newNode = document.createElement("li");
	var nodeMessages = document.getElementById(ID_MESSAGES_DYNAMIC_JS);	
	nodeMessages.appendChild(newNode);
	var countMessages = nodeMessages.getElementsByTagName("li");
	newNode.innerHTML = "<span class=\"" + type + "\" id=\"" + ID_MESSAGES_DYNAMIC_JS + "_" + countMessages.length + "\">" + text + "</span>";
}

function removeMessages(form) {
	var messages = document.getElementById(form).getElementsByTagName('li');
	var countMessages = messages.length;
	for(var i=0; i<countMessages; i++) {
		messages[0].parentNode.removeChild(messages[0]);
	}
}

function showMessages() {
	document.getElementById(ID_MESSAGES_DYNAMIC_JS).style.display = "";
}

function hideMessages() {
	document.getElementById(ID_MESSAGES_DYNAMIC_JS).style.display = "none";
}