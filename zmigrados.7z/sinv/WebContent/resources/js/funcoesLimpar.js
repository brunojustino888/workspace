function limparOperacoesDia() {
	document.getElementById("operacoesDiaForm:periodoInicio").value = "";
	document.getElementById("operacoesDiaForm:periodoInicio.day").value = "";
	document.getElementById("operacoesDiaForm:periodoInicio.month").value = "";
	document.getElementById("operacoesDiaForm:periodoInicio.year").value = "";
	document.getElementById("operacoesDiaForm:periodoFim").value = "";
	document.getElementById("operacoesDiaForm:periodoFim.day").value = "";
	document.getElementById("operacoesDiaForm:periodoFim.month").value = "";
	document.getElementById("operacoesDiaForm:periodoFim.year").value = "";
	document.getElementById("operacoesDiaForm:tipoAtivo").options[0].selected = "true";
	document.getElementById("operacoesDiaForm:ativo").options[0].selected = "true";
	document.getElementById("operacoesDiaForm:trava").options[0].selected = "true";
	document.getElementById("operacoesDiaForm:empresa").options[0].selected = "true";
	document.getElementById("operacoesDiaForm:filial").options[0].selected = "true";
	document.getElementById("operacoesDiaForm:corretora").options[0].selected = "true";
	document.getElementById("operacoesDiaForm:categoria").options[0].selected = "true";
	// Limpar mensagens.
	removeMessages('operacoesDiaForm');
}


function limparOperacoesCDS() {
	document.getElementById("operacaoCDSForm:periodoInicio").value = "";
	document.getElementById("operacaoCDSForm:periodoInicio.day").value = "";
	document.getElementById("operacaoCDSForm:periodoInicio.month").value = "";
	document.getElementById("operacaoCDSForm:periodoInicio.year").value = "";
	document.getElementById("operacaoCDSForm:periodoFim").value = "";
	document.getElementById("operacaoCDSForm:periodoFim.day").value = "";
	document.getElementById("operacaoCDSForm:periodoFim.month").value = "";
	document.getElementById("operacaoCDSForm:periodoFim.year").value = "";
	document.getElementById("operacaoCDSForm:tipoAtivo").options[0].selected = "true";
	document.getElementById("operacaoCDSForm:ativo").options[0].selected = "true";
	document.getElementById("operacaoCDSForm:trava").options[0].selected = "true";
	document.getElementById("operacaoCDSForm:empresa").options[0].selected = "true";
	document.getElementById("operacaoCDSForm:filial").options[0].selected = "true";
	document.getElementById("operacaoCDSForm:corretora").options[0].selected = "true";
	document.getElementById("operacaoCDSForm:categoria").options[0].selected = "true";
	// Limpar mensagens.
	removeMessages('operacaoCDSForm');
}

function limparMovimentacaoEstoque() {
	document.getElementById("ConsultaMovimentacaoEstoqueForm:periodoInicio").value = "";
	document.getElementById("ConsultaMovimentacaoEstoqueForm:periodoInicio.day").value = "";
	document.getElementById("ConsultaMovimentacaoEstoqueForm:periodoInicio.month").value = "";
	document.getElementById("ConsultaMovimentacaoEstoqueForm:periodoInicio.year").value = "";
	document.getElementById("ConsultaMovimentacaoEstoqueForm:periodoFim").value = "";
	document.getElementById("ConsultaMovimentacaoEstoqueForm:periodoFim.day").value = "";
	document.getElementById("ConsultaMovimentacaoEstoqueForm:periodoFim.month").value = "";
	document.getElementById("ConsultaMovimentacaoEstoqueForm:periodoFim.year").value = "";
	document.getElementById("ConsultaMovimentacaoEstoqueForm:tipoAtivo").options[0].selected = "true";
	document.getElementById("ConsultaMovimentacaoEstoqueForm:ativo").options[0].selected = "true";
	document.getElementById("ConsultaMovimentacaoEstoqueForm:trava").options[0].selected = "true";
	document.getElementById("ConsultaMovimentacaoEstoqueForm:empresa").options[0].selected = "true";
	document.getElementById("ConsultaMovimentacaoEstoqueForm:filial").options[0].selected = "true";
	document.getElementById("ConsultaMovimentacaoEstoqueForm:corretora").options[0].selected = "true";
	document.getElementById("ConsultaMovimentacaoEstoqueForm:categoria").options[0].selected = "true";
	// Limpar mensagens.
	removeMessages('ConsultaMovimentacaoEstoqueForm');
}
function limparMovimentacaoEstoqueCaixa() {
	document.getElementById("ConsultaMovimentacaoEstoqueCaixaForm:periodoInicio").value = "";
	document.getElementById("ConsultaMovimentacaoEstoqueCaixaForm:periodoInicio.day").value = "";
	document.getElementById("ConsultaMovimentacaoEstoqueCaixaForm:periodoInicio.month").value = "";
	document.getElementById("ConsultaMovimentacaoEstoqueCaixaForm:periodoInicio.year").value = "";
	document.getElementById("ConsultaMovimentacaoEstoqueCaixaForm:periodoFim").value = "";
	document.getElementById("ConsultaMovimentacaoEstoqueCaixaForm:periodoFim.day").value = "";
	document.getElementById("ConsultaMovimentacaoEstoqueCaixaForm:periodoFim.month").value = "";
	document.getElementById("ConsultaMovimentacaoEstoqueCaixaForm:periodoFim.year").value = "";
	document.getElementById("ConsultaMovimentacaoEstoqueCaixaForm:tipoAtivo").options[0].selected = "true";
	document.getElementById("ConsultaMovimentacaoEstoqueCaixaForm:ativo").options[0].selected = "true";
	document.getElementById("ConsultaMovimentacaoEstoqueCaixaForm:trava").options[0].selected = "true";
	document.getElementById("ConsultaMovimentacaoEstoqueCaixaForm:empresa").options[0].selected = "true";
	document.getElementById("ConsultaMovimentacaoEstoqueCaixaForm:filial").options[0].selected = "true";
	document.getElementById("ConsultaMovimentacaoEstoqueCaixaForm:corretora").options[0].selected = "true";
	document.getElementById("ConsultaMovimentacaoEstoqueCaixaForm:categoria").options[0].selected = "true";
	// Limpar mensagens.
	removeMessages('ConsultaMovimentacaoEstoqueCaixaForm');
}

function limparConsulta() {
	document.getElementById("consultaForm:periodoInicio").value = "";
	document.getElementById("consultaForm:periodoInicio.day").value = "";
	document.getElementById("consultaForm:periodoInicio.month").value = "";
	document.getElementById("consultaForm:periodoInicio.year").value = "";
	document.getElementById("consultaForm:periodoFim").value = "";
	document.getElementById("consultaForm:periodoFim.day").value = "";
	document.getElementById("consultaForm:periodoFim.month").value = "";
	document.getElementById("consultaForm:periodoFim.year").value = "";
	document.getElementById("consultaForm:tipoAtivo").options[0].selected = "true";
	document.getElementById("consultaForm:ativo").options[0].selected = "true";
	document.getElementById("consultaForm:trava").options[0].selected = "true";
	document.getElementById("consultaForm:empresa").options[0].selected = "true";
	document.getElementById("consultaForm:filial").options[0].selected = "true";
	document.getElementById("consultaForm:corretora").options[0].selected = "true";
	document.getElementById("consultaForm:categoria").options[0].selected = "true";
	// Limpar mensagens.
	removeMessages('consultaForm');
}