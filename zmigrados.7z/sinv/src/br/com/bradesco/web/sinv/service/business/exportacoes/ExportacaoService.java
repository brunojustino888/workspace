package br.com.bradesco.web.sinv.service.business.exportacoes;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletResponse;

import br.com.bradesco.web.aq.application.util.FileUtils;
import br.com.bradesco.web.sinv.service.data.dataobject.exportacoes.ExportacaoDataObject;

@SuppressWarnings({"unchecked","rawtypes"})
public class ExportacaoService<DadosExportacao> implements IExportacaoService<ExportacaoDataObject<DadosExportacao>, DadosExportacao>{
	
	public void writeToDownloadStream(IExportacaoDataObjectStream exportacaoDataObjectStream, ExportacaoDataObject exportacaoDataObject) throws Exception {
		byte[] bytes = exportacaoDataObjectStream.getBytes(exportacaoDataObject);

		HttpServletResponse resp = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
		resp.setContentType(exportacaoDataObjectStream.getContentType().getValue());
		resp.setHeader("Content-Disposition", "attachment; filename=\"" + exportacaoDataObject.getNome()  + "\";");

		OutputStream out = resp.getOutputStream();
		out.write(bytes);
		out.flush();
		out.close();
		FacesContext.getCurrentInstance().responseComplete();
		
	}

	public void writeToFileStream(IExportacaoDataObjectStream exportacaoDataObjectStream, ExportacaoDataObject exportacaoDataObject, String path) throws Exception {
		String tempPathname = path + exportacaoDataObject.getNome() + ".tmp";
		File file = new File(path+ exportacaoDataObject.getNome());
		File fileTmp = new File(tempPathname);
		if(fileTmp.exists()){
			fileTmp.delete();
		}
		FileUtils.createIfNotExists(fileTmp);
		FileOutputStream fileOutputStream = new FileOutputStream(fileTmp);
		fileOutputStream.write(exportacaoDataObjectStream.getBytes(exportacaoDataObject));
		fileOutputStream.close();
		if(file.exists()){
			file.delete();
		}
		FileUtils.renameTo(tempPathname, path + exportacaoDataObject.getNome());
	}
}
