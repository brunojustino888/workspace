package br.com.bradesco.web.sinv.service.business.exportacoes;

import br.com.bradesco.web.sinv.service.data.dataobject.exportacoes.ExportacaoDataObject;


public interface IDadosExportacaoGetter <Vo, ExportacaoDO extends ExportacaoDataObject<DadosExportacao>, DadosExportacao>{

	public ExportacaoDO getDadosExportacao(Vo vo);
}