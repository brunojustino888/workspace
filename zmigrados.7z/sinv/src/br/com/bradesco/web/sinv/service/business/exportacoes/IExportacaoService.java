package br.com.bradesco.web.sinv.service.business.exportacoes;

import java.io.FileNotFoundException;
import java.io.IOException;

import br.com.bradesco.web.sinv.service.data.dataobject.exportacoes.ExportacaoDataObject;

@SuppressWarnings("rawtypes")
public interface IExportacaoService <ExportacaoDO extends ExportacaoDataObject<DadosExportacao>, DadosExportacao>{
	public void writeToDownloadStream(IExportacaoDataObjectStream exportacaoDataObjectStream, ExportacaoDO exportacaoDataObject) throws IOException, FileNotFoundException, Exception;

	public void writeToFileStream(IExportacaoDataObjectStream exportacaoDataObjectStream, ExportacaoDO exportacaoDataObject, String path) throws IOException, FileNotFoundException, Exception;
}
