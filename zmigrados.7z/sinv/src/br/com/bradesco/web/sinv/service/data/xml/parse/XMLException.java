/*
 * @(#)XMLException.java       1.0 02/03/2013
 *
 * Copyright (c) 2013 Bradesco S/A.
 * Osasco, SP - Brazil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bradesco S/A. ("Confidential Information").  You shall not disclose 
 * such Confidential Information and shall not use, publish, alter 
 * or otherwise make it available, directly or indirectly, without the prior 
 * written consent of Bradesco S/A.
 */
package br.com.bradesco.web.sinv.service.data.xml.parse;

/**
 * Exce��es retornada pelos Service Objects em caso de erro no acesso
 * ao banco de dados.
 * @author Jo�o Germano Filho
 * @version 1.0
 */
@SuppressWarnings("serial")
public class XMLException extends Exception {

    public XMLException(Exception e) {
        super(e);
    }

    public XMLException(String msg) {
        super(msg);
    }   
    
    public XMLException(String msg, Exception e) {
        super(msg, e);
    }
    
}
