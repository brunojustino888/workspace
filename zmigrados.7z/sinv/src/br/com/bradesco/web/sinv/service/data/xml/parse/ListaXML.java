/*
 * @(#)ListaXML.java               06/03/2013       
 *
 * Copyright (c) 2013 Bradesco.
 * Osasco, SP - Brazil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bradesco. ("Confidential Information").  You shall not disclose 
 * such Confidential Information and shall not use, publish, alter 
 * or otherwise make it available, directly or indirectly, without the prior 
 * written consent of InfoServer.
 */

package br.com.bradesco.web.sinv.service.data.xml.parse;

import java.util.ArrayList;
import java.util.List;

import br.com.bradesco.web.sinv.service.data.xml.model.XMLDataObject;

public class ListaXML {
    
    protected List<XMLDataObject> lista;
    
    public ListaXML(String fileName) throws ParserException {
        this.lista = new ArrayList<XMLDataObject>();
        this.recuperarLista(fileName);
    }

    protected void recuperarLista(String fileName) throws ParserException {
        
    }
    
    public int getListaSize(){
        return this.lista != null ? this.lista.size() : 0;
    }
    
    public String getTagCodigo(int index){
        String valor = null;
        if(this.lista != null){
            valor = this.lista.get(index).getTagCodigo();
        }
        return valor;
    }

    public String getTagDescricao(int index){
        String valor = null;
        if(this.lista != null){
            valor = this.lista.get(index).getTagDescricao();
        }
        return valor;
    }
    
    public String getTagClasse(int index){
        String valor = null;
        if(this.lista != null){
            valor = this.lista.get(index).getTagClasse();
        }
        return valor;
    }
    
    public String getTagTamanho(int index){
        String valor = null;
        if(this.lista != null){
            valor = this.lista.get(index).getTagTamanho();
        }
        return valor;
    }
    
    public boolean getTagStatus(int index){
        String valor = null;
        if(this.lista != null){
            valor = this.lista.get(index).getTagStatus();
        }
        return valor.equals("1");
    }
}
