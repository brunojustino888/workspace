/*
 * @(#)XMLDataObject.java               06/03/2013       
 *
 * Copyright (c) 2013 Bradesco.
 * Osasco, SP - Brazil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bradesco. ("Confidential Information").  You shall not disclose 
 * such Confidential Information and shall not use, publish, alter 
 * or otherwise make it available, directly or indirectly, without the prior 
 * written consent of InfoServer.
 */

package br.com.bradesco.web.sinv.service.data.xml.model;

public class XMLDataObject {

    private String tagCodigo;
    private String tagDescricao;
    private String tagClasse;
    private String tagTamanho;
    private String tagStatus;

    /**
     * @return the tagCodigo
     */
    public String getTagCodigo() {
        return tagCodigo;
    }

    /**
     * @param tagCodigo the tagCodigo to set
     */
    public void setTagCodigo(String tagCodigo) {
        this.tagCodigo = tagCodigo;
    }

    /**
     * @return the tagDescricao
     */
    public String getTagDescricao() {
        return tagDescricao;
    }

    /**
     * @param tagDescricao the tagDescricao to set
     */
    public void setTagDescricao(String tagDescricao) {
        this.tagDescricao = tagDescricao;
    }

    /**
     * @return the tagClasse
     */
    public String getTagClasse() {
        return tagClasse;
    }

    /**
     * @param tagClasse the tagClasse to set
     */
    public void setTagClasse(String tagClasse) {
        this.tagClasse = tagClasse;
    }

    /**
     * @return the tagTamanho
     */
    public String getTagTamanho() {
        return tagTamanho;
    }

    /**
     * @param tagTamanho the tagTamanho to set
     */
    public void setTagTamanho(String tagTamanho) {
        this.tagTamanho = tagTamanho;
    }

    /**
     * @return the tagStatus
     */
    public String getTagStatus() {
        return tagStatus;
    }

    /**
     * @param tagStatus the tagStatus to set
     */
    public void setTagStatus(String tagStatus) {
        this.tagStatus = tagStatus;
    }

}
