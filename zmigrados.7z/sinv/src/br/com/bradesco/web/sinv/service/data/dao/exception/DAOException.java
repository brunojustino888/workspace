/*
 * @(#)DaoException.java       1.0 20/09/2004
 *
 * Copyright (c) 2004 Bradesco S/A.
 * Osasco, SP - Brazil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bradesco S/A. ("Confidential Information").  You shall not disclose 
 * such Confidential Information and shall not use, publish, alter 
 * or otherwise make it available, directly or indirectly, without the prior 
 * written consent of Bradesco S/A.
 */

package br.com.bradesco.web.sinv.service.data.dao.exception;

/**
 * Exce��es retornada pelos Data Access Objects em caso de erro no acesso
 * ao banco de dados.
 *
 * @author Jo�o Germano Filho
 * @version 1.0
 */
public class DAOException extends Exception {

	private static final long serialVersionUID = 8841408003033779866L;

	/** Cria uma nova inst�ncia de DaoException. */
    public DAOException() {
        super();
    }

    /** Cria uma nova inst�ncia de DaoException. */
    public DAOException( String msg ) {
        super( msg );
    }

    /** Cria uma nova inst�ncia de DaoException. */
    public DAOException( Exception e ) {
        super( (e == null) ? null : e.toString() );
    }
}