package br.com.bradesco.web.sinv.service.data.dataobject;

import java.io.Serializable;

public class BaseDataObject implements Serializable {

	private static final long serialVersionUID = -6872259834215561816L;
	/** C�DIGO DO STATUS */
	private String status;
	/** C�DIGO DO ERRO */
	private int codigoErro;
	/** DESCRI��O DO ERRO */
	private String descricaoErro;
	
	/** CONSTANTE STATUS INCLUIR */
	public static final String STATUS_INCLUIR = "I";
	/** CONSTANTE STATUS EXCLUIR */
	public static final String STATUS_EXCLUIR = "E";
	/** CONSTANTE STATUS SALVAR */
	public static final String STATUS_ALTERAR = "A";
	
	protected int codigo;
	protected String descricao;

	/**
	 * @return the codigo
	 */
	public int getCodigo() {
		return codigo;
	}
	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}
	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the codigoErro
	 */
	public int getCodigoErro() {
		return codigoErro;
	}
	/**
	 * @param codigoErro the codigoErro to set
	 */
	public void setCodigoErro(int codigoErro) {
		this.codigoErro = codigoErro;
	}
	/**
	 * @return the descricaoErro
	 */
	public String getDescricaoErro() {
		return descricaoErro;
	}
	/**
	 * @param descricaoErro the descricaoErro to set
	 */
	public void setDescricaoErro(String descricaoErro) {
		this.descricaoErro = descricaoErro;
	}
	
}
