package br.com.bradesco.web.sinv.view.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

public class UploadMultipartFilter implements Filter{

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) 
							throws IOException, ServletException {
	
		HttpServletRequest hRequest = (HttpServletRequest)request;
		
		boolean isMultipart = (hRequest.getHeader("content-type") != null && 
							   hRequest.getHeader("content-type").indexOf("multipart/form-data") != -1); 
  
		if(!isMultipart){
			chain.doFilter(request,response);
		}else{
			UploadMultipartRequestWrapper wrapper = new UploadMultipartRequestWrapper(hRequest);
			chain.doFilter(wrapper,response);
		}
	}

	public void destroy() {}
	public void init(FilterConfig config) throws ServletException {}
	
}