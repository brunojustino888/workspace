/*
* =========================================================================
* 
* Client:       Bradesco (BR)
* Project:      Bradesco ShopCredit
* Development:  GFT Iberia (http://www.gft.com)
* -------------------------------------------------------------------------
* Revision - Last:
* $Source: \Repositorio\TIMelhorias_IT\Projetos/ShopCredit/JavaSource/br/com/bradesco/web/shopcredit/service/provider/log/helper/ContextoLogConstant.java,v $
* $Id: ContextoLogConstant.java,v 1.14 2008/04/25 20:04:00 cpm.com.br\vinicius.bonifacio Exp $
* $State: Exp $
* -------------------------------------------------------------------------
* Revision - History:
* $Log: ContextoLogConstant.java,v $
* Revision 1.14  2008/04/25 20:04:00  cpm.com.br\vinicius.bonifacio
* Ajustes de checkstyle
*
* Revision 1.13  2008/03/12 20:50:09  cpm.com.br\melissa.kato
* Implementa��o log.
*
* Revision 1.12  2008/02/26 17:23:50  cpm.com.br\melissa.kato
* Implementa��o do log.
*
* Revision 1.11  2008/01/07 17:44:17  cpm.com.br\melissa.kato
* Altera��o do layout do log.
*
* Revision 1.10  2007/11/08 21:19:54  cpm.com.br\jane.soares
* Ajuste no import da classe ShopCreditPdcBaseAdapter
*
* Revision 1.9  2007/11/07 21:39:09  cpm.com.br\jane.soares
* Jane Soares: Implementa�ao do log
*
* Revision 1.8  2007/10/23 18:56:42  cpm.com.br\jane.soares
* Jane Soares: Implementa�ao do log
*
* Revision 1.7  2007/10/22 12:05:00  cpm.com.br\jane.soares
* Jane Soares: Implementa�ao do log
*
* Revision 1.6  2007/10/18 19:39:22  cpm.com.br\ricardo.zanini
* JaneSoares: Implementa��o do Log
*
* Revision 1.5  2007/10/18 17:15:54  cpm.com.br\ricardo.zanini
* JaneSoares: Implementa��o do Log
*
* Revision 1.4  2007/10/11 14:56:04  cpm.com.br\ricardo.zanini
* JASO: aqueda��o log
*
* Revision 1.3  2007/10/10 22:01:56  cpm.com.br\ricardo.zanini
* JASO: Altera��o para adequar ao novo layout de log
*
* Revision 1.2  2007/10/09 16:32:55  cpm.com.br\ricardo.zanini
* Jane Soares
*
* Revision 1.1  2007/05/15 18:35:41  cpm.com.br\ricardo.zanini
* in�cio projeto ShopCredit - Arquitetura inicial
*
*
* =========================================================================
*/

package br.com.bradesco.web.sinv.service.provider.log.helper;

/**
 * 
* <p><b>Title:</b>        Bradesco ShopCredit.</p>
* <p><b>Description:</b></p>
* <p>Interface de constantes que indican los caracteres de
* layout de Log de ShopCredit.</p>
* 
* @author       GFT Iberia Solutions / Emagine <BR/>
* copyright Copyright (c) 2006 <BR/>
* created   10-nov-2006 <BR/>
* @version      1.0
 */
public class ContextoLogConstant {

    /**
     * CTE con el nombre del atributo que contiene el contexto de traza de log
     * de tipo 'STTRANS' en el scope X.
     */
    public static final String CONTEXTO_TRANSACAO_ATTRIBUTE = "contextoTransacao";
    
    /**
     * CTE con el nombre del atributo que contiene el contexto de traza de log
     * de tipo 'ERRO' en el scope X.
     */
    public static final String CONTEXTO_ERRO_ATTRIBUTE = "contextoErro";
    
    /**
     * CTE con el nombre del atributo que contiene el contexto de traza de log
     * de tipo 'PAGINA' en el scope X.
     */
    public static final String CONTEXTO_PAGINA_ATTRIBUTE = "contextoPagina";
    
    /**
     * CTE con el nombre del atributo que contiene el contexto de traza de log
     * de tipo 'SESSAO' en el scope X.
     */
    public static final String CONTEXTO_SESSAO_ATTRIBUTE = "contextoSessao";
    
    /**
     * Cte con el caracter de layout correspondiente al campo <transacao> del registro de
     * Log tipo 'STTRANS'.
     */
    public static final String CAMADA_ERRO = "camada";
    
    /**
     * 
     */
    public static final String INSTRUCAO_ERRO = "instrucao";
    
    /**
     * 
     */
    public static final String CODIGO_SERVICO = "codigoServico";
    
    /**
     * 
     */
    public static final String CODIGO_RETORNO_TRANSACAO_ERRO = "codigoRetorno";
    
    /**
     * 
     */
    public static final String MENSAGEM_ERRO = "mensagemErro";
    
    /**
     * 
     */
    public static final String FLAG_ERRO_NEGOCIO = "flagErroNegocio";

    /**
     * 
     */
    public static final String FLAG_ERRO_TECNICO = "flagErroTecnico";

    
    /**
     * 
     */
    public static final String ERRO_COMUNICACAO = "erroComunicacao";
    
    /**
     * 
     */
    public static final String PARAMETROS_MENSAGEM_TRANSACAO = "parametrosMensagemTransacao";
    
    /**
     * 
     */
    public static final String MENSAGEM_SUCESSO_TRANSACAO = "mensagemSucesso";
  
    /**
     * 
     */
    public static final String PAGINA_DESCRICAO = "paginaDescricao";
    
    /**
     * 
     */
    public static final String PAGINA_STATUS = "paginaStatus";
    
    /**
     * 
     */
    public static final String ERRO_REPORTADO = "erroReportado";
    
    /**
     * 
     */
    public static final String PAGINA_ANTERIOR_DESCRICAO = "paginaAnteriorDescricao";
    
    /**
     * 
     */
    public static final String PARAMETROS_REQUEST = "parametrosRequest";
    
    /**
     * 
     */
    public static final String ROTINA_EXECUTADA = "rotinaExecutada";

    /**
     * 
     */
    public static final String FUNCAO_EXECUTADA = "funcaoExecutada";

    
    /**
     * 
     */
    public static final String NOME_PROCESSO = "nomeProcesso";
    
    
    /**
     * 
     */
    public static final String NOME_METODO = "nomeMetodo";
    
    /**
     * Constante que representa a mensagem retorna pela transa��o executada.
     */
    public static final String ERROR_MESSAGE_INTERNAL = "mensagemErroInterna";
    
    /**
     * Constante que representa o ticket utilizado no framework online.
     */
    public static final String TICKET = "ticketFramework";

    /**
     * 
     * Construtor.
     *
     */
    public ContextoLogConstant() {
        super();
    }
    
    
}
