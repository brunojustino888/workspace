package br.com.bradesco.web.sinv.service.data.dataobject.geral;

public class TipoMoedaDataObject {
	
	private int codigoMoeda;
	private String tipoMoeda;
	
	public int getCodigoMoeda() {
		return codigoMoeda;
	}
	public void setCodigoMoeda(int codigoMoeda) {
		this.codigoMoeda = codigoMoeda;
	}
	public String getTipoMoeda() {
		return tipoMoeda;
	}
	public void setTipoMoeda(String tipoMoeda) {
		this.tipoMoeda = tipoMoeda;
	}
	

}
