/*
* =========================================================================
* 
* Client:       Bradesco (BR)
* Project:      Bradesco ShopCredit
* Development:  GFT Iberia (http://www.gft.com)
* -------------------------------------------------------------------------
* Revision - Last:
* $Source: \Repositorio\TIMelhorias_IT\Projetos/ShopCredit/JavaSource/br/com/bradesco/web/shopcredit/service/provider/log/contexto/ErroContextLog.java,v $
* $Id: ErroContextLog.java,v 1.1 2007/05/15 18:35:49 cpm.com.br\ricardo.zanini Exp $
* $State: Exp $
* -------------------------------------------------------------------------
* Revision - History:
* $Log: ErroContextLog.java,v $
* Revision 1.1  2007/05/15 18:35:49  cpm.com.br\ricardo.zanini
* in�cio projeto ShopCredit - Arquitetura inicial
*
*
* =========================================================================
*/

package br.com.bradesco.web.sinv.service.provider.log.contexto;

import br.com.bradesco.web.aq.application.log.helper.ContextLog;

/**
 * 
* <p><b>Title:</b>        Bradesco ShopCredit.</p>
* <p><b>Description:</b></p>
* <p>Contexto de Log para la generacion de un registro tipo 'ERRO'.</p>
* 
* @author       GFT Iberia Solutions / Emagine <BR/>
* copyright Copyright (c) 2006 <BR/>
* created   23-nov-2006 <BR/>
* @version      1.0
 */
public class ErroContextLog extends ContextLog {
    
    /**
     * CTE que indica el que tipo de log se usa este contexto.
     */
    private static final String LOG_TYPE_ID = "ERRO";
    
    /**
     * 
     * Constructor por defecto.
     *
     */
    public ErroContextLog() {
        super(LOG_TYPE_ID);
    }
}
