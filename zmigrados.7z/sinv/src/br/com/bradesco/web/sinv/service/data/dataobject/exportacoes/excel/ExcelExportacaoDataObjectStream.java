package br.com.bradesco.web.sinv.service.data.dataobject.exportacoes.excel;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.hssf.util.Region;

import br.com.bradesco.web.sinv.service.business.exportacoes.IExportacaoDataObjectStream;
import br.com.bradesco.web.sinv.service.data.dataobject.exportacoes.DadosExportacaoDataObject;
import br.com.bradesco.web.sinv.service.data.dataobject.exportacoes.ExportacaoDataObject;
import br.com.bradesco.web.sinv.service.data.dataobject.exportacoes.RegistroDeExportacao;

public class ExcelExportacaoDataObjectStream implements IExportacaoDataObjectStream<ExportacaoDataObject<DadosExportacaoDataObject>, DadosExportacaoDataObject>
{
	
	private HSSFWorkbook work;

	private int rowCount = 1;

	private HSSFPalette workBookPalette;

	private HSSFCellStyle contentStyle;

	private HSSFFont contentFont;

	private HSSFCellStyle headerStyle;

	private HSSFFont headerFont;

	private HSSFFont titleFont;

	private HSSFCellStyle titleStyle;
	
	private HSSFWorkbook getWorkBook(){
		if (this.work == null) {
			this.work  = new HSSFWorkbook();
		}
		return this.work ;
	}
	
	private HSSFCellStyle getTitleStyle() {
		if (titleStyle == null) {
			titleStyle = getWorkBook().createCellStyle();
			titleStyle.setFillForegroundColor(HSSFColor.RED.index);
			titleStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			titleStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			titleStyle.setFont(getTitleFont());
		}
		return titleStyle;
	}

	private HSSFFont getTitleFont() {
		if (titleFont == null) {
			titleFont = getWorkBook().createFont();
			titleFont.setFontName("verdana");
			titleFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			titleFont.setFontHeightInPoints((short)11);
			titleFont.setColor(HSSFColor.WHITE.index);
		}
		return titleFont;
	}

	public byte[] getBytes(ExportacaoDataObject<DadosExportacaoDataObject> exportacaoDataObject) throws Exception
	{
		for (DadosExportacaoDataObject dadosExportacaoDataObject : exportacaoDataObject.getListaDeDadosExportacao()) {
			HSSFSheet sheet = createSheet(dadosExportacaoDataObject);
			createMergedTitle(sheet, dadosExportacaoDataObject.getTitulo(), dadosExportacaoDataObject.getCabecalho().getQuantidadeColunas());
	
			createHeaderColumns(sheet, dadosExportacaoDataObject.getCabecalho());
			
			createContentColumns(sheet, dadosExportacaoDataObject.getRegistros());
		}
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		getWorkBook().write(baos);
		return baos.toByteArray();
	}

	private void createContentColumns(HSSFSheet sheet, List<RegistroDeExportacao> contents) throws IOException, FileNotFoundException {
		getWorkBookPalette().setColorAtIndex(HSSFColor.BLACK.index, (byte)51, (byte)51, (byte)51);
		
		for (RegistroDeExportacao linhaRelatorio : contents) {
			HSSFRow row = createRow(sheet);
			int columnCount = 0;
			for (Object columnContent : linhaRelatorio.getConteudo()) {
				
				if(columnContent == null) {
					columnContent = "";
				}
				HSSFCell cell = createCell(row, columnCount);
				if (columnContent instanceof BigDecimal) {
					cell.setCellValue(((BigDecimal)columnContent).doubleValue());
				} else if (columnContent instanceof Double) {
					cell.setCellValue(((Double)columnContent).doubleValue());
				} else if (columnContent instanceof Date) {
					cell.setCellValue(((Date)columnContent));
				} else if (columnContent instanceof Calendar) {
					cell.setCellValue(((Calendar)columnContent));
				} else if (columnContent instanceof String) {
					cell.setCellValue(((String)columnContent).trim());
				} else {
					cell.setCellValue(columnContent.toString().trim());
				}
				
				cell.setCellStyle(getContentStyle());
				
				int columnWidth = columnContent.toString().trim().length() * 400;
				int currentWidth = sheet.getColumnWidth(columnCount);
				if(columnWidth > currentWidth) {
					sheet.setColumnWidth(columnCount, (short)columnWidth);		
				}
				columnCount++;
			}
		}
	}

	private void createHeaderColumns(HSSFSheet sheet, RegistroDeExportacao conteudo) {
		getWorkBookPalette().setColorAtIndex(HSSFColor.GREY_80_PERCENT.index, (byte)206, (byte)206, (byte)206);
		getWorkBookPalette().setColorAtIndex(HSSFColor.GREY_50_PERCENT.index, (byte)104, (byte)98, (byte)98);
		
		HSSFRow row = createRow(sheet);
		short columnCount = 0;
		for (Object columnContent : conteudo.getConteudo()) {
			HSSFCell cell = createCell(row, columnCount);
			cell.setCellValue(columnContent.toString().trim());
			cell.setCellStyle(getCabecalhoStyle());
			sheet.setColumnWidth(columnCount, (columnContent.toString().trim().length() * 400));
			columnCount++;
		}
	}

	private HSSFCell createCell(HSSFRow row, int column) {
		return row.createCell(column);
	}

	private HSSFSheet createSheet(DadosExportacaoDataObject dadosExportacaoDataObject) {
		rowCount = 0;
		return getWorkBook().createSheet(dadosExportacaoDataObject.getNome());
	}

	@SuppressWarnings("deprecation")
	private void createMergedTitle(HSSFSheet sheet, String title, int qtdColunas) {
		HSSFRow row = createRow(sheet);
		HSSFCell cell = createCell(row, 0);
		cell.setCellStyle(getTitleStyle());
		cell.setCellValue(title);
		Region region = new Region(0, (short)0, 0, (short)(qtdColunas - 1));
		sheet.addMergedRegion(region);
		getWorkBookPalette().setColorAtIndex(HSSFColor.RED.index, (byte)153, (byte)0, (byte)0);
	}

	private HSSFPalette getWorkBookPalette() {
		if (workBookPalette == null) {
			workBookPalette = getWorkBook().getCustomPalette();
		}
		return workBookPalette;
	}

	private HSSFRow createRow(HSSFSheet sheet) {
		return sheet.createRow(rowCount++);
	}
	
	
	private HSSFCellStyle getContentStyle() {
		if (contentStyle == null) {
			contentStyle = getWorkBook().createCellStyle();
			contentStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			contentStyle.setBottomBorderColor(HSSFColor.RED.index);
			contentStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			contentStyle.setFont(getContentFont());
		}
		return contentStyle;
	}

	private HSSFFont getContentFont() {
		if (contentFont == null) {
			contentFont = getWorkBook().createFont();
			contentFont.setFontName("verdana");
			contentFont.setFontHeightInPoints((short)9);
			contentFont.setColor(HSSFColor.BLACK.index);
		}
		return contentFont;
	}

	private HSSFCellStyle getCabecalhoStyle() {
		if (headerStyle == null) {
			headerStyle = getWorkBook().createCellStyle();
			headerStyle.setFillForegroundColor(HSSFColor.GREY_80_PERCENT.index);
			headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			headerStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			headerStyle.setTopBorderColor(HSSFColor.WHITE.index);
			headerStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
			headerStyle.setBottomBorderColor(HSSFColor.RED.index);
			headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			headerStyle.setFont(getCabecalhoFont());
		}			
		return headerStyle;
	}

	private HSSFFont getCabecalhoFont() {
		if (headerFont == null) {
			headerFont = getWorkBook().createFont();
			headerFont.setFontName("verdana");
			headerFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			headerFont.setFontHeightInPoints((short)9);
			headerFont.setColor(HSSFColor.GREY_50_PERCENT.index);
		}
		return headerFont;
	}

	public ContentTypeEnum getContentType() {
		return ContentTypeEnum.PLANILHA;
	}
	
}
