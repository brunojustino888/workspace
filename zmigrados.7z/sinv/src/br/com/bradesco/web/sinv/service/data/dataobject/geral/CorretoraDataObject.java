/* @(#)CorretoraDataObject.java              05/12/2013     
 *
 * Copyright (c) 2013 Bradesco.
 * Osasco, SP - Brazil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bradesco. ("Confidential Information").  You shall not disclose 
 * such Confidential Information and shall not use, publish, alter 
 * or otherwise make it available, directly or indirectly, without the prior 
 * written consent of InfoServer.
 */
package br.com.bradesco.web.sinv.service.data.dataobject.geral;

import java.math.BigDecimal;

import br.com.bradesco.web.sinv.service.data.dataobject.BaseDataObject;

/**
 * @author InfoSERVER - Lucas Verdi Carnevalli
 */
@SuppressWarnings("serial")
public class CorretoraDataObject extends BaseDataObject implements Comparable<CorretoraDataObject> {
	
	 private 	int		codigoBolsa;
	 private 	int 	codigoCorretora;
	 private	String	descricaoCorretora;
	 private	int		situacaoCorretora;
	 private	BigDecimal	operacaoBMF;
	 private	BigDecimal	operacaoBovespa;
	 private	BigDecimal	devolucao;
	 private	BigDecimal	restricaoOperacao;
	 private	String	codigoBloomberg;
	 
	 
    public int compareTo(CorretoraDataObject o) {
        return this.descricao.compareTo(o.descricao);
    }




	public String getCodigoBloomberg() {
		return codigoBloomberg;
	}




	public void setCodigoBloomberg(String codigoBloomberg) {
		this.codigoBloomberg = codigoBloomberg;
	}




	public int getCodigoCorretora() {
		return codigoCorretora;
	}




	public void setCodigoCorretora(int codigoCorretora) {
		this.codigoCorretora = codigoCorretora;
	}





	public BigDecimal getDevolucao() {
		return devolucao;
	}




	public void setDevolucao(BigDecimal devolucao) {
		this.devolucao = devolucao;
	}




	public String getDescricaoCorretora() {
		return descricaoCorretora;
	}




	public void setDescricaoCorretora(String descricaoCorretora) {
		this.descricaoCorretora = descricaoCorretora;
	}




	public BigDecimal getOperacaoBMF() {
		return operacaoBMF;
	}




	public void setOperacaoBMF(BigDecimal operacaoBMF) {
		this.operacaoBMF = operacaoBMF;
	}




	public BigDecimal getOperacaoBovespa() {
		return operacaoBovespa;
	}




	public void setOperacaoBovespa(BigDecimal operacaoBovespa) {
		this.operacaoBovespa = operacaoBovespa;
	}




	public BigDecimal getRestricaoOperacao() {
		return restricaoOperacao;
	}




	public void setRestricaoOperacao(BigDecimal restricaoOperacao) {
		this.restricaoOperacao = restricaoOperacao;
	}




	public int getSituacaoCorretora() {
		return situacaoCorretora;
	}




	public void setSituacaoCorretora(int situacaoCorretora) {
		this.situacaoCorretora = situacaoCorretora;
	}




	public int getCodigoBolsa() {
		return codigoBolsa;
	}




	public void setCodigoBolsa(int codigoBolsa) {
		this.codigoBolsa = codigoBolsa;
	}

	
}
