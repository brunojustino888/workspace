package br.com.bradesco.web.sinv.service.data.dataobject.geral;

public class TipoCarteiraDataObject {
	
	private int codigoCarteira;
	private String tipoCarteira;
	
	public int getCodigoCarteira() {
		return codigoCarteira;
	}
	public void setCodigoCarteira(int codigoCarteira) {
		this.codigoCarteira = codigoCarteira;
	}
	public String getTipoCarteira() {
		return tipoCarteira;
	}
	public void setTipoCarteira(String tipoCarteira) {
		this.tipoCarteira = tipoCarteira;
	}
	

}
