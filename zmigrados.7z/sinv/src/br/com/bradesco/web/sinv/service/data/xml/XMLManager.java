/*
 * @(#)XMLManager.java       1.0 02/03/2013
 *
 * Copyright (c) 2013 Bradesco S/A.
 * Osasco, SP - Brazil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bradesco S/A. ("Confidential Information").  You shall not disclose 
 * such Confidential Information and shall not use, publish, alter 
 * or otherwise make it available, directly or indirectly, without the prior 
 * written consent of Bradesco S/A.
 */
package br.com.bradesco.web.sinv.service.data.xml;

import br.com.bradesco.web.sinv.service.data.xml.parse.ListaXML;
import br.com.bradesco.web.sinv.service.data.xml.parse.ListaXMLParser;
import br.com.bradesco.web.sinv.service.data.xml.parse.XMLException;

public class XMLManager {
    
    public static final int  LISTA_ESTOQUE = 1;
    public static final int  LISTA_ESTOQUE_CONTABIL = 2;
    public static final int  LISTA_OPERACAO_DIA = 3;
    public static final int  LISTA_OPERACAO_CDS = 4;
    public static final int  LISTA_PARAMETRIZACAO_BTLI = 5;
    public static final int  LISTA_DETALHE_FLUXO_OP_CDS = 6;
    public static final int  LISTA_ARBITRAGEM_MOEDA = 7;
    
    private static final String FILE_ESTOQUE = "Estoque.xml";
    private static final String FILE_ESTOQUE_CONTABIL= "EstoqueContabil.xml";
    private static final String FILE_OPERACAO_DIA = "OperacaoDia.xml";
    private static final String FILE_OPERACAO_CDS = "OperacaoCds.xml";
    private static final String FILE_PARAMETRIZACAO_BTLI = "ParametrizacaoBTLI.xml";
    private static final String FILE_DETALHE_FLUXO_OP_CDS = "DetalheFluxoOperacaoCDS.xml";
    private static final String FILE_ARBITRAGEM_MOEDA = "ArbitragemMoeda.xml";
    
    public static ListaXML recuperarLista(int idLista) throws XMLException {
        ListaXML service = null;
        try {
            //Recuperar 
            service =  getListaService(idLista);
        } catch (Exception e) {
            throw new XMLException(e);
        }
        return service;
    }

    private static ListaXML getListaService(int idLista) throws XMLException {
        ListaXML service = null;
        String fileName = getFileName(idLista);
        try {
            service = new ListaXMLParser(fileName);
        } catch (Exception e) {
            throw new XMLException("Problemas ao recuperar tipo de servi�o");
        }
        return service;
    }

    private static String getFileName(int idLista) {
        String fileName = FILE_ESTOQUE;
        switch (idLista) {
        case LISTA_ESTOQUE:
            fileName = FILE_ESTOQUE;
            break;
        case LISTA_ESTOQUE_CONTABIL:
            fileName = FILE_ESTOQUE_CONTABIL;
            break;
        case LISTA_OPERACAO_DIA:
            fileName = FILE_OPERACAO_DIA;
            break;      
        case LISTA_OPERACAO_CDS:
            fileName = FILE_OPERACAO_CDS;
            break;   
        case LISTA_PARAMETRIZACAO_BTLI:
            fileName = FILE_PARAMETRIZACAO_BTLI;
            break; 
        case LISTA_DETALHE_FLUXO_OP_CDS:
        	fileName =  FILE_DETALHE_FLUXO_OP_CDS;
        	break;
        case LISTA_ARBITRAGEM_MOEDA:
        	fileName =  FILE_ARBITRAGEM_MOEDA;
        	break;
        default:
            fileName = FILE_OPERACAO_DIA;
            break;
        }
        return fileName;
    }
}
