package br.com.bradesco.web.sinv.exception;

import br.com.bradesco.web.aq.application.error.BradescoApplicationException;

public class SINVException extends BradescoApplicationException {
 
	private static final long serialVersionUID = -2744808697377163713L;

	public SINVException() {
        super();
    }

    public SINVException(String arg0) { 
        super(arg0);
    }

    public SINVException(String arg0, Throwable arg1) {
        super(arg0, arg1);
    }

    public SINVException(Throwable arg0) {
        super(arg0);
    }
    
    public SINVException(String message, Throwable cause, String code) {
        super(message, cause, code);
        setInstrucao(SINVExceptionConstants.INSTRUCAO_EXCEPCAO_GERAL);
        setLogLevel(DEFAULT_LOG_LEVEL);
        setLoggable(DEFAULT_LOGGABLE);
    } 

}
