/*
 * @(#)ParserException.java       1.0 02/03/2013
 *
 * Copyright (c) 2013 Bradesco S/A.
 * Osasco, SP - Brazil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bradesco S/A. ("Confidential Information").  You shall not disclose 
 * such Confidential Information and shall not use, publish, alter 
 * or otherwise make it available, directly or indirectly, without the prior 
 * written consent of Bradesco S/A.
 */
package br.com.bradesco.web.sinv.service.data.xml.parse;

/**
 * Exce��es retornada pelos Parser Objects em caso de erro no acesso
 * ao banco de dados.
 *
 * @author Jo�o Germano Filho
 * @version 1.0
 */
public class ParserException extends Exception {

    private static final long serialVersionUID = -7728385179281455910L;

    public ParserException(Exception e) {
        super(e);
    }

    public ParserException(String msg) {
        super(msg);
    }   
    
    public ParserException(String msg, Exception e) {
        super(msg, e);
    }

}

