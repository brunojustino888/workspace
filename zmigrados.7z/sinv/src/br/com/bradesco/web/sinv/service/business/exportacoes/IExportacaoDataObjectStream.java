package br.com.bradesco.web.sinv.service.business.exportacoes;

import br.com.bradesco.web.sinv.service.data.dataobject.exportacoes.ExportacaoDataObject;

public interface IExportacaoDataObjectStream <ExportacaoDO extends ExportacaoDataObject<DadosExportacao>, DadosExportacao> {

	public enum ContentTypeEnum{
		PLANILHA("application/xls"),
		TEXTO("plain/text"), 
		PDF("application/pdf");
		
		private String value;

		private ContentTypeEnum(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}
	}
	
	ContentTypeEnum getContentType();
	
	byte[] getBytes(ExportacaoDO exportacaoDataObject) throws Exception;

}
