/*
 * @(#)ListaXMLParser.java               06/03/2013       
 *
 * Copyright (c) 2013 Bradesco.
 * Osasco, SP - Brazil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bradesco. ("Confidential Information").  You shall not disclose 
 * such Confidential Information and shall not use, publish, alter 
 * or otherwise make it available, directly or indirectly, without the prior 
 * written consent of InfoServer.
 */

package br.com.bradesco.web.sinv.service.data.xml.parse;

import java.io.InputStream;

import org.apache.commons.digester.Digester;

import br.com.bradesco.web.sinv.service.data.xml.file.FileXML;
import br.com.bradesco.web.sinv.service.data.xml.model.XMLDataObject;

public class ListaXMLParser extends ListaXML {

     public ListaXMLParser(String fileName) throws ParserException {
        super(fileName);
    }

     protected void recuperarLista(String fileName) throws ParserException {
        String fileURL =  fileName;
        try {
        	String tagCabecalho = "tagList/tag";
            Digester digester = new Digester();
            digester.push(this.lista);
            digester.setValidating(false);
            digester.addObjectCreate(tagCabecalho, XMLDataObject.class);
            digester.addBeanPropertySetter(tagCabecalho + "/tagCodigo", "tagCodigo");
            digester.addBeanPropertySetter(tagCabecalho + "/tagDescricao", "tagDescricao");
            digester.addBeanPropertySetter(tagCabecalho + "/tagClasse", "tagClasse");
            digester.addBeanPropertySetter(tagCabecalho + "/tagTamanho", "tagTamanho");
            digester.addBeanPropertySetter(tagCabecalho + "/tagStatus", "tagStatus");
            digester.addSetNext(tagCabecalho, "add");
            digester.parse(this.getFileUrl(fileName));
        } catch (Exception e1) {
            throw new ParserException("Problemas no Parse do Arquivo: " + fileURL + " - " + e1.getMessage(), e1);
        }
    }

    private InputStream getFileUrl(String fileName) throws ParserException {
        InputStream in = FileXML.class.getResourceAsStream(fileName);
        return in;
    }
    
}
