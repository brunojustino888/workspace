/*
 * EmpresaDataObject.java       1.0 10/02/2014
 *
 * Copyright (c) 2013 Bradesco S/A.
 * Osasco, SP - Brazil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bradesco S/A. ("Confidential Information").  You shall not disclose 
 * such Confidential Information and shall not use, publish, alter 
 * or otherwise make it available, directly or indirectly, without the prior 
 * written consent of Bradesco S/A.
 */
package br.com.bradesco.web.sinv.service.data.dataobject.geral;

import java.math.BigDecimal;

import br.com.bradesco.web.sinv.service.data.dataobject.BaseDataObject;

/**
 * @author InfoSERVER - Jo�o Germano Filho
 */
@SuppressWarnings("serial")
public class EmpresaDataObject extends BaseDataObject implements Comparable<EmpresaDataObject> {
	private int IdEmpresa;
	private String tipoEmpresa;
	private String NmEmpresa;	
	private String RazaoSocial;	
	private int Cnpj;
	private int CnpjFilial;	
	private int CnpjDigitoControle;	
	private String Endereco;	
	private String	Cidade;	
	private String Estado;	
	private String Cep;	
	private String Telefone;	
	private int TpMediaMovel;	
	private int IdSisbacen;	
	private int IdBmf;	
	private String	NmTrader;	
	private int FaixaInicialNrComando;	
	private int codClienteBMF;
	private BigDecimal idBancoTEMA;	
	private BigDecimal codParticipanteBMF;	
	
	    
    public int compareTo(EmpresaDataObject o) {
        return this.descricao.compareTo(o.descricao);
    }


	public String getCep() {
		return Cep;
	}


	public void setCep(String cep) {
		Cep = cep;
	}


	public String getCidade() {
		return Cidade;
	}


	public void setCidade(String cidade) {
		Cidade = cidade;
	}


	public int getCnpj() {
		return Cnpj;
	}


	public void setCnpj(int cnpj) {
		Cnpj = cnpj;
	}


	public int getCnpjDigitoControle() {
		return CnpjDigitoControle;
	}


	public void setCnpjDigitoControle(int cnpjDigitoControle) {
		CnpjDigitoControle = cnpjDigitoControle;
	}


	public int getCnpjFilial() {
		return CnpjFilial;
	}


	public void setCnpjFilial(int cnpjFilial) {
		CnpjFilial = cnpjFilial;
	}


	public int getCodClienteBMF() {
		return codClienteBMF;
	}


	public void setCodClienteBMF(int codClienteBMF) {
		this.codClienteBMF = codClienteBMF;
	}


	public BigDecimal getCodParticipanteBMF() {
		return codParticipanteBMF;
	}


	public void setCodParticipanteBMF(BigDecimal codParticipanteBMF) {
		this.codParticipanteBMF = codParticipanteBMF;
	}


	public String getEndereco() {
		return Endereco;
	}


	public void setEndereco(String endereco) {
		Endereco = endereco;
	}


	public String getEstado() {
		return Estado;
	}


	public void setEstado(String estado) {
		Estado = estado;
	}


	public int getFaixaInicialNrComando() {
		return FaixaInicialNrComando;
	}


	public void setFaixaInicialNrComando(int faixaInicialNrComando) {
		FaixaInicialNrComando = faixaInicialNrComando;
	}


	public BigDecimal getIdBancoTEMA() {
		return idBancoTEMA;
	}


	public void setIdBancoTEMA(BigDecimal idBancoTEMA) {
		this.idBancoTEMA = idBancoTEMA;
	}


	public int getIdBmf() {
		return IdBmf;
	}


	public void setIdBmf(int idBmf) {
		IdBmf = idBmf;
	}


	public int getIdEmpresa() {
		return IdEmpresa;
	}


	public void setIdEmpresa(int idEmpresa) {
		IdEmpresa = idEmpresa;
	}


	public int getIdSisbacen() {
		return IdSisbacen;
	}


	public void setIdSisbacen(int idSisbacen) {
		IdSisbacen = idSisbacen;
	}


	public String getNmEmpresa() {
		return NmEmpresa;
	}


	public void setNmEmpresa(String nmEmpresa) {
		NmEmpresa = nmEmpresa;
	}


	public String getNmTrader() {
		return NmTrader;
	}


	public void setNmTrader(String nmTrader) {
		NmTrader = nmTrader;
	}


	public String getRazaoSocial() {
		return RazaoSocial;
	}


	public void setRazaoSocial(String razaoSocial) {
		RazaoSocial = razaoSocial;
	}


	public String getTelefone() {
		return Telefone;
	}


	public void setTelefone(String telefone) {
		Telefone = telefone;
	}


	public int getTpMediaMovel() {
		return TpMediaMovel;
	}


	public void setTpMediaMovel(int tpMediaMovel) {
		TpMediaMovel = tpMediaMovel;
	}


	public String getTipoEmpresa() {
		return tipoEmpresa;
	}


	public void setTipoEmpresa(String tipoEmpresa) {
		this.tipoEmpresa = tipoEmpresa;
	}

    
}
