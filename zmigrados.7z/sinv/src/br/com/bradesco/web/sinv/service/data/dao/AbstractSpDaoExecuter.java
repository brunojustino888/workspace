package br.com.bradesco.web.sinv.service.data.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;
import java.util.List;

public abstract class AbstractSpDaoExecuter <InputDataType > extends BaseDAO {
	
	
	private final InputDataType inputData;

	public abstract String obterNomeStoredProcedure();
	
	public InputDataType getInputData() {
		return inputData;
	}
	
	public abstract List<?> obterParametros();
	
	protected AbstractSpDaoExecuter(InputDataType vo) {
		this.inputData = vo;
	}
	
	protected String getParametrizacao() {
		String parametrizacao = "";
		List<?> parametros = obterParametros();
		if (parametros != null && parametros.size() > 0) {
			parametrizacao = "(?";
			for (int i = 1; i < parametros.size(); i++) {
				parametrizacao += ", ?";
			}
			parametrizacao += ")";
		}
		
		return parametrizacao;
	}
	
	protected String getSpCallString(){
		return "{call " + obterNomeStoredProcedure() + getParametrizacao() + "}";
	}
	
	protected void setValorParametro(CallableStatement cs, int indexParametro, Object value) {
		try {
			if(value == null) {
				cs.setNull(indexParametro, Types.CHAR);
			} else {
				if(value instanceof Date) {
					Date data = (Date) value;
					Timestamp dataSql = new Timestamp(data.getTime()); 
					value = dataSql;
				}
				
				if (value instanceof BigDecimal) {
					BigDecimal valor = (BigDecimal) value;
					value = valor.doubleValue();					
				}
				cs.setObject(indexParametro, value);
			}
		} catch (SQLException e) {
			log.error("Erro setando par�metro [" + indexParametro + "]" + " Valor: " + value + "E: " + e, value);
		}
	}
	protected void setValorParametro(CallableStatement cs, String nomeParametro, Object value) {
		try {
			if(value == null) {
				cs.setNull(nomeParametro, Types.CHAR);
			} else {
				if(value instanceof Date) {
					Date data = (Date) value;
					Timestamp dataSql = new Timestamp(data.getTime()); 
					value = dataSql;
				}
				cs.setObject(nomeParametro, value);
			}
		} catch (SQLException e) {
			log.error("Erro setando par�metro [" + nomeParametro + "]"+ " Valor: " + value + "E: " + e, value);
		}
	}
}
