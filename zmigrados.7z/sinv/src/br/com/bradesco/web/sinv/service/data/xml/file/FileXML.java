package br.com.bradesco.web.sinv.service.data.xml.file;

public class FileXML {

}
