package br.com.bradesco.web.sinv.service.data.dataobject.exportacoes.pdf;

import java.awt.Color;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.design.JRDesignBand;
import net.sf.jasperreports.engine.design.JRDesignExpression;
import net.sf.jasperreports.engine.design.JRDesignField;
import net.sf.jasperreports.engine.design.JRDesignStaticText;
import net.sf.jasperreports.engine.design.JRDesignTextField;
import net.sf.jasperreports.engine.design.JasperDesign;
import br.com.bradesco.web.sinv.service.data.dataobject.exportacoes.DadosExportacaoDataObject;
import br.com.bradesco.web.sinv.service.data.dataobject.exportacoes.ExportacaoDataObject;
import br.com.bradesco.web.sinv.service.data.dataobject.exportacoes.RegistroDeExportacao;

public class ReportDesigner {
	@SuppressWarnings("unused")
	private final ExportacaoDataObject<DadosExportacaoDataObject> exportacaoDataObject;

	public ReportDesigner(ExportacaoDataObject<DadosExportacaoDataObject> exportacaoDataObject) {
		this.exportacaoDataObject = exportacaoDataObject;
	}
	@SuppressWarnings("unused")
	private void configPage(JasperDesign jasperDesign) {
		jasperDesign.setPageWidth(500);
		jasperDesign.setPageHeight(1000);
		jasperDesign.setColumnCount(1);
		jasperDesign.setColumnWidth(450);
		jasperDesign.setColumnSpacing(0);
		jasperDesign.setLeftMargin(10);
		jasperDesign.setRightMargin(10);
		jasperDesign.setBottomMargin(5);
		jasperDesign.setTopMargin(5);
		jasperDesign.setName("RelatorioDeConsumo");
	}
	@SuppressWarnings("unused")
	private JasperDesign getPageHeader(JasperDesign design, DadosExportacaoDataObject dadosExportacao){
		return design;
	}
	@SuppressWarnings("unused")
	private JasperDesign getTitle(JasperDesign design, DadosExportacaoDataObject dadosExportacao){
		JRDesignBand band = new JRDesignBand();
		band.setHeight(50);
		JRDesignStaticText staticText = new JRDesignStaticText();
		staticText.setX(10);
		staticText.setY(10);
		staticText.setWidth(450);
		staticText.setHeight(40);
		staticText.setFontName("Tahoma");
		staticText.setForecolor(Color.BLUE);
		staticText.setFontSize(24);
		staticText.setPdfFontName("Helvetica-Bold");
		staticText.setBold(true);
		staticText.setText(dadosExportacao.getNome());
		band.addElement(staticText);
		design.setTitle(band);
		
		return design;
	}
	
	@SuppressWarnings("unused")
	private JasperDesign getColumnHeader(JasperDesign design, DadosExportacaoDataObject dadosExportacao){
		JRDesignBand band = new JRDesignBand();
		band.setHeight(25);
		design.setColumnHeader(band);
		
		RegistroDeExportacao cabecalho = dadosExportacao.getCabecalho();
		
		int y = 1;
		for (int i = 0;i < cabecalho.getQuantidadeColunas();i++, y+=dadosExportacao.getColunmSize(i)) {
			Object headerColumn = cabecalho.getConteudo().get(i);
			JRDesignStaticText staticText = new JRDesignStaticText();
			staticText.setX(0);
			staticText.setY(y);
			staticText.setWidth(dadosExportacao.getColunmSize(i));
			staticText.setHeight(15);
			staticText.setText(headerColumn.toString());
			staticText.setBold(true);
			band.addElement(staticText);
		}
		
		return design;
		
	}
	
//	private JasperDesign createSubReportsFields(JasperDesign design, ExportacaoDataObject exportacaoDataObject) throws JRException{
//		for (int i = 1;i < exportacaoDataObject.getListaDeDadosExportacao().size();i++) {
//			JRDesignField field = new JRDesignField();
//			field.setName(exportacaoDataObject.getNome() + "SubReportList" + i);
//			field.setValueClass(java.util.List.class);
//			design.addField(field);
//		}
//		
//		return design;
//		
	@SuppressWarnings("unused")
	private JasperDesign getColumnDetails(JasperDesign design, DadosExportacaoDataObject dadosExportacao) throws JRException{
		JRDesignBand band = new JRDesignBand();
		band.setHeight(20);
//		design.setDetail(band);
		
		RegistroDeExportacao exportacao = dadosExportacao.getRegistros().get(0);
		int y = 1;
		for (int i = 0;i < exportacao.getQuantidadeColunas();i++) {
			JRDesignField field = new JRDesignField();
			field.setName(i+"");
			field.setValueClass(exportacao.getConteudo().get(i).getClass());
			design.addField(field);
			
			JRDesignTextField textField = new JRDesignTextField();
			textField.setX(0);
			textField.setY(y);
			textField.setWidth(dadosExportacao.getColunmSize(i));
			textField.setHeight(15);

			JRDesignExpression expression = new JRDesignExpression();
			expression.setValueClass(java.lang.String.class);
			expression.setText("$F{"+ i + "}");
			textField.setExpression(expression);
			band.addElement(textField);
		}
		
		return design;
		
	}
	
	@SuppressWarnings("unused")
	private JasperDesign getColumnFooter(JasperDesign design, DadosExportacaoDataObject dadosExportacao) throws JRException{
		JRDesignBand band = new JRDesignBand();
		band.setHeight(20);
		design.setColumnFooter(band);
		return design;
	}
	
	@SuppressWarnings("unused")
	private JasperDesign getPageFooter(JasperDesign design, DadosExportacaoDataObject dadosExportacao) throws JRException{
		JRDesignBand band = new JRDesignBand();
		band.setHeight(20);
		design.setPageFooter(band);
		return design;
	}
	@SuppressWarnings("unused")
	private JasperDesign getNoData(JasperDesign design, DadosExportacaoDataObject dadosExportacao) throws JRException{
		JRDesignBand band = new JRDesignBand();
		band.setHeight(20);
		design.setNoData(band);
		return design;
	}
	@SuppressWarnings("unused")
	private JasperDesign getSumary(JasperDesign design, DadosExportacaoDataObject dadosExportacao) throws JRException{
		JRDesignBand band = new JRDesignBand();
		band.setHeight(20);
		design.setSummary(band);
		return design;
	}
	
//	
//	private void generateDesign() throws JRException {
//		JasperDesign jasperDesign = new JasperDesign();;
//		configPage(jasperDesign);
//		DadosExportacaoDataObject masterList = this.exportacaoDataObject.getListaDeDadosExportacao().get(0);
//		getPageHeader(jasperDesign, masterList);
//		getTitle(jasperDesign, masterList);
//		getColumnHeader(jasperDesign, masterList);
//		getColumnDetails(jasperDesign, masterList);
//		getColumnFooter(jasperDesign, masterList);
//		getPageFooter(jasperDesign, masterList);
//		getNoData(jasperDesign, masterList);
//		getSumary(jasperDesign, masterList);
//
//		if(this.exportacaoDataObject.getListaDeDadosExportacao().size() > 1){
//			createSubReportsFields(jasperDesign, this.exportacaoDataObject);
//		}
//	}
	
}