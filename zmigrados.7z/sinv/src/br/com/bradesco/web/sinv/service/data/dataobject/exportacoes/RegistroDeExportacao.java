package br.com.bradesco.web.sinv.service.data.dataobject.exportacoes;

import java.util.ArrayList;
import java.util.List;

public class RegistroDeExportacao{
	private List<Object> conteudo;
	
	public RegistroDeExportacao() {
		conteudo = new ArrayList<Object>();
	}
	
	public void adicionarValorColuna(Object valorColuna){
		conteudo.add(valorColuna);
	}
	
	public List<Object> getConteudo() {
		return conteudo;
	}
	
	public int getQuantidadeColunas(){
		return conteudo.size();
	}
}
