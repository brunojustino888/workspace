/*
 * ImportacaoDolRiscDataObject.java       1.0 03/12/2013
 *
 * Copyright (c) 2013 Bradesco S/A.
 * Osasco, SP - Brazil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bradesco S/A. ("Confidential Information").  You shall not disclose 
 * such Confidential Information and shall not use, publish, alter 
 * or otherwise make it available, directly or indirectly, without the prior 
 * written consent of Bradesco S/A.
 */
package br.com.bradesco.web.sinv.service.data.dataobject.importacoes;

import java.util.Date;

import br.com.bradesco.web.sinv.service.data.dataobject.BaseDataObject;

/**
 * @author InfoSERVER - Jo�o Germano Filho
 */
@SuppressWarnings("serial")
public class ImportacaoDolRiscDataObject extends BaseDataObject {
	
	
	private Date data;

	/**
	 * @return the data
	 */
	public Date getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(Date data) {
		this.data = data;
	}
	
	

}
