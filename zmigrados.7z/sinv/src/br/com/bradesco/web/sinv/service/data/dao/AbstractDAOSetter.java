package br.com.bradesco.web.sinv.service.data.dao;

import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Iterator;

import br.com.bradesco.web.sinv.service.data.dao.exception.DAOException;

public abstract class AbstractDAOSetter<InputDataType extends Serializable> extends AbstractSpDaoExecuter<InputDataType>{
	
	protected AbstractDAOSetter(InputDataType inputData) {
		super(inputData);
	}
	
	public void execute() throws DAOException {
        Connection conn = null;
        CallableStatement cs = null;
        ResultSet rs = null;
        try {
            log.debug(this, "Preparar a chamada da Stored Procedure - " + obterNomeStoredProcedure());
            conn = this.getConnection();
            cs = conn.prepareCall(getSpCallString());
            
            int indexParametro = 1;
			for(Iterator<?> i = obterParametros().iterator(); i.hasNext(); ) {
				setValorParametro(cs, indexParametro++, i.next());
			}

			log.debug(this, "Executar a Stored Procedure - " + obterNomeStoredProcedure());
            // Executar a Stored Procedure
            cs.execute();
        } catch (Exception e) {
        	log.error(e, "Erro ao executar a Stored Procedure - " + obterNomeStoredProcedure() + " Descri��o: " + e);
            throw new DAOException("Problemas ao executar Stored Procedure - " + obterNomeStoredProcedure() + " Descri��o: " + e);
        } finally {
            close(rs, cs, conn);
        }
        log.info(this, "Execu��o de Stored Procedure "+ obterNomeStoredProcedure() + " realizada com sucesso.");
	}
	

}
