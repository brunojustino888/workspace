package br.com.bradesco.web.sinv.service.data.dataobject.exportacoes.pdf;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRMapCollectionDataSource;
import net.sf.jasperreports.engine.design.JRDesignBand;
import net.sf.jasperreports.engine.design.JRDesignExpression;
import net.sf.jasperreports.engine.design.JRDesignField;
import net.sf.jasperreports.engine.design.JRDesignStaticText;
import net.sf.jasperreports.engine.design.JRDesignTextField;
import net.sf.jasperreports.engine.design.JasperDesign;
import br.com.bradesco.web.aq.application.error.BradescoApplicationException;
import br.com.bradesco.web.sinv.service.business.exportacoes.IExportacaoDataObjectStream;
import br.com.bradesco.web.sinv.service.data.dataobject.exportacoes.DadosExportacaoDataObject;
import br.com.bradesco.web.sinv.service.data.dataobject.exportacoes.ExportacaoDataObject;
import br.com.bradesco.web.sinv.service.data.dataobject.exportacoes.RegistroDeExportacao;

@SuppressWarnings({ "unchecked", "rawtypes" })
public class PDFDinamicoExportacaoDataObjectStream
		implements
		IExportacaoDataObjectStream<ExportacaoDataObject<DadosExportacaoDataObject>, DadosExportacaoDataObject> {
	private ExportacaoDataObject<DadosExportacaoDataObject> exportacaoDataObject;

	public byte[] getBytes(
			ExportacaoDataObject<DadosExportacaoDataObject> exportacaoDataObject)
			throws Exception {
		this.exportacaoDataObject = exportacaoDataObject;
		byte[] bytes = null;
		try {

			JasperDesign jasperDesign = generateDesign();

			JasperReport jasperReport = JasperCompileManager
					.compileReport(jasperDesign);
			HashMap map = new HashMap();
			List<Map<String, Object>> preparedDataSource = new ArrayList<Map<String, Object>>();
			for (DadosExportacaoDataObject dadosExportacaoDataObject : exportacaoDataObject
					.getListaDeDadosExportacao()) {
				for (int i = 0; i < dadosExportacaoDataObject.getRegistros()
						.size(); i++) {
					RegistroDeExportacao registroDeExportacao = dadosExportacaoDataObject
							.getRegistros().get(i);
					HashMap<String, Object> columnValue = new HashMap<String, Object>();
					for (int j = 0; j < registroDeExportacao
							.getQuantidadeColunas(); j++) {
						map.put(j + "",
								registroDeExportacao.getConteudo().get(j));
					}
					preparedDataSource.add(columnValue);
				}
			}

			JRDataSource jrds = new JRMapCollectionDataSource(
					preparedDataSource);
			bytes = JasperRunManager.runReportToPdf(jasperReport, map, jrds);
		} catch (Exception e) {
			throw new BradescoApplicationException(e);
		}
		return bytes;
	}

	public ContentTypeEnum getContentType() {
		return ContentTypeEnum.PDF;
	}

	private void configPage(JasperDesign jasperDesign) {
		jasperDesign.setPageWidth(500);
		jasperDesign.setPageHeight(1000);
		jasperDesign.setColumnCount(1);
		jasperDesign.setColumnWidth(450);
		jasperDesign.setColumnSpacing(0);
		jasperDesign.setLeftMargin(10);
		jasperDesign.setRightMargin(10);
		jasperDesign.setBottomMargin(5);
		jasperDesign.setTopMargin(5);
		jasperDesign.setName("RelatorioDeConsumo");
	}

	private JasperDesign getPageHeader(JasperDesign design,
			DadosExportacaoDataObject dadosExportacao) {
		return design;
	}

	private JasperDesign getTitle(JasperDesign design,
			DadosExportacaoDataObject dadosExportacao) {
		JRDesignBand band = new JRDesignBand();
		band.setHeight(50);
		JRDesignStaticText staticText = new JRDesignStaticText();
		staticText.setX(10);
		staticText.setY(10);
		staticText.setWidth(450);
		staticText.setHeight(40);
		staticText.setFontName("Tahoma");
		staticText.setForecolor(Color.BLUE);
		staticText.setFontSize(24);
		staticText.setPdfFontName("Helvetica-Bold");
		staticText.setBold(true);
		staticText.setText(dadosExportacao.getNome());
		band.addElement(staticText);
		design.setTitle(band);

		return design;
	}

	private JasperDesign getColumnHeader(JasperDesign design,
			DadosExportacaoDataObject dadosExportacao) {
		JRDesignBand band = new JRDesignBand();
		band.setHeight(25);
		design.setColumnHeader(band);
		RegistroDeExportacao cabecalho = dadosExportacao.getCabecalho();

		int y = 1;
		for (int i = 0; i < cabecalho.getQuantidadeColunas(); i++) {
			Object headerColumn = cabecalho.getConteudo().get(i);
			JRDesignStaticText staticText = new JRDesignStaticText();
			staticText.setY(y);
			staticText.setWidth(30);
			// staticText.setWidth(dadosExportacao.getColunmSize(i));
			staticText.setHeight(15);
			staticText.setText(headerColumn.toString());
			staticText.setBold(true);
			band.addElement(staticText);
			// y+=dadosExportacao.getColunmSize(i);
			y += 30;
		}

		return design;

	}

//	private JasperDesign createSubReportsFields(JasperDesign design,
//			ExportacaoDataObject exportacaoDataObject) throws JRException {
//		for (int i = 1; i < exportacaoDataObject.getListaDeDadosExportacao()
//				.size(); i++) {
//			JRDesignField field = new JRDesignField();
//			field.setName(exportacaoDataObject.getNome() + "SubReportList" + i);
//			field.setValueClass(java.util.List.class);
//			design.addField(field);
//		}
//
//		return design;
//
//	}

	private JasperDesign getColumnDetails(JasperDesign design,
			DadosExportacaoDataObject dadosExportacao) throws JRException {
		JRDesignBand band = new JRDesignBand();
		band.setHeight(20);

		RegistroDeExportacao exportacao = dadosExportacao.getRegistros().get(0);
		int y = 1;
		for (int i = 0; i < exportacao.getQuantidadeColunas(); i++) {
			JRDesignField field = new JRDesignField();
			field.setName(i + "");
			field.setValueClass(exportacao.getConteudo().get(i).getClass());
			design.addField(field);

			JRDesignTextField textField = new JRDesignTextField();
			textField.setX(0);
			textField.setY(y);
			textField.setWidth(dadosExportacao.getColunmSize(i));
			textField.setHeight(15);
			JRDesignExpression expression = new JRDesignExpression();
			expression.setValueClass(java.lang.String.class);
			expression.setText("$F{" + i + "}");
			textField.setExpression(expression);
			band.addElement(textField);
		}

		return design;

	}

	private JasperDesign getColumnFooter(JasperDesign design,
			DadosExportacaoDataObject dadosExportacao) throws JRException {
		JRDesignBand band = new JRDesignBand();
		band.setHeight(20);
		design.setColumnFooter(band);
		return design;
	}

	private JasperDesign getPageFooter(JasperDesign design,
			DadosExportacaoDataObject dadosExportacao) throws JRException {
		JRDesignBand band = new JRDesignBand();
		band.setHeight(20);
		design.setPageFooter(band);
		return design;
	}

	private JasperDesign getNoData(JasperDesign design,
			DadosExportacaoDataObject dadosExportacao) throws JRException {
		JRDesignBand band = new JRDesignBand();
		band.setHeight(20);
		design.setNoData(band);
		return design;
	}

	private JasperDesign getSumary(JasperDesign design,
			DadosExportacaoDataObject dadosExportacao) throws JRException {
		JRDesignBand band = new JRDesignBand();
		band.setHeight(20);
		design.setSummary(band);
		return design;
	}

	private JasperDesign generateDesign() throws JRException {
		JasperDesign jasperDesign = new JasperDesign();
		;
		configPage(jasperDesign);
		DadosExportacaoDataObject masterList = this.exportacaoDataObject
				.getListaDeDadosExportacao().get(0);
		getPageHeader(jasperDesign, masterList);
		getTitle(jasperDesign, masterList);
		getColumnHeader(jasperDesign, masterList);
		getColumnDetails(jasperDesign, masterList);
		getColumnFooter(jasperDesign, masterList);
		getPageFooter(jasperDesign, masterList);
		getNoData(jasperDesign, masterList);
		getSumary(jasperDesign, masterList);

		// if(this.exportacaoDataObject.getListaDeDadosExportacao().size() > 1){
		// createSubReportsFields(jasperDesign, this.exportacaoDataObject);
		// }

		return jasperDesign;
	}

}
