package br.com.bradesco.web.sinv.service.data.dao;

public class SINVDAOErrorCode {

	// Codigos das exce��es

	/**
	 * Prefiro que tenham os codigos de error da capa do DAO
	 */
	public static final String PREFIX_EXCEPTION_CODE = "error.sevice.data.dao.sinv.";

	// CODIGOS ERROR RELACIONADOS COM O DATAACCESSEXCEPTION

	/**
	 * Agencia e conta Inexistentes.
	 */
	public static final String AGENCIA_CONTA_INEXISTENTES = PREFIX_EXCEPTION_CODE
			+ "agenciaContaInexistentes";

	/**
	 * Codigo de exce��o lan�ado quando el resultado de la llamada a un store
	 * procedure es una lista vacia
	 */
	public static final String LST_NULL_RESULT_EXCEPTION = PREFIX_EXCEPTION_CODE
			+ "lstResultNullException";

	/**
	 * Codigo de exce�ao lan�ado quando el resultado de la llamada a un store
	 * procedure de tipo insert update es erroneo
	 */
	public static final String NOT_SUCCESS_INSERT_UPDATE_EXCEPTION = PREFIX_EXCEPTION_CODE
			+ "notSuccessInsertUpdateException";

	/**
	 * Codigo de exce�ao lan�ado quando intentamos insertar una columna
	 */
	public static final String COLUMN_NOT_NULLABLE_EXCEPTION = PREFIX_EXCEPTION_CODE
			+ "columnNotNullableException";

	/**
	 * Codigo de exce�ao lan�ado quando tenta criar uma sess�o que j� existe
	 * para outro usu�rio
	 */
	public static final String SESSAO_JA_EXISTE_OUTRO_EXCEPTION = PREFIX_EXCEPTION_CODE
			+ "sessionErrorException";

	/**
	 * Codigo de exce�ao lan�ado quando tenta criar ag�ncia e conta virtual
	 */
	public static final String ERRO_CRIA_CV_EXCEPTION = PREFIX_EXCEPTION_CODE
			+ "criaCVException";

	/**
	 * Codigo de exce��o lan�ado quando um metodo foi chamado com um tempo
	 * ilegal ou inapropiado.(o estado da JVM N�o � o apropiado)
	 */
	public static final String ILLEGAL_STATE_EXCEPTION = PREFIX_EXCEPTION_CODE
			+ "illegalStateException";

	/**
	 * Codigo de exce��o lan�ado quando uma lista est� vazia
	 */
	public static final String LIST_EMPTY_EXCEPTION = PREFIX_EXCEPTION_CODE
			+ "listEmptyException";

	/**
	 * Codigo de exce��o lan�ado quando o error no processo do metodo do dao �
	 * generico: null pointer, illegalstate, arrayIndexbound,...
	 */
	public static final String DEFAULT_EXCEPTION = PREFIX_EXCEPTION_CODE
			+ "default";

	/**
	 * 
	 * Construtor.
	 * 
	 */
	public SINVDAOErrorCode() {
		super();
	}

}
