package br.com.bradesco.web.sinv.view.bean;

import java.util.Locale;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

public class LocaleBean {
    
    /**
     * Propriedade locale: Representa o locale do aplicativo.
     */
    private String locale;
    
    /**
     * Retorna o locale da aplica��o. O default ser� o idioma o navegador.
     * 
     * @return String o locale da aplica��o.
     */
    public String getLocale() {
        if (locale == null || locale.equals("")) {
            locale = FacesContext.getCurrentInstance().getExternalContext().getRequestLocale().getLanguage();
        }
        return locale;
    }
    
    /**
     * Atualiza o locale da aplica��o.
     * 
     * @param locale ir� atualizar a propriedade locale.
     */
    public void setLocale(String locale) {
        this.locale = locale;
    }
    
    /**
     * M�todo que modifica o locale da aplica��o.
     * 
     * @param lc String que representa o locale do aplicativo.
     */
    public void changeLocale(String lc) {
        FacesContext context = FacesContext.getCurrentInstance();
        String locale;
        if (lc.equals("pt")) {
           locale = "pt"; 
           context.getViewRoot().setLocale(new Locale("pt", "BR"));
        } else {
           locale = "es";
           context.getViewRoot().setLocale(new Locale("es", "ES"));
        }
        
        setLocale(locale);
    }
    
    /**
     * M�todo chamado para modifica��o do idioma da aplica��o.
     * 
     * @param event - evento de origem da tela.
     */
    public void processarEventos(ActionEvent event) {
        UIComponent component = event.getComponent();
        if (component.getId().equals("pt")) {
            changeLocale("pt");
        } else if (component.getId().equals("es")) {
            changeLocale("es");
        }
    }
    
}

