package br.com.bradesco.web.sinv.service.data.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Iterator;

import br.com.bradesco.web.sinv.service.data.dao.exception.DAOException;

public abstract class AbstractDAOGetter<InputDataType , OutputDataType > extends AbstractSpDaoExecuter<InputDataType>{
	
	protected AbstractDAOGetter(InputDataType inputData) {
		super(inputData);
	}
	
	public abstract OutputDataType buildOutputDataType(ResultSet resultSet) throws DAOException;

	public OutputDataType executeQuery() throws DAOException {
		OutputDataType outputData = null;
        Connection conn = null;
        CallableStatement cs = null;
        ResultSet rs = null;
        try {
            log.debug(this, "Preparar a chamada da Stored Procedure de obten��o de Dados - " + obterNomeStoredProcedure());
            conn = this.getConnection();
            cs = conn.prepareCall(getSpCallString());
            
            int indexParametro = 1;
			for(Iterator<?> i = obterParametros().iterator(); i.hasNext(); ) {
				setValorParametro(cs, indexParametro++, i.next());
			}

			log.debug(this, "Executar a Stored Procedure de obten��o de Dados - " + obterNomeStoredProcedure());
            // Executar a Stored Procedure
            boolean hasResultSet = cs.execute();
            int updateCount = -1;
			do {
            	if(hasResultSet){
            		rs = cs.getResultSet();
            		outputData = buildOutputDataType(rs);
            	}
            	updateCount = cs.getUpdateCount();
            	hasResultSet = cs.getMoreResults();
            } while (hasResultSet || updateCount != -1);            	
        } catch (Exception e) {
        	log.error(e, "Erro ao executar a Stored Procedure de obten��o de Dados - " + obterNomeStoredProcedure());
            throw new DAOException("Problemas ao obter de Dados - " + obterNomeStoredProcedure());
        } finally {
            close(rs, cs, conn);
        }
        log.info(this, "obten��o de Dados de Relat�rio "+ obterNomeStoredProcedure() +"realizada com sucesso.");
        return outputData;
	}
}
