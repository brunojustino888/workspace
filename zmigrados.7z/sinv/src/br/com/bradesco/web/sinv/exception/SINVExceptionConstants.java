package br.com.bradesco.web.sinv.exception;

import br.com.bradesco.web.aq.application.error.ExceptionConstants;

public class SINVExceptionConstants extends ExceptionConstants  {

    /**
     * Indica a instru��o ou fase de servi�o na qual � realizada a comunica��o
     * com ISD.
     */
    public static final String INSTRUCAO_COMUNICACAO_ISD = "02";
  
    //public static final String COMUNICACAO_BANCO_DADOS = "01";

    /**
     * Indica a instru��o ou fase de servi�o na qual realiza-se a obten��o
     * de uma determinada configura��o.
     */
    public static final String INSTRUCAO_OBTENCAO_CONFIGURACAO = "16";

    /**
     * Indica a instru��o ou fase de servi�o na qual realiza-se a obten��o
     * da conta relacionada ao usu�rio.
     */
    public static final String INSTRUCAO_OBTENCAO_CONTA_ENTITY = "09";

    /**
     * Indica a instru��o ou fase de servi�o na qual realiza-se a obten��o
     * dos dados de sess�o de usu�rio.
     */
    public static final String INSTRUCAO_OBTENCAO_DADOS_SESSAO = "12";

    /**
     * Indica a instru��o ou fase de servi�o na qual realiza-se obten��o
     * da midia.
     */
    public static final String INSTRUCAO_OBTENCAO_MIDIA_ENTITY = "08";

    /**
     * Indica a instru��o ou fase de servi�o na qual � realizada a comprova��o
     * do resultado do acesso ao banco de dados.
     */
    public static final String INSTRUCAO_RETORNO_BANCO_DADOS = "03";

    /**
     * Indica a instru��o ou fase de servi�o na qual � realizada a comprova��o
     * do retorno de ISD.
     */
    public static final String INSTRUCAO_RETORNO_ISD = "04"; 

    /**
     * Indica a instru��o ou fase de servi�o na que realiza-se o parseado
     * a mensagem de retorno de uma determinada transa��o.
     */
    public static final String INSTRUCAO_RETORNO_MESSAGE_PARSER = "05";

    /**
     * Indica a instru��o ou fase de servi�o na que realizam-se v�rias valida��es
     * sobre os dados de entrada.
     */
    public static final String INSTRUCAO_VALIDACAO_DADOS_ENTRADA = "07";

    /**
     * Indica a instru��o ou fase de servi�o na qual � realizada a valida��o
     * da senha de usu�rio.
     */
    public static final String INSTRUCAO_VALIDACAO_SENHA = "13";

    /**
     * Indica a instru��o ou fase de servi�o na qual � realizada a valida��o
     * se o usu�rio tem um perfil de acesso adequado para a execu��o de uma
     * determinada a��o.
     */
    public static final String INSTRUCAO_VALIDACAO_PERFIL_ACESSO = "06";
    
    /**
     * Indica o tipo de erro ocorrido. Se for funcional ser� negocio, qualquer outro
     * erro ser� t�cnico.
     */
    public static final String FLAG_ERRO = "1";

    /**
     * Indica o tipo de erro ocorrido. Se for funcional ser� negocio, qualquer outro
     * erro ser� t�cnico.
     */
    public static final String FLAG_SUCESSO = "0";
    
    /**
     * Indica erro gen�rico no site.
     */    
    public static final String GENERAL_ERROR = "error.view.default";
    
    /**
     * Condicoes fora do padr�o do convenio.
     */    
    public static final String CONDICOES_FORA_PADRAO_CONVENIO = "error.service.data.condicoesForaPadraoConvenio";
    
    /**
     * Valor insuficiente de margem.
     */    
    public static final String VALOR_MARGEM_INSUFICIENTE = "error.service.econsig.margeminsuficiente";
    
    /**
     * Falta de senha do servidor.
     */
    public static final String SENHA_SERVIDOR_OBRIGATORIO_INCORRETA = "error.service.econsig.senhaIncorreta";
    
    /**
     * Falta de senha do servidor.
     */
    public static final String CONTA_SEM_CHEQUE_ESPECIAL = "error.service.chequeEspecial.clienteSemLimite";
    
    /**
     * N�o existem comprovantes com pagamento agendado.
     */
    public static final String NAO_EXISTE_COMPROVANTE_PAG_ANTECIPADO = 
            "error.service.data.pdc.functional.shopcredit.pagamento.listaPagamentos.100.cancelamento";
    
}
