/*
 * ProdutoTesourariaDataObject.java       1.0 23/01/2014
 *
 * Copyright (c) 2013 Bradesco S/A.
 * Osasco, SP - Brazil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bradesco S/A. ("Confidential Information").  You shall not disclose 
 * such Confidential Information and shall not use, publish, alter 
 * or otherwise make it available, directly or indirectly, without the prior 
 * written consent of Bradesco S/A.
 */
package br.com.bradesco.web.sinv.service.data.dataobject.geral;

import br.com.bradesco.web.sinv.service.data.dataobject.BaseDataObject;

/**
 * @author InfoSERVER - Jo�o Germano Filho
 */
@SuppressWarnings("serial")
public class ProdutoTesourariaDataObject extends BaseDataObject implements Comparable<ProdutoTesourariaDataObject> {

    private short situacao;

    public int compareTo(ProdutoTesourariaDataObject o) {
        return this.descricao.compareTo(o.descricao);
    }

    /**
     * @return the situacao
     */
    public short getSituacao() {
        return situacao;
    }

    /**
     * @param situacao the situacao to set
     */
    public void setSituacao(short situacao) {
        this.situacao = situacao;
    }

}
