/*
 * @(#)DefaultDao.java       1.0 19/09/2008
 *
 * Copyright (c) 2008 Bradesco S/A.
 * Osasco, SP - Brazil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bradesco S/A. ("Confidential Information").  You shall not disclose 
 * such Confidential Information and shall not use, publish, alter 
 * or otherwise make it available, directly or indirectly, without the prior 
 * written consent of Bradesco S/A.
 */
package br.com.bradesco.web.sinv.service.data.dao;

import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.Status;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import br.com.bradesco.web.sinv.service.data.dao.exception.DAOException;
import br.com.bradesco.web.sinv.service.data.dataobject.geral.ProdutoTesourariaDataObject; 
import br.com.bradesco.web.sinv.view.bean.LogBean;

/**
 * Classe Abstrata DefaultDao. Respons�vel por recuperar a conex�o com banco de dados.
 * @author Jo�o Germano Filho
 * @Version 1.0
 */
public class BaseDAO extends LogBean {

//	private static final String JNDI_NAME = "java:comp/env/jdbc/intranet_sinv_sinvd000_sql";
//	private static final String USER_JNDI_NAME = "java:comp/UserTransaction";
	private static final String PROCEDURE_OBTER_LISTA_PRODUTOS   = "dbo.pSeltProdtOperTesou01";
	
    protected static DataSource datasource;

    protected boolean autoCommit = true;
    protected static Connection conexaoPersistente = null;
    
    protected boolean localConnection = false;
    protected String urlDB = null;
    
    protected static final int DBMS_TEXT = 1;

    protected BaseDAO() {
        super();
        autoCommit = true;
    }
     
    protected PrintWriter logWriter = null;


    /*
     * Recuperar a conex�o com o Banco de Dados
     * @return Retorna uma conex�o com o banco de dados.
     * @throws DaoException se algum erro ocorrer.
     */
    public Connection getConnection() throws DAOException, SQLException {
        Connection connection = null;
        try {
            if (datasource == null) {
//                datasource = (DataSource) ServiceLocator.getInstance().lookup(JNDI_NAME);
            }
            connection = datasource.getConnection();
        } catch (Exception e) {
            throw new DAOException("Problemas ao obter conex�o com o Banco de Dados" + e.getMessage());
        }
        return connection;
    }
    
    protected void begin() throws DAOException {
		try {
			if (getUserTransaction().getStatus() == Status.STATUS_NO_TRANSACTION) {
				getUserTransaction().begin();
			}
		} catch (NotSupportedException e) {
			throw new DAOException(
					"Transaction Error, Transacao nao suportada." + e.getMessage());
		} catch (SystemException e) {
			throw new DAOException(
					"Erro de sistema inicializando transacao." + e.getMessage());
		} catch (Exception e) {
			throw new DAOException(e);
		}

	}

	protected void commit() throws DAOException {
		try {
			if (getUserTransaction().getStatus() == Status.STATUS_ACTIVE) {
				getUserTransaction().commit();
			}
		} catch (SystemException e) {
			throw new DAOException(
					"Erro de sistema inicializando transacao." + e.getMessage());
		} catch (SecurityException e) {
			throw new DAOException(
					"Erro de seguranca realizando commit na transacao." + e.getMessage());
		} catch (IllegalStateException e) {
			throw new DAOException(
					"Estado ilegal realizando commit na transacao." + e.getMessage());
		} catch (RollbackException e) {
			throw new DAOException(e);
		} catch (HeuristicMixedException e) {
			throw new DAOException(e);
		} catch (HeuristicRollbackException e) {
			throw new DAOException(e);
		} catch (Exception e) {
			throw new DAOException(e);
		}

	}

	protected void rollback() throws DAOException {
		try {
			if (getUserTransaction().getStatus() == Status.STATUS_ACTIVE) {
				getUserTransaction().rollback();
			}
		} catch (IllegalStateException e) {
			throw new DAOException(
					"Estado ilegal realizando rollback na transacao." + e.getMessage());
		} catch (SecurityException e) {
			throw new DAOException(
					"Erro de seguranca realizando rollback na transacao." + e.getMessage());
		} catch (SystemException e) {
			throw new DAOException(
					"Erro de sistema realizando rollback na transacao." + e.getMessage());
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

    private UserTransaction getUserTransaction() throws DAOException, SQLException 
	{
		try {
//			ServiceLocator locator = ServiceLocator.getInstance();
//			UserTransaction transaction = (UserTransaction) locator.lookup(USER_JNDI_NAME);
//	    	return transaction;
		} catch (Exception e) {
			throw new DAOException("Erro ao obter UserTransaction. " + e.getMessage());
		}
		return null;
	}

    protected void close(ResultSet rs) throws DAOException {
        try {
        	Statement stmt = null;
        	if (rs != null) {
				stmt = rs.getStatement();
	        	rs.close();
        	}
        	close(stmt);
        } catch (Exception e) {
        	throw new DAOException("Erro ao Fechar conex�o: " + e.getMessage());
        }
    }
    
    protected void close(Statement stmt) throws DAOException {
    	try {
    		Connection conn = null;
    		if (stmt != null) {
    			conn = stmt.getConnection();
    			stmt.close();
    		}
    		close(conn);
    	} catch (Exception e) {
    		throw new DAOException("Erro ao Fechar conex�o: " + e.getMessage());
    	}
    }
    
    protected void close(Connection conn) throws DAOException {
    	try {
    		if (conn != null) {
				conn.close();
    		}
    	} catch (Exception e) {
    		throw new DAOException("Erro ao Fechar conex�o: " + e.getMessage());
    	}
	}

	protected void close(ResultSet rs, PreparedStatement stmt, Connection conn) throws DAOException {
    	try {
    		if (rs != null) rs.close();
    		if (stmt != null) stmt.close();
    		if (conn != null) {conn.close();}
    	} catch (Exception e) {
    	}
    }

    protected void close(PreparedStatement stmt, Connection conn) throws DAOException {
        try {
            if (stmt != null) stmt.close();
            if (conn != null) {
                conn.close();
             }
        } catch (Exception e) {
        }
    }

    protected void close(Statement stmt, Connection conn) throws DAOException {
        try {
            if (stmt != null) stmt.close();
            if (conn != null) {
                conn.close();
             }
        } catch (Exception e) {
            throw new DAOException("Erro ao Fechar conex�o: " + e.getMessage());
        }
    }
   
    protected void setCsString(CallableStatement cs, String valor, int i) throws DAOException {
        try {
            if (valor == null) {
                cs.setNull(i, Types.CHAR);
            } else {
                cs.setString(i, valor);
            }
        } catch (Exception e) {
            throw new DAOException("Erro valor no valor informado: " + valor);
        }
    }

    protected void setCsDateTime(CallableStatement cs, Date data, int i) throws DAOException {
        try {
            if (data == null) {
                cs.setNull(i, Types.TIMESTAMP);
            } else {
                cs.setTimestamp(i, new Timestamp(data.getTime()));
            }
        } catch (Exception e) {
            throw new DAOException("Erro no valor informado: " + data);
        }
    }

    protected void setCsDate(CallableStatement cs, Date data, int i) throws DAOException {
        try {
            if (data == null) {
                cs.setNull(i, Types.DATE);
            } else {
//                cs.setDate(i, FormatToolKit.getSqlDate(data));
            }
        } catch (Exception e) {
            throw new DAOException("Erro no valor informado: " + data);
        }
    }
    
    protected void setCsInt(CallableStatement cs, int valor, int i) throws DAOException {
        try {
            if (valor == 0) {
                cs.setNull(i, Types.DECIMAL);
            } else {
                cs.setInt(i, valor);
            }
        } catch (Exception e) {
            throw new DAOException("Erro valor no valor informado: " + valor);
        }
    }
    
    protected void setCsShort(CallableStatement cs, short valor, int i) throws DAOException {
        try {
            if (valor == 0) {
                cs.setNull(i, Types.DECIMAL);
            } else {
                cs.setInt(i, valor);
            }
        } catch (Exception e) {
            throw new DAOException("Erro valor no valor informado: " + valor);
        }
    }

    protected void setCsLong(CallableStatement cs, long valor, int i) throws DAOException {
        try {
            if (valor == 0) {
                cs.setNull(i, Types.DECIMAL);
            } else {
                cs.setLong(i, valor);
            }
        } catch (Exception e) {
            throw new DAOException("Erro valor no valor informado: " + valor);
        }
    }

    protected void setCsDouble(CallableStatement cs, double valor, int i) throws DAOException {
        try {
            if (valor == 0) {
                cs.setNull(i, Types.DECIMAL);
            } else {
                cs.setDouble(i, valor);
            }
        } catch (Exception e) {
            throw new DAOException("Erro valor no valor informado: " + valor);
        }
    }

    protected void setCsFloat(CallableStatement cs, float valor, int i) throws DAOException {
        try {
            if (valor == 0) {
                cs.setNull(i, Types.DECIMAL);
            } else {
                cs.setFloat(i, valor);
            }
        } catch (Exception e) {
            throw new DAOException("Erro valor no valor informado: " + valor);
        }
    }
    
    public List<ProdutoTesourariaDataObject> obterListaProdutosTesouraria() throws DAOException {
        List<ProdutoTesourariaDataObject> lista = new ArrayList<ProdutoTesourariaDataObject>();
        Connection conn = null;
        CallableStatement cs = null;
        ResultSet rs = null;
        try {
            String query = "{call " + PROCEDURE_OBTER_LISTA_PRODUTOS + "(?)}";
            // Preparar a chamada da Stored Procedure
            conn = this.getConnection();
            cs = conn.prepareCall(query);
            // Definir par�metros da Stored Procedure
            this.setCsString(cs, null, 1);
            // Executar a Stored Procedure
            rs = cs.executeQuery();
            while (rs.next()) {
                log.debug("Recuperar informa��es da Stored Procedure de recupera��o da Planilha.");
                // Recuperar informa��es da Stored Procedure
                ProdutoTesourariaDataObject data = new ProdutoTesourariaDataObject(); 
                data.setCodigo(rs.getInt("cProdtOperTesou"));
                data.setDescricao(rs.getString("rProdtOperTesou"));
                data.setSituacao(rs.getShort("cIndcdSitReg"));
                lista.add(data);
            }
        } catch (Exception e) {
            log.error(e, "Erro ao executar a Stored Procedure de recupera��o da Produtos. [" + PROCEDURE_OBTER_LISTA_PRODUTOS + "]");
            throw new DAOException("Problemas ao recuperar lista de Produto de Tesouraria: " + e.getMessage());
        } finally {
            // Fechar Conex�o
            close(rs,cs, conn);
        }
        log.debug(this, "Recupera��o da lista de produtos de tesouraria realizada com sucesso.");
        return lista;
    } 
    
}