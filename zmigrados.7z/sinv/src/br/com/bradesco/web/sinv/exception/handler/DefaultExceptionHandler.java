package br.com.bradesco.web.sinv.exception.handler;

import br.com.bradesco.web.aq.application.error.BradescoBaseException;
import br.com.bradesco.web.aq.application.error.config.IExceptionConfig;
import br.com.bradesco.web.aq.application.error.handler.BradescoApplicationExceptionHandler;
import br.com.bradesco.web.aq.application.util.faces.BradescoFacesUtils;
import br.com.bradesco.web.sinv.exception.SINVExceptionConstants;
import br.com.bradesco.web.sinv.service.provider.log.contexto.ErroContextLog;
import br.com.bradesco.web.sinv.service.provider.log.helper.ContextoLogConstant;

public class DefaultExceptionHandler extends BradescoApplicationExceptionHandler {

    /**
     * CTE com a key da mensagem i18n da etiqueta do campo de mensagem geral de exce��o.
     */
    public static final String MENSAGEM_GERAL_LABEL_KEY = "shopcredit.erro.mensagem.geral.label";
    
    /**
     * CTE com a key da mensagem i18n da etiqueta do campo de mensagem detalhado de exce��o.
     */
    public static final String MENSAGEM_DETALHADO_LABEL_KEY = "shopcredit.erro.mensagem.detalhado.label";
    
    /**
     * Identificador do atributo baixo ao que armazena-se o valor i18n da mensagem
     * associado ao atributo 'redirectMessageId' do objeto ExceptionConfig recebido
     * pelo handler.
     */
    public static final String REDIRECT_MESSAGE_LABEL_KEY = "shopcredit.erro.mensagem.redirect.label";
   
    /**
     * Constructor.
     * 
     */
    public DefaultExceptionHandler() {
        super();
    }

    /**
     * Gera um tra�ado de log se a configura��o recebida assim indicar. A
     * criticidade do tra�ado de log � indicada para a configura��o recebida.
     * 
     * @see br.com.bradesco.web.aq.application.error.handler.BradescoApplicationExceptionHandler#
     *      writeLog(br.com.bradesco.web.aq.application.error.BradescoApplicationException,
     *      br.com.bradesco.web.aq.application.error.config.IExceptionConfig)
     * @param exception
     *            exce��o tratada.
     * @param exceptionConfig
     *            configura��o do Gestor de Erros para a exce��o recebida.
     */
    protected void writeLog(Exception exception, IExceptionConfig exceptionConfig) {
        
        boolean isErrorLoggable = true;
        
        if (exception instanceof BradescoBaseException) {
            isErrorLoggable = ((BradescoBaseException) 
                            exception).isLoggable();
            int exceptionLogLevel = ((BradescoBaseException) 
                            exception).getLogLevel();
            
            if (exceptionLogLevel != BradescoBaseException.DEFAULT_LOG_LEVEL) {
                exceptionConfig.setLogLevel(exceptionLogLevel);
            }
        }
        
        if (isErrorLoggable) {   
            ErroContextLog contexto = new ErroContextLog();
             
            contexto.setAttribute(ContextoLogConstant.INSTRUCAO_ERRO, getExceptionInstrucao(exception));
            contexto.setAttribute(ContextoLogConstant.MENSAGEM_ERRO,  getMensagemException(exception));
            contexto.setAttribute(ContextoLogConstant.CODIGO_RETORNO_TRANSACAO_ERRO, 
                                  getCodigoRetornoException(exception));
            
            contexto.setAttribute(ContextoLogConstant.ERRO_REPORTADO, exception);
            contexto.setAttribute(ContextoLogConstant.CAMADA_ERRO, getCamada(exception));
            contexto.setAttribute(ContextoLogConstant.CODIGO_SERVICO, 
                                  getCodigoTransacaoException(exception));
            
            if (getLogger() != null) {
                getLogger().log(contexto);
            }
        }
        super.writeLog(exception, exceptionConfig);
    }
    
    /**
     * 
     * Obt�m a instru��o que a exce��o foi for�ada.
     * 
     * @param e objeto tipo Exception que representa o erro tratadao.
     * @return instru��o em formato String.
     */
    protected String getExceptionInstrucao(Exception e) {
        return "EXCEPTION GERAL";
    }
    
    /**
     * 
     * Obt�m a mensagem associada ao erro tratado.
     * 
     * @param e objeto tipo Exception que representa o erro tratadao.
     * @return mensagem de exce��o em formato String.
     */
    protected String getMensagemException(Exception e) {
        return "Excecao em geral";
    }
    
    /**
     * 
     * Obt�m o c�digo de retorno associado ao erro tratado.
     * 
     * @param e objeto tipo Exception que representa o erro tratadao.
     * @return codigo de retorno em formato String.
     */
    protected String getCodigoRetornoException(Exception e) {
        return SINVExceptionConstants.INSTRUCAO_EXCEPCAO_GERAL;
    }
    
    /**
     * 
     * Obt�m a camada de aplica��o que o erro remeteu.
     * 
     * @param e objeto tipo Exception que representa o erro tratadao.
     * @return camada em formato String.
     */
    protected String getCamada(Exception e) {
        return SINVExceptionConstants.CAMADA_APRESENTACAO_ID;
    }
    
    /**
     * 
     * Obt�m a camada de aplica��o que o erro remeteu.
     * 
     * @param e objeto tipo Exception que representa o erro tratadao.
     * @return camada em formato String.
     */
    protected String getCodigoTransacaoException(Exception e) {
        return "";
    }
    
    /**
     * 
     * Implementa��o "by default" n�o realiza nenhuma a��o.
     * 
     * @see br.com.bradesco.web.aq.application.error.handler.AbstractBaseExceptionHandlerImpl
     * #beforePerformForward(java.lang.Exception,
     *      br.com.bradesco.web.aq.application.error.config.IExceptionConfig)
     * @param aException
     *            exce��o a ser tratada.
     * @param config
     *            configura��o do Gestor de Erros necess�ria para o tratamento
     * @return true no caso de permitir o redirect; false no caso de tranpor-se
     *         a configura��o de redirect.
     */
    protected boolean beforePerformForward(Exception aException, IExceptionConfig config) {
        
        BradescoFacesUtils.addGlobalErrorFacesMessage(MENSAGEM_DETALHADO_LABEL_KEY, aException.getLocalizedMessage());
        
        BradescoFacesUtils.addGlobalErrorFacesMessage(MENSAGEM_GERAL_LABEL_KEY, aException.getMessage());

        BradescoFacesUtils.addGlobalErrorFacesMessage(REDIRECT_MESSAGE_LABEL_KEY, BradescoFacesUtils.getLocalizedMessage(config.getRedirectMessageId()));

        return true;
    }

}

