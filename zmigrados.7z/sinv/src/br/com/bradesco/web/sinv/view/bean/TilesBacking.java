package br.com.bradesco.web.sinv.view.bean;

public class TilesBacking {
    
	private String testProperty;
	
    public String pressMe() {
		return ("nav_page4");
	}

	@SuppressWarnings("unused")
	public String getTestProperty() {	
		if(true) throw new NullPointerException("testeando excepciones en la fase de render");	
		return testProperty;
	}

	public void setTestProperty(String testProperty) {
		this.testProperty = testProperty;
	}  
    
}
