package br.com.bradesco.web.sinv.service.data.dataobject.exportacoes;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

public class ExportacaoDataObject <DadosExportacao>{

	private String nome;
	
	private List<DadosExportacao> listaDeDadosExportacao;

	public ExportacaoDataObject(String nome) {
		super();
		this.nome = nome;
	}
	public ExportacaoDataObject(String nome, List<DadosExportacao> listaDeDadosExportacao) {
		this(nome);
		this.listaDeDadosExportacao = listaDeDadosExportacao;
	}
	
	@SuppressWarnings("unchecked")
	public ExportacaoDataObject(String nome, DadosExportacao... listaDeDadosExportacao) {
		this(nome);
		ArrayList<DadosExportacao> arrayList = new ArrayList<DadosExportacao>();
		CollectionUtils.addAll(arrayList, listaDeDadosExportacao);
		this.listaDeDadosExportacao = arrayList;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String name) {
		this.nome = name;
	}

	public void addSubRelatorio(DadosExportacao dadosExportacao) {
		if (this.listaDeDadosExportacao == null) {
			this.listaDeDadosExportacao = new ArrayList<DadosExportacao>();
		}
		this.listaDeDadosExportacao.add(dadosExportacao);
	}
	
	public List<DadosExportacao> getListaDeDadosExportacao() {
		return listaDeDadosExportacao;
	}
}
