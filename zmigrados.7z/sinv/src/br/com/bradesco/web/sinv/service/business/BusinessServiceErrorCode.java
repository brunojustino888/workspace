package br.com.bradesco.web.sinv.service.business;

public class BusinessServiceErrorCode {

    /**
     * Prefixo que tem os c�digos de erro de camada de DAO.
     */
    public static final String PREFIX_EXCEPTION_CODE  = "error.service.business.";

    /**
     * Erro c�digo lan�ado em erro gen�rico e por erro em um business service.
     */
    public static final String DEFAULT_EXCEPTION_CODE = PREFIX_EXCEPTION_CODE + "default";

    /**
     * 
     * Construtor.
     *
     */
    public BusinessServiceErrorCode() {
        super();
    }
    
}
