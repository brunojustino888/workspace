package br.com.bradesco.web.sinv.exception;

import br.com.bradesco.web.aq.application.error.BradescoBaseException;

public class SINVServiceException extends BradescoBaseException {

    /**
     * ID da classe.
     */
    private static final long serialVersionUID = 2079167605431107526L;
    
    /**
     * 
     * Construtor da exce��o.
     * 
     * @param message mensagem interna da exce��o.
     * @param code codigo interno de exce��o utilizado para obter uma mensagem
     *        i18n.
     */
    public SINVServiceException(String message, String code) {
        this(message, null, code);
    }
    
    /**
     * 
     * Construtor da exce��o.
     * 
     * @param message mensagem interna da exce��o.
     * @param cause objeto Throwable que d� origem � exce��o.
     * @param code codigo interno de exce��o.
     */
    public SINVServiceException(String message, Throwable cause, String code) {
              
    } 
    
}
