package br.com.bradesco.web.sinv.service.data.dataobject.exportacoes;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/*
 * SubRelatorio(conceitual)
 * P�gina(Text)
 * Planilha(Excel)
 */
public class DadosExportacaoDataObject implements Serializable {

	private static final long serialVersionUID = -9010370206595766211L;

	private String nome = "";
	
	private final String titulo;
	
	private RegistroDeExportacao cabecalho;

	private List<RegistroDeExportacao> registros;
	
	private Map<Integer, Integer> colunmsSizeMap = new TreeMap<Integer, Integer>(); 

	public DadosExportacaoDataObject(String titulo) {
		this(titulo, titulo, new RegistroDeExportacao(), new ArrayList<RegistroDeExportacao>());
	}

	public DadosExportacaoDataObject(String nome, String titulo) {
		this(nome, titulo, new RegistroDeExportacao(), new ArrayList<RegistroDeExportacao>());
	}

	public DadosExportacaoDataObject(String nome, String titulo, RegistroDeExportacao cabecalho, List<RegistroDeExportacao> registro) {
		this.nome = nome;
		this.titulo = titulo;
		this.cabecalho = cabecalho;
		this.registros = registro;
	}

	public void addRegistro(RegistroDeExportacao registro) {
		registros.add(registro);
		if(colunmsSizeMap.isEmpty()){
			setColumnsSize(cabecalho);
		}
		setColumnsSize(registro);
	}

	private void setColumnsSize(RegistroDeExportacao registro) {
		for (int i = 0; i < registro.getQuantidadeColunas(); i++) {
			Object obj = registro.getConteudo().get(i);
			Integer i1 = colunmsSizeMap.get(i);
			Integer i2 = obj == null?0:obj.toString().trim().length();
			colunmsSizeMap.put(i, Math.max(i1 == null?0:i1, i2));
		}
	}
	
	public Map<Integer, Integer> getColunmsSizeMap() {
		return colunmsSizeMap;
	}
	
	public int getColunmSize(int column) {
		return colunmsSizeMap.get(column);
	}

	public RegistroDeExportacao getCabecalho() {
		return cabecalho;
	}

	public String getNome() {
		return nome;
	}

	public List<RegistroDeExportacao> getRegistros() {
		return registros;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setCabecalho(RegistroDeExportacao cabecalho) {
		this.cabecalho = cabecalho;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
