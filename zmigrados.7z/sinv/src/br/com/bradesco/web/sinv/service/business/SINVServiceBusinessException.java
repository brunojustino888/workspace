package br.com.bradesco.web.sinv.service.business;

import br.com.bradesco.web.sinv.exception.SINVException;

public class SINVServiceBusinessException extends SINVException {
 
	private static final long serialVersionUID = 1471970131306096080L;

	public SINVServiceBusinessException() {
		super();
	}

	public SINVServiceBusinessException(String arg0) {
		super(arg0);
	}

	public SINVServiceBusinessException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public SINVServiceBusinessException(Throwable arg0) {
		super(arg0);
	}

}
