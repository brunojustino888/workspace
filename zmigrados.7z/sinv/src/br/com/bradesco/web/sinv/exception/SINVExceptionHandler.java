package br.com.bradesco.web.sinv.exception;

import br.com.bradesco.web.aq.application.error.BradescoApplicationException;
import br.com.bradesco.web.aq.application.error.config.IExceptionConfig;
import br.com.bradesco.web.aq.application.error.handler.BradescoApplicationExceptionHandler;

public class SINVExceptionHandler extends BradescoApplicationExceptionHandler {

    /**
     * CTE que indica a key da mensagem i18n correspondente � etiqueta
     * do campo que mostra o codigo de erro.
     */
    public static final String CODIGO_ERRO_LABEL_KEY = "sinv.erro.codigo.label";
    
    /**
     * Comentarios para el Constructor.
     * 
     */
    public SINVExceptionHandler() {
        super();
    }

    /**
     * Acciones a realizar antes de enviar la alerta configurada.
     * 
     * @see br.com.bradesco.web.aq.application.error.handler.BradescoApplicationExceptionHandler#beforePerformAlert(br.com.bradesco.web.aq.application.error.BradescoApplicationException, br.com.bradesco.web.aq.application.error.config.IExceptionConfig)
     */
    protected boolean beforePerformAlert(BradescoApplicationException exception, IExceptionConfig exceptionConfig) {
        return super.beforePerformAlert(exception, exceptionConfig);
    }

    /**
     * Acciones a realizar antes de realizar forward a la p�gina de error.
     * 
     * @see br.com.bradesco.web.aq.application.error.handler.BradescoApplicationExceptionHandler#beforePerformForward(br.com.bradesco.web.aq.application.error.BradescoApplicationException, br.com.bradesco.web.aq.application.error.config.IExceptionConfig)
     */
    protected boolean beforePerformForward(BradescoApplicationException exception, IExceptionConfig exceptionConfig) {
        return super.beforePerformForward(exception, exceptionConfig);
    }

    /**
     * Acciones a realizar antes de realizar el logout configurado.
     * 
     * @see br.com.bradesco.web.aq.application.error.handler.BradescoApplicationExceptionHandler#beforePerformLogout(br.com.bradesco.web.aq.application.error.BradescoApplicationException, br.com.bradesco.web.aq.application.error.config.IExceptionConfig)
     */
    protected boolean beforePerformLogout(BradescoApplicationException exception, IExceptionConfig exceptionConfig) {
        return super.beforePerformLogout(exception, exceptionConfig);
    }

    /**
     * Tratamiento de la excepci�n recibida. 
     * 
     * @see br.com.bradesco.web.aq.application.error.handler.BradescoApplicationExceptionHandler#handleException(java.lang.Exception, br.com.bradesco.web.aq.application.error.config.IExceptionConfig, boolean)
     */
    public void handleException(Exception exception, IExceptionConfig exceptionConfig, boolean redirect) {       
        if (exception instanceof SINVException) {
            // Establecer aqu� el comportamiento deseado para las excepciones de �ste aplicativo.
            super.handleException(exception, exceptionConfig, redirect);          
        } else {
            super.handleException(exception, exceptionConfig, redirect);
        }
    }

    /**
     * Escritura en log (en caso de estar configurado).
     * 
     * @see br.com.bradesco.web.aq.application.error.handler.BradescoApplicationExceptionHandler#writeLog(br.com.bradesco.web.aq.application.error.BradescoApplicationException, br.com.bradesco.web.aq.application.error.config.IExceptionConfig)
     */
    protected void writeLog(BradescoApplicationException exception, IExceptionConfig exceptionConfig) {
        super.writeLog(exception, exceptionConfig);
    }

}
