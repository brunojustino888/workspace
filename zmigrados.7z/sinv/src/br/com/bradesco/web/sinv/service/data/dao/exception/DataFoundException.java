/*
 * @(#)DataFoundException.java        1.0 05/11/2004
 *
 * Copyright (c) 2004 Bradesco S/A.
 * Osasco, SP - Brazil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bradesco S/A. ("Confidential Information").  You shall not disclose 
 * such Confidential Information and shall not use, publish, alter 
 * or otherwise make it available, directly or indirectly, without the prior 
 * written consent of Bradesco S/A.
 */
package br.com.bradesco.web.sinv.service.data.dao.exception;

/**
 * Exce��es retornadas pelos Data Access Objects em caso de erro no acesso
 * ao banco de dados.
 * @author Jo�o Germano Filho
 * @version 1.0
 */
public class DataFoundException extends Exception {

	private static final long serialVersionUID = -1297149221512872835L;

	/** Cria uma nova inst�ncia de DataFoundException. */
	public DataFoundException() {
		super();
	}

	/**
	 * Cria uma nova inst�ncia de DataFoundException.
	 * @param msg, String contendo a mensagem que ser� apresentada
	 */ 
	public DataFoundException( String msg ) {
		super( msg );
	}

	/**
	 * Cria uma nova inst�ncia de DataFoundException.
	 * @param e, Exception contendo o erro ocorrido
	 */ 
	public DataFoundException( Exception e ) {
		super( (e == null) ? null : e.toString() );
	}
}