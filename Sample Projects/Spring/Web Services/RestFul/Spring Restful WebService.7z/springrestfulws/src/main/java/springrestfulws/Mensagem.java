package springrestfulws;

/**
 * Utilizado como POJO modelo.
 * 
 * @author brunoj - Bruno Justino
 */
public class Mensagem {

	/**
	 * Representa o ID da mensagem.
	 */
	private final long id;
	
	/**
	 * Representa o conte�do da mensagem.
	 */
	private final String content;

	/**
	 * Construtor inicializando valores dos atributo.
	 * @param id - long - id da mensagem.
	 * @param content - String - conte�do da mensagem.
	 */
	public Mensagem(long id, String content) {
		this.id = id;
		this.content = content;
	}

	/**
	 * M�todo get do atributo id.
	 * @return id - long - id da mensagem.
	 */
	public long getId() {
		return this.id;
	}

	/**
	 * M�todo get do atributo content.
	 * @return content - String - conte�do da mensagem.
	 */
	public String getContent() {
		return this.content;
	}

}