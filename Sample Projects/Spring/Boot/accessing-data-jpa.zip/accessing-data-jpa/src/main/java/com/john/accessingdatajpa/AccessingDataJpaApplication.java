package com.john.accessingdatajpa;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.john.model.Customer;
import com.john.repositories.CustomerRepository;

@SpringBootApplication
@EnableJpaRepositories("com.john.repositories")
@EntityScan("com.john..model")
public class AccessingDataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccessingDataJpaApplication.class, args);
	}

	private static final Logger LOGGER = LoggerFactory.getLogger(AccessingDataJpaApplication.class);

	@Bean
	public CommandLineRunner demo(CustomerRepository repository) {
		
		return (args) -> {

			this.saveCustomer(repository);

			this.findAllCustomers(repository);

			this.findCustomerById(repository,1L);
			
			this.findCustomerByLastName(repository,"Giacomini da Silva Justino");

		};
	}

	/**
	 * Método utilizado para persistir alguns clientes.
	 * @param repository - CustomerRepository - interface de manipulação de clientes.
	 */
	private void saveCustomer(CustomerRepository repository) {
		LOGGER.info("-------------------------------");
		LOGGER.info("INÍCIO - Persisitindo clientes");
		LOGGER.info("-------------------------------");
		repository.save(new Customer("Bruno", "Alves Justino"));
		repository.save(new Customer("John", "Teste 888"));
		repository.save(new Customer("Vinicius", "Giacomini da Silva Justino"));
		repository.save(new Customer("Miguel", "Giacomini da Silva Justino"));
		LOGGER.info("-------------------------------");
		LOGGER.info("FIM - Persisitindo clientes");
		LOGGER.info("-------------------------------");
		LOGGER.info("");
	}

	/**
	 * Utilizado para encontrar todos os clientes.
	 * @param repository - CustomerRepository - interface de manipulação de clientes.
	 */
	private void findAllCustomers(CustomerRepository repository) {
		LOGGER.info("-------------------------------");
		LOGGER.info("INÍCIO - Listando todos os clientes");
		LOGGER.info("-------------------------------");
		for (Customer customer : repository.findAll()) {
			LOGGER.info(customer.toString());
		}
		//		repository.findByLastName("Teste 888").forEach(aux -> {
		//			LOGGER.info(aux.toString());
		//		});
		LOGGER.info("-------------------------------");
		LOGGER.info("FIM - Listando todos os clientes");
		LOGGER.info("-------------------------------");
		LOGGER.info("");
	}

	/**
	 * Utilizado para encontrar um determinado cliente através da chave primária.
	 * @param repository - CustomerRepository - interface de manipulação de clientes.
	 * @param id - long - chave primária do cliente.
	 */
	private void findCustomerById(CustomerRepository repository, long id) {
		LOGGER.info("-------------------------------");
		LOGGER.info("INÍCIO - Pesquisando cliente específico com chave primária == "+id);
		LOGGER.info("-------------------------------");
		Customer customer = repository.findById(id);
		LOGGER.info("Cliente encontrado com a chave == 1: "+ customer.toString());
		LOGGER.info("-------------------------------");
		LOGGER.info("FIM - Pesquisando cliente específico com chave primária == "+id);
		LOGGER.info("-------------------------------");
		LOGGER.info("");
	}
	
	/**
	 * Utilizadpo para encontrar clientes com o sobrenome recebido.
	 * @param repository - CustomerRepository - interface de manipulação de clientes.
	 * @param sobrenome - String - representa o sobrenome do cliente.
	 */
	private void findCustomerByLastName(CustomerRepository repository, String sobrenome) {
		LOGGER.info("-------------------------------");
		LOGGER.info("INÍCIO - Pesquisando clientes pelo sobrenome == "+sobrenome);
		LOGGER.info("-------------------------------");
		LOGGER.info("Clientes encontrados com o sobrenome == "+sobrenome+":");
		for (Customer aux : repository.findByLastName(sobrenome)) {
			LOGGER.info(aux.toString());
		}
		LOGGER.info("-------------------------------");
		LOGGER.info("FIM - Pesquisando clientes pelo sobrenome == "+sobrenome);
		LOGGER.info("-------------------------------");
		LOGGER.info("");
	}

}