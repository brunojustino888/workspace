package com.john.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * Entidade JPA que representa um determinado cliente.
 * @author Bruno Justino.
 */
@Entity
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	private String firstName;
	private String lastName;

	/**
	 * Construtor de convenção JPA. Não utilizamos este construtor de forma direta.
	 */
	protected Customer() {
	}

	/**
	 * Construtor padrão do objeto cliente.
	 * @param firstName - String - primeiro nome do cliente.
	 * @param lastName  - String - sobrenome do cliente.
	 */
	public Customer(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString() {
		return String.format("Customer[id=%d, firstName='%s', lastName='%s']", this.id, this.firstName, this.lastName);
	}

	/**
	 * Método get().
	 * @return id - Long - chave primária do cliente.
	 */
	public Long getId() {
		return this.id;
	}

	/**
	 * Método get().
	 * @return firstName - String - nome do cliente.
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 * Método get().
	 * @return lastName - String - sobrenome do cliente.
	 */
	public String getLastName() {
		return this.lastName;
	}

}