package com.john.repositories;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import com.john.model.Customer;

/**
 * Interface de manipulação de clientes.
 * @author Bruno Justino.
 */
public interface CustomerRepository extends CrudRepository<Customer, Long> {
	
	/**
	 * Busca uma lista de clientes pelo sobrenome.
	 * @param lastName - String - sobrenome do cliente.
	 * @return List<Customer> - Lista contendo todos clientes com o sobrenome recebido como parâmetro.
	 */
	List<Customer> findByLastName(String lastName);

	/**
	 * Busca um determinado cliente através da chave primária.
	 * @param id - long - Chave primária que representa o código de um determinado cliente.
	 * @return Customer - Objeto que representa um determinado cliente.
	 */
	Customer findById(long id);

}