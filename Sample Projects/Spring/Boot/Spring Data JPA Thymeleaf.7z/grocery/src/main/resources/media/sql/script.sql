DROP TABLE PRODUCT_CATEGORY;
DROP TABLE PRODUCT;
DROP TABLE CUSTOMERS;
DROP TABLE ORDEMN;
DROP TABLE ADRESS;
DROP TABLE ORDER_LINE;
DROP TABLE COMMENT;

CREATE TABLE PRODUCT_CATEGORY (
   ID	                  		bigint auto_increment not null primary key,
   DESCRICAO         		 	varchar(50) not null unique,
   ULTIMA_ATUALIZACAO   		datetime not null,
   USUARIO_ULTIMA_ATUALIZACAO   varchar(20) not null,
   USUARIO_CRIACAO      		varchar(20),
   DATA_CRIACAO         		datetime
);

CREATE TABLE PRODUCT (
   ID	                  		bigint auto_increment not null primary key,
   DESCRICAO         		 	varchar(255) not null,
   NOME         		 		varchar(255) not null unique,
   CATEGORIA_COD				bigint not null,
   PRECO						decimal(10,2) not null,
   QUANTIDADE_ESTOQUE			bigint not null,
   ATIVO						boolean not null,
   ULTIMA_ATUALIZACAO   		datetime not null,
   USUARIO_ULTIMA_ATUALIZACAO   varchar(20) not null,
   USUARIO_CRIACAO      		varchar(20),
   DATA_CRIACAO         		datetime,
   FOREIGN KEY (CATEGORIA_COD) REFERENCES PRODUCT_CATEGORY(ID)
);

CREATE TABLE CUSTOMERS (
   ID	                  		bigint auto_increment not null primary key,
   DOCUMENTO         		 	varchar(255) not null unique,
   EMAIL	         		 	varchar(255) not null unique,
   TELEFONE         		 	varchar(25) not null unique,
   NOME         		 		varchar(255) not null unique,
   RAMO_ATIVIDADE				varchar(255) not null,
   ATIVO						boolean not null,
   ULTIMA_ATUALIZACAO   		datetime not null,
   USUARIO_ULTIMA_ATUALIZACAO   varchar(20) not null,
   USUARIO_CRIACAO      		varchar(20),
   DATA_CRIACAO         		datetime
);

CREATE TABLE ADRESS (
   ID	                  		bigint auto_increment not null primary key,
   CLIENTE_COD         		 	bigint not null,
   LOGRADOURO         		 	varchar(255) not null,
   NUMERO	         		 	varchar(25) not null,
   CEP	         		 		varchar(25) not null,
   BAIRRO						varchar(255) not null,
   CIDADE						varchar(255) not null,
   ESTADO						varchar(255) not null,
   PAIS							varchar(255) not null,
   REFERENCIA					varchar(255) not null,
   ENDERECO_PRINCIPAL			boolean not null,
   ULTIMA_ATUALIZACAO   		datetime not null,
   USUARIO_ULTIMA_ATUALIZACAO   varchar(20) not null,
   USUARIO_CRIACAO      		varchar(20),
   DATA_CRIACAO         		datetime,
   FOREIGN KEY(CLIENTE_COD) REFERENCES CUSTOMERS(ID)
);

CREATE TABLE ORDEMN (
   ID	                  		bigint auto_increment not null primary key,
   CLIENTE_COD         		 	bigint not null,
   VALOR            		 	decimal(10,2) not null,
   STATUS			      		varchar(30) not null,
   OBSERVACAO		      		varchar(255) not null,
   ULTIMA_ATUALIZACAO   		datetime not null,
   USUARIO_ULTIMA_ATUALIZACAO   varchar(20) not null,
   USUARIO_CRIACAO      		varchar(20),
   DATA_CRIACAO         		datetime,
   FOREIGN KEY(CLIENTE_COD) REFERENCES CUSTOMERS(ID)
);

CREATE TABLE COMMENT (
   ID	                  		bigint auto_increment not null primary key,
   COMENTARIO         		 	varchar(255) not null,
   PRODUTO_COD     		 		bigint not null,
   ULTIMA_ATUALIZACAO   		datetime not null,
   USUARIO_ULTIMA_ATUALIZACAO   varchar(20) not null,
   USUARIO_CRIACAO      		varchar(20),
   DATA_CRIACAO         		datetime,
   FOREIGN KEY (PRODUTO_COD) REFERENCES PRODUCT(ID)
);

CREATE TABLE ORDER_LINE (
   ID	                  		bigint auto_increment not null primary key,
   DESCRICAO         		 	varchar(255) not null,
   PEDIDO_COD     		 		bigint not null,
   QUANTIDADE     		 		bigint not null,
   VALOR	     		 		decimal(10,2) not null,
   ULTIMA_ATUALIZACAO   		datetime not null,
   USUARIO_ULTIMA_ATUALIZACAO   varchar(20) not null,
   USUARIO_CRIACAO      		varchar(20),
   DATA_CRIACAO         		datetime,
   FOREIGN KEY (PEDIDO_COD) REFERENCES ORDEMN(ID)
);

INSERT INTO PRODUCT_CATEGORY ( 
  DESCRICAO, 
  ULTIMA_ATUALIZACAO, USUARIO_ULTIMA_ATUALIZACAO, USUARIO_CRIACAO, DATA_CRIACAO) values(
  'Limpeza',
  CURTIME(),'SISTEMA','SISTEMA', CURTIME()
);

INSERT INTO PRODUCT_CATEGORY ( 
  DESCRICAO, 
  ULTIMA_ATUALIZACAO, USUARIO_ULTIMA_ATUALIZACAO, USUARIO_CRIACAO, DATA_CRIACAO) values(
  'Alimento',
  CURTIME(),'SISTEMA','SISTEMA', CURTIME()
);

INSERT INTO PRODUCT_CATEGORY ( 
  DESCRICAO, 
  ULTIMA_ATUALIZACAO, USUARIO_ULTIMA_ATUALIZACAO, USUARIO_CRIACAO, DATA_CRIACAO) values(
  'Ferramenta',
  CURTIME(),'SISTEMA','SISTEMA', CURTIME()
);

INSERT INTO PRODUCT_CATEGORY ( 
  DESCRICAO, 
  ULTIMA_ATUALIZACAO, USUARIO_ULTIMA_ATUALIZACAO, USUARIO_CRIACAO, DATA_CRIACAO) values(
  'Bebida',
  CURTIME(),'SISTEMA','SISTEMA', CURTIME()
);

INSERT INTO PRODUCT_CATEGORY ( 
  DESCRICAO, 
  ULTIMA_ATUALIZACAO, USUARIO_ULTIMA_ATUALIZACAO, USUARIO_CRIACAO, DATA_CRIACAO) values(
  'T�xtil',
  CURTIME(),'SISTEMA','SISTEMA', CURTIME()
);

INSERT INTO PRODUCT_CATEGORY ( 
  DESCRICAO, 
  ULTIMA_ATUALIZACAO, USUARIO_ULTIMA_ATUALIZACAO, USUARIO_CRIACAO, DATA_CRIACAO) values(
  'Higiene',
  CURTIME(),'SISTEMA','SISTEMA', CURTIME()
);

INSERT INTO PRODUCT (DESCRICAO, NOME, CATEGORIA_COD, PRECO, QUANTIDADE_ESTOQUE, ATIVO, ULTIMA_ATUALIZACAO, USUARIO_ULTIMA_ATUALIZACAO, USUARIO_CRIACAO, DATA_CRIACAO) VALUES (
'P�o franc�s da padaria',
'P�o Franc�s',
2,
0.42,
50,
true,
CURTIME(),
'Sistema',
'Sistema',
CURTIME());

INSERT INTO PRODUCT (DESCRICAO, NOME, CATEGORIA_COD, PRECO, QUANTIDADE_ESTOQUE, ATIVO, ULTIMA_ATUALIZACAO, USUARIO_ULTIMA_ATUALIZACAO, USUARIO_CRIACAO, DATA_CRIACAO) VALUES (
'Sabonete protex limpeza profunda',
'Sabonete Protex',
6,
2.50,
25,
true,
CURTIME(),
'Sistema',
'Sistema',
CURTIME());

INSERT INTO CUSTOMERS (DOCUMENTO, EMAIL, TELEFONE, NOME, RAMO_ATIVIDADE, ATIVO, ULTIMA_ATUALIZACAO, USUARIO_ULTIMA_ATUALIZACAO, USUARIO_CRIACAO, DATA_CRIACAO) VALUES (
'RG 44.830.073-4',
'brunojustino888@gmail.com',
'+55 11 9 4493-2799',
'Bruno Alves Justino',
'Programador',
true,
CURTIME(),
'Sistema',
'Sistema',
CURTIME());

INSERT INTO ADRESS (CLIENTE_COD, LOGRADOURO, NUMERO, CEP, BAIRRO, CIDADE, ESTADO, PAIS, REFERENCIA, ENDERECO_PRINCIPAL, ULTIMA_ATUALIZACAO, USUARIO_ULTIMA_ATUALIZACAO, USUARIO_CRIACAO, DATA_CRIACAO) VALUES (
1,
'Rua S�o Luiz',
'200 B',
'06226-210',
'Rochdale',
'Osasco',
'SP',
'Brasil',
'Pr�ximo � Avenida Cruzeiro do Sul',
true,
CURTIME(),
'Sistema',
'Sistema',
CURTIME());

INSERT INTO ORDEMN (CLIENTE_COD, VALOR, STATUS, OBSERVACAO, ULTIMA_ATUALIZACAO, USUARIO_ULTIMA_ATUALIZACAO, USUARIO_CRIACAO, DATA_CRIACAO) VALUES (
1,
287.56,
'Pago',
'Pedido pago � vista com d�bito.',
CURTIME(),
'Sistema',
'Sistema',
CURTIME());

INSERT INTO COMMENT (COMENTARIO, PRODUTO_COD, ULTIMA_ATUALIZACAO, USUARIO_ULTIMA_ATUALIZACAO, USUARIO_CRIACAO, DATA_CRIACAO) VALUES (
'Lote danificado.',
2, 
CURTIME(),
'Sistema',
'Sistema',
CURTIME());

INSERT INTO ORDER_LINE (DESCRICAO, PEDIDO_COD, QUANTIDADE, VALOR, ULTIMA_ATUALIZACAO, USUARIO_ULTIMA_ATUALIZACAO, USUARIO_CRIACAO, DATA_CRIACAO) VALUES (
'P�o de mel.',
1, 
190,
287.56,
CURTIME(),
'Sistema',
'Sistema',
CURTIME());

SELECT * FROM ORDER_LINE;
SELECT * FROM COMMENT;
SELECT * FROM ORDEMN;
SELECT * FROM ADRESS;
SELECT * FROM CUSTOMERS;
SELECT * FROM PRODUCT_CATEGORY;
SELECT * FROM PRODUCT;