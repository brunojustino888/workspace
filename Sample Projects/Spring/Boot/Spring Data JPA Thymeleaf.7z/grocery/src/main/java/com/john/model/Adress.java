package com.john.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="ADRESS")
public class Adress implements Serializable {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Id - chave prim�ria.
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private Long idNumber;
	
	/**
	 * Representa o cliente dono do endere�o.
	 */
	@ManyToOne
	private Customer customer;
	
	/**
	 * Representa o c�digo do dono do endere�o.
	 */
	@Column(name="CLIENTE_COD")
	private Long clientCod;
	
	/**
	 * Representa o logradouro do endere�o.
	 */
	@Column(name="LOGRADOURO")
	private String logradouro;
	
	/**
	 * N�mero do endere�o.
	 */
	@Column(name="NUMERO")
	private String numero;
	
	/**
	 * C�digo postal do endere�o.
	 */
	@Column(name="CEP")
	private String cep;
	
	/**
	 * Flag indicadora de endere�o principal.
	 */
	@Column(name="ENDERECO_PRINCIPAL")
	private boolean isEnderoPrincipal;
	
	/**
	 * Bairro do endere�o
	 */
	@Column(name="BAIRRO")
	private String bairro;
	
	/**
	 * Cidade do endere�o.
	 */
	@Column(name="CIDADE")
	private String cidade;
	
	/**
	 * Estado do endere�o.
	 */
	@Column(name="ESTADO")
	private String estado;
	
	/**
	 * Pa�s do endere�o.
	 */
	@Column(name="PAIS")
	private String pais;
	
	/**
	 * Refer�ncia do endere�o.
	 */
	@Column(name="REFERENCIA")
	private String referencia;
	
	/**
	 * �ltima atualiza��o do registro na base de dados.
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ULTIMA_ATUALIZACAO")
	private Date atualizacao;
	
	/**
	 * Usu�rio da �ltima atualiza��odo registro.
	 */
	@Column(name="USUARIO_ULTIMA_ATUALIZACAO")
	private String usuarioUltimaAtualizacao;
	
	/**
	 * Usu�rio de cria��o do registro.
	 */
	@Column(name="USUARIO_CRIACAO")
	private String usuarioCriacao;
	
	/**
	 * Data da cria��o do registro na base de dados.
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DATA_CRIACAO")
	private Date dataCriacao;
	
	
	/**
	 * M�todo get do atributo idNumber.
	 * @return idNumber - Long - chave prim�ria. 
	 */
	public Long getIdNumber() {
		return this.idNumber;
	}

	/**
	 * M�todo set do atributo idNumber.
	 * @param idNumber - Long - chave prim�ria. 
	 */
	public void setIdNumber(final Long idNumber) {
		this.idNumber = idNumber;
	}

	/**
	 * Get do customer.
	 * @return customer - Customer - representa o cliente.
	 */
	public Customer getCustomer() {
		return this.customer;
	}

	/**
	 * Set do customer.
	 * @param customer - Customer - representa o cliente.
	 */
	public void setCustomer(final Customer customer) {
		this.customer = customer;
	}

	/**
	 * Get do c�digo do cliente
	 * @return clientCod - Long - representa o dono do endere�o. 
	 */
	public Long getClientCod() {
		return this.clientCod;
	}

	/**
	 * Set do c�digo do cliente
	 * @param clientCod - Long - representa o dono do endere�o. 
	 */
	public void setClientCod(final Long clientCod) {
		this.clientCod = clientCod;
	}
	
	/**
	 * M�todo get do atributo logradouro.
	 * @return logradouro - String - logradouro do endere�o.
	 */
	public String getLogradouro() {
		return this.logradouro;
	}
	
	/**
	 * M�todo set do atributo logradouro.
	 * @param logradouro - String - logradouro do endere�o.
	 */
	public void setLogradouro(final String logradouro) {
		this.logradouro = logradouro;
	}
	
	/**
	 * M�todo get do atributo numero.
	 * @return numero - String - numero do endere�o.
	 */
	public String getNumero() {
		return this.numero;
	}
	
	/**
	 * M�todo set do atributo numero.
	 * @param numero - String - numero do endere�o.
	 */
	public void setNumero(final String numero) {
		this.numero = numero;
	}
	
	/**
	 * M�todo set do atributo cep.
	 * @return cep - String - cep do endere�o.
	 */
	public String getCep() {
		return this.cep;
	}
	
	/**
	 * M�todo set do atributo cep.
	 * @param cep - String - cep do endere�o.
	 */
	public void setCep(final String cep) {
		this.cep = cep;
	}
	
	/**
	 * M�todo get do atributo isEnderoPrincipal.
	 * @return isEnderoPrincipal - boolean - endere�o principal do cliente.
	 */
	public boolean isEnderoPrincipal() {
		return this.isEnderoPrincipal;
	}
	
	/**
	 * M�todo set do atributo isEnderoPrincipal.
	 * @param isEnderoPrincipal - boolean - endere�o principal do cliente.
	 */
	public void setEnderoPrincipal(final boolean isEnderoPrincipal) {
		this.isEnderoPrincipal = isEnderoPrincipal;
	}
	
	/**
	 * M�todo get do atributo bairro.
	 * @return bairro - String - bairro do cliente.
	 */
	public String getBairro() {
		return this.bairro;
	}
	
	/**
	 * M�todo set do atributo bairro.
	 * @param bairro - String - bairro do cliente.
	 */
	public void setBairro(final String bairro) {
		this.bairro = bairro;
	}
	
	/**
	 * M�todo get do atributo cidade.
	 * @return cidade - String - cidade do endere�o.
	 */
	public String getCidade() {
		return this.cidade;
	}
	
	/**
	 * M�todo set do atributo cidade.
	 * @param cidade - String - cidade do endere�o.
	 */
	public void setCidade(final String cidade) {
		this.cidade = cidade;
	}
	
	/**
	 * M�todo get do atributo estado.
	 * @return estado - String - estado do endere�o.
	 */
	public String getEstado() {
		return this.estado;
	}
	
	/**
	 * M�todo set do atributo estado.
	 * @param estado - String - estado do endere�o.
	 */
	public void setEstado(final String estado) {
		this.estado = estado;
	}
	
	/**
	 * M�todo get do atributo pais.
	 * @return pais - String -pais do endere�o.
	 */
	public String getPais() {
		return this.pais;
	}
	
	/**
	 * M�todo set do atributo pais.
	 * @param pais - String -pais do endere�o.
	 */
	public void setPais(final String pais) {
		this.pais = pais;
	}
	
	/**
	 * M�todo get do atributo referencia.
	 * @return referencia - String - refer�ncia do endere�o.
	 */
	public String getReferencia() {
		return this.referencia;
	}
	
	/**
	 * M�todo set do atributo referencia.
	 * @param referencia - String - refer�ncia do endere�o.
	 */
	public void setReferencia(final String referencia) {
		this.referencia = referencia;
	}
	
	/**
	 * M�todo get do atributo atualizacao.
	 * @return atualizacao - Date - data da atualiza��o do registro.
	 */
	public Date getAtualizacao() {
		return this.atualizacao;
	}

	/**
	 * M�todo set do atributo atualizacao.
	 * @param atualizacao - Date - data da atualiza��o do registro.
	 */
	public void setAtualizacao(final Date atualizacao) {
		this.atualizacao = atualizacao;
	}

	/**
	 * M�todo get do atributo usuarioUltimaAtualizacao.
	 * @return usuarioUltimaAtualizacao - String - usu�rio que realizou a �ltima atualiza��o de registro.
	 */
	public String getUsuarioUltimaAtualizacao() {
		return this.usuarioUltimaAtualizacao;
	}

	/**
	 * M�todo set do atributo usuarioUltimaAtualizacao.
	 * @param usuarioUltimaAtualizacao - String - usu�rio que realizou a �ltima atualiza��o de registro.
	 */
	public void setUsuarioUltimaAtualizacao(final String usuarioUltimaAtualizacao) {
		this.usuarioUltimaAtualizacao = usuarioUltimaAtualizacao;
	}

	/**
	 * M�todo get do atributo usuarioCriacao.
	 * @return usuarioCriacao - String - usu�rio da cria��o do registro.
	 */
	public String getUsuarioCriacao() {
		return this.usuarioCriacao;
	}

	/**
	 * M�todo set do atributo usuarioCriacao.
	 * @param usuarioCriacao - String -  usu�rio da cria��o do registro.
	 */
	public void setUsuarioCriacao(final String usuarioCriacao) {
		this.usuarioCriacao = usuarioCriacao;
	}

	/**
	 * M�todo get do atributo dataCriacao.
	 * @return dataCriacao - Date - data da cria��o do registro.
	 */
	public Date getDataCriacao() {
		return this.dataCriacao;
	}

	/**
	 * M�todo set do atributo dataCriacao.
	 * @param dataCriacao - Date - data da cria��o do registro.
	 */
	public void setDataCriacao(final Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

}