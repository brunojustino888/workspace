package com.john.model;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="PRODUCT")
public class Product implements Serializable {

	/**
	 * Serial version UID.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Id - chave prim�ria.
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private Long idNumber;

	/**
	 * Representa o nome de um determinado produto.
	 */
	@Column(name="NOME")
	private String nome;
	
	/**
	 * Representa o nome de um determinado produto.
	 */
	@Column(name="DESCRICAO")
	private String descricao;
	
	/**
	 * Representa o nome de um determinado cliente.
	 */
	@OneToOne
    @JoinColumn(name="ID")
	private ProductCategory categoria;
	
	/**
	 * Representa a chave estrangeira.
	 */
    @Column(name="CATEGORIA_COD")
	private Long idCategoria;
	
	/**
	 * Representa os coment�rios de um determinado produto.
	 */
	@OneToMany(mappedBy = "productItem", cascade = CascadeType.ALL)
	private List<Comment> comentarioLista;	
	
	/**
	 * Representa o pre�o do produto.
	 */
	@Column(name="PRECO")
	private BigDecimal preco;
	
	/**
	 * Quantidade em estoque.
	 */
	@Column(name="QUANTIDADE_ESTOQUE")
	private int quantidadeStock;
	
	/**
	 * Produto est� ativo?
	 */
	@Column(name="ATIVO")
	private boolean ativo;
	
	/**
	 * Indicador da �ltima atualiza��o do registro.
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ULTIMA_ATUALIZACAO")
	private Date atualizacao;
	
	/**
	 * Usu�rio da �ltima atualiza��o de registro.
	 */
	@Column(name="USUARIO_ULTIMA_ATUALIZACAO")
	private String usuarioUltimaAtualizacao;
	
	/**
	 * Usu�rio de cria��o do registro.
	 */
	@Column(name="USUARIO_CRIACAO")
	private String usuarioCriacao;
	
	/**
	 * Data da cria��o do registro.
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DATA_CRIACAO")
	private Date dataCriacao;

	/**
	 * M�todo get do atributo.
	 * @return idNumber - Long - chave prim�ria. 
	 */
	public Long getIdNumber() {
		return this.idNumber;
	}

	/**
	 * M�todo set do atributo.
	 * @param idNumber - Long - chave prim�ria. 
	 */
	public void setIdNumber(final Long idNumber) {
		this.idNumber = idNumber;
	}

	/**
	 * M�todo get do atributo atualizacao.
	 * @return atualizacao - Date - data da atualiza��o do registro.
	 */
	public Date getAtualizacao() {
		return this.atualizacao;
	}

	/**
	 * M�todo set do atributo atualizacao.
	 * @param atualizacao - Date - data da atualiza��o do registro.
	 */
	public void setAtualizacao(final Date atualizacao) {
		this.atualizacao = atualizacao;
	}

	/**
	 * M�todo get do atributo usuarioUltimaAtualizacao.
	 * @return usuarioUltimaAtualizacao - String - usu�rio que realizou a �ltima atualiza��o de registro.
	 */
	public String getUsuarioUltimaAtualizacao() {
		return this.usuarioUltimaAtualizacao;
	}

	/**
	 * M�todo set do atributo usuarioUltimaAtualizacao.
	 * @param usuarioUltimaAtualizacao - String - usu�rio que realizou a �ltima atualiza��o de registro.
	 */
	public void setUsuarioUltimaAtualizacao(final String usuarioUltimaAtualizacao) {
		this.usuarioUltimaAtualizacao = usuarioUltimaAtualizacao;
	}

	/**
	 * M�todo get do atributo usuarioCriacao.
	 * @return usuarioCriacao - String - usu�rio da cria��o do registro.
	 */
	public String getUsuarioCriacao() {
		return this.usuarioCriacao;
	}

	/**
	 * M�todo set do atributo usuarioCriacao.
	 * @param usuarioCriacao - String -  usu�rio da cria��o do registro.
	 */
	public void setUsuarioCriacao(final String usuarioCriacao) {
		this.usuarioCriacao = usuarioCriacao;
	}

	/**
	 * M�todo get do atributo dataCriacao.
	 * @return dataCriacao - Date - data da cria��o do registro.
	 */
	public Date getDataCriacao() {
		return this.dataCriacao;
	}

	/**
	 * M�todo set do atributo dataCriacao.
	 * @param dataCriacao - Date - data da cria��o do registro.
	 */
	public void setDataCriacao(final Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	/**
	 * M�todo get do atributo nome.
	 * @return nome - String - representa o nome do produto.
	 */
	public String getNome() {
		return this.nome;
	}

	/**
	 * M�todo set do atributo nome.
	 * @param nome - String - representa o nome do produto.
	 */
	public void setNome(final String nome) {
		this.nome = nome;
	}

	/**
	 * M�todo get do atributo descricao.
	 * @return descricao - String - representa a descricao do produto.
	 */
	public String getDescricao() {
		return this.descricao;
	}

	/**
	 * M�todo set do atributo descricao.
	 * @param descricao - String - representa a descricao do produto.
	 */
	public void setDescricao(final String descricao) {
		this.descricao = descricao;
	}

	/**
	 * M�todo get do atributo categoria.
	 * @return categoria - ProductCategory - representa a categoria do produto.
	 */
	public ProductCategory getCategoria() {
		return this.categoria;
	}

	/**
	 * M�todo set do atributo categoria.
	 * @param categoria - ProductCategory - representa a categoria do produto.
	 */
	public void setCategoria(final ProductCategory categoria) {
		this.categoria = categoria;
	}

	/**
	 * M�todo get do atributo preco.
	 * @return preco - BigDecimal - representa o pre�o do produto.
	 */
	public BigDecimal getPreco() {
		return this.preco;
	}

	/**
	 * M�todo set do atributo preco.
	 * @param preco - BigDecimal - representa o pre�o do produto.
	 */
	public void setPreco(final BigDecimal preco) {
		this.preco = preco;
	}

	/**
	 * M�todo get do atributo quantidadeStock.
	 * @return quantidadeStock - int - representa a quantidade de estoque do produto.
	 */
	public int getQuantidadeStock() {
		return this.quantidadeStock;
	}

	/**
	 * M�todo set do atributo quantidadeStock.
	 * @param quantidadeStock - int - representa a quantidade de estoque do produto.
	 */
	public void setQuantidadeStock(final int quantidadeStock) {
		this.quantidadeStock = quantidadeStock;
	}

	/**
	 * M�todo get do atributo ativo.
	 * @return ativo - boolean - representa se o produto est� ativo no sistema.
	 */
	public boolean isAtivo() {
		return this.ativo;
	}

	/**
	 * M�todo set do atributo ativo.
	 * @param ativo - boolean - representa se o produto est� ativo no sistema.
	 */
	public void setAtivo(final boolean ativo) {
		this.ativo = ativo;
	}

	/**
	 * M�todo get do atributo idCategoria.
	 * @return idCategoria - Long - Representa a chave estrangeira.
	 */
	public Long getIdCategoria() {
		return this.idCategoria;
	}

	/**
	 * M�todo set do atributo idCategoria.
	 * @param idCategoria - Long - Representa a chave estrangeira.
	 */
	public void setIdCategoria(final Long idCategoria) {
		this.idCategoria = idCategoria;
	}

	/**
	 * M�todo get do atributo comentarioLista.
	 * @return comentarioLista - List<Comment> - lista de coment�rios de um produto.
	 */
	public List<Comment> getComentarioLista() {
		return this.comentarioLista;
	}

	/**
	 * M�todo set do atributo comentarioLista.
	 * @param comentarioLista - List<Comment> - lista de coment�rios de um produto.
	 */
	public void setComentarioLista(final List<Comment> comentarioLista) {
		this.comentarioLista = comentarioLista;
	}
	
}