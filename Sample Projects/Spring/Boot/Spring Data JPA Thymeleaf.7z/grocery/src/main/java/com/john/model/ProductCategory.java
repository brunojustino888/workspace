package com.john.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="PRODUCT_CATEGORY")
public class ProductCategory implements Serializable {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Id
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private Long idNumber;
	
	/**
	 * Usu�rio da �ltima atualiza��o de registro
	 */
	@Column(name="DESCRICAO")
	private String description;

	/**
	 * Indicador da �ltima atualiza��o do registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ULTIMA_ATUALIZACAO")
	private Date atualizacao;
	
	/**
	 * Usu�rio da �ltima atualiza��o de registro
	 */
	@Column(name="USUARIO_ULTIMA_ATUALIZACAO")
	private String usuarioUltimaAtualizacao;
	
	/**
	 * Usu�rio de cria��o do registro
	 */
	@Column(name="USUARIO_CRIACAO")
	private String usuarioCriacao;
	
	/**
	 * Data da cria��o do registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DATA_CRIACAO")
	private Date dataCriacao;

	/**
	 * M�todo get do atributo
	 * @return idNumber - Long - chave prim�ria. 
	 */
	public Long getIdNumber() {
		return this.idNumber;
	}

	/**
	 * M�todo set do atributo
	 * @param idNumber - Long - chave prim�ria. 
	 */
	public void setIdNumber(Long idNumber) {
		this.idNumber = idNumber;
	}

	/**
	 * M�todo get do atributo atualizacao.
	 * @return atualizacao - Date - data da atualiza��o do registro.
	 */
	public Date getAtualizacao() {
		return this.atualizacao;
	}

	/**
	 * M�todo set do atributo atualizacao.
	 * @param atualizacao - Date - data da atualiza��o do registro.
	 */
	public void setAtualizacao(final Date atualizacao) {
		this.atualizacao = atualizacao;
	}

	/**
	 * M�todo get do atributo usuarioUltimaAtualizacao.
	 * @return usuarioUltimaAtualizacao - String - usu�rio que realizou a �ltima atualiza��o de registro.
	 */
	public String getUsuarioUltimaAtualizacao() {
		return this.usuarioUltimaAtualizacao;
	}

	/**
	 * M�todo set do atributo usuarioUltimaAtualizacao.
	 * @param usuarioUltimaAtualizacao - String - usu�rio que realizou a �ltima atualiza��o de registro.
	 */
	public void setUsuarioUltimaAtualizacao(final String usuarioUltimaAtualizacao) {
		this.usuarioUltimaAtualizacao = usuarioUltimaAtualizacao;
	}

	/**
	 * M�todo get do atributo usuarioCriacao.
	 * @return usuarioCriacao - String - usu�rio da cria��o do registro.
	 */
	public String getUsuarioCriacao() {
		return this.usuarioCriacao;
	}

	/**
	 * M�todo set do atributo usuarioCriacao.
	 * @param usuarioCriacao - String -  usu�rio da cria��o do registro.
	 */
	public void setUsuarioCriacao(final String usuarioCriacao) {
		this.usuarioCriacao = usuarioCriacao;
	}

	/**
	 * M�todo get do atributo dataCriacao.
	 * @return dataCriacao - Date - data da cria��o do registro.
	 */
	public Date getDataCriacao() {
		return this.dataCriacao;
	}

	/**
	 * M�todo set do atributo dataCriacao.
	 * @param dataCriacao - Date - data da cria��o do registro.
	 */
	public void setDataCriacao(final Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

}