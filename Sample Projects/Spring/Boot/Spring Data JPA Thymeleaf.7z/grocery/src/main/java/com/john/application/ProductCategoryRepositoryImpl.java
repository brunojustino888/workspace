package com.john.application;
import java.util.List;
import java.util.Optional;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import com.john.model.ProductCategory;
import com.john.service.ProductCategoryRepository;

/**
 * Service respons�vel pelas categorias dos produtos cadastrados.
 * @author brunoj - Bruno Justino
 */
public class ProductCategoryRepositoryImpl implements ProductCategoryRepository {
	
	/**
	 * Entity Manager
	 */
	@PersistenceContext
	private EntityManager entityManager;
	
	/**
	 * {@inheritDoc}
	 */ 
	@Override
	public List<ProductCategory> findAll() {
		try {
			entityManager.getTransaction().begin();
			List<ProductCategory> result = entityManager.createQuery("from ProductCategory", ProductCategory.class ).getResultList();
			entityManager.getTransaction().commit();
			entityManager.close();
			return result;
		}catch(Throwable error) {
			error.printStackTrace();
		}
		return null;
	}
	
	@Override
	public <S extends ProductCategory> S save(S entity) {
		return null;
	}

	@Override
	public <S extends ProductCategory> Iterable<S> saveAll(Iterable<S> entities) {
		return null;
	}

	@Override
	public boolean existsById(Long id) {
		return false;
	}

	@Override
	public Iterable<ProductCategory> findAllById(Iterable<Long> ids) {
		return null;
	}

	@Override
	public long count() {
		return 0;
	}

	@Override
	public void deleteById(Long id) {
	}

	@Override
	public void delete(ProductCategory entity) {
	}

	@Override
	public void deleteAll(Iterable<? extends ProductCategory> entities) {
	}

	@Override
	public void deleteAll() {
	}

	@Override
	public Optional<ProductCategory> findById(Long id) {
		return null;
	}
	
}