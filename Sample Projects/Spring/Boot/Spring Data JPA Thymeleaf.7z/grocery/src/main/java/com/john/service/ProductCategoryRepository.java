package com.john.service;
import java.util.List;
import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;
import com.john.model.ProductCategory;

/**
 * Interface respons�vel pelos servi�os de categorias dos produtos cadastrados.
 * @author brunoj - Bruno Justino
 */
@Transactional
public interface ProductCategoryRepository extends CrudRepository<ProductCategory, Long>{

	/**
	 * M�todo respons�vel por buscar todas as categorias de produtos.
	 * @return List<ProductCategory> - lista de categorias de produtos.
	 */
	List<ProductCategory> findAll();
	
	/**
	 * M�todo respons�vel por buscar uma determinada categoria atrav�s da sua pk.
	 * @param id - Long - pk do registro 
	 * @return ProductCategory - categoria encontrada
	 */
	Optional<ProductCategory> findById(Long id);
	
}