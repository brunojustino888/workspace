package com.john.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="ORDEMN")
public class Order implements Serializable {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Id - chave prim�ria.
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private Long idNumber;

	/**
	 * Representa a chave estrangeira.
	 */
	@Column(name="CLIENTE_COD")
	private Long clienteIdNumber;
	
	/**
	 * Representa o valor total do pedido.
	 */
	@Column(name="VALOR")
	private BigDecimal valor;
	
	/**
	 * Representa o status de um determinado pedido.
	 */
	@Column(name="STATUS")
	private String status;
	
	/**
	 * Representa observa��o de um determinado pedido.
	 */
	@Column(name="OBSERVACAO")
	private String observ;
	
	/**
	 * Representa o cliente que realizou o pedido
	 */
	@ManyToOne
	private Customer customer;
	
	/**
	 * Representa as linhas do pedido.
	 */
	@OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
	private List<OrderLine> linhasDoPedido;
	
	/**
	 * Indicador da �ltima atualiza��o do registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ULTIMA_ATUALIZACAO")
	private Date atualizacao;
	
	/**
	 * Usu�rio da �ltima atualiza��o de registro
	 */
	@Column(name="USUARIO_ULTIMA_ATUALIZACAO")
	private String usuarioUltimaAtualizacao;
	
	/**
	 * Usu�rio de cria��o do registro
	 */
	@Column(name="USUARIO_CRIACAO")
	private String usuarioCriacao;
	
	/**
	 * Data da cria��o do registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DATA_CRIACAO")
	private Date dataCriacao;

	/**
	 * M�todo get do atributo.
	 * @return idNumber - Long - chave prim�ria. 
	 */
	public Long getIdNumber() {
		return this.idNumber;
	}

	/**
	 * M�todo set do atributo.
	 * @param idNumber - Long - chave prim�ria. 
	 */
	public void setIdNumber(final Long idNumber) {
		this.idNumber = idNumber;
	}
	
	/**
	 * M�todo get do atributo clienteIdNumber.
	 * @return clienteIdNumber - Long - chave estrangeira para a tabela de clientes.
	 */
	public Long getClienteIdNumber() {
		return this.clienteIdNumber;
	}

	/**
	 * M�todo set do atributo clienteIdNumber.
	 * @param clienteIdNumber - Long - chave estrangeira para a tabela de clientes.
	 */
	public void setClienteIdNumber(final Long clienteIdNumber) {
		this.clienteIdNumber = clienteIdNumber;
	}

	/**
	 * M�todo get do atributo atualizacao.
	 * @return atualizacao - Date - data da atualiza��o do registro.
	 */
	public Date getAtualizacao() {
		return this.atualizacao;
	}

	/**
	 * M�todo set do atributo atualizacao.
	 * @param atualizacao - Date - data da atualiza��o do registro.
	 */
	public void setAtualizacao(final Date atualizacao) {
		this.atualizacao = atualizacao;
	}

	/**
	 * M�todo get do atributo usuarioUltimaAtualizacao.
	 * @return usuarioUltimaAtualizacao - String - usu�rio que realizou a �ltima atualiza��o de registro.
	 */
	public String getUsuarioUltimaAtualizacao() {
		return this.usuarioUltimaAtualizacao;
	}

	/**
	 * M�todo set do atributo usuarioUltimaAtualizacao.
	 * @param usuarioUltimaAtualizacao - String - usu�rio que realizou a �ltima atualiza��o de registro.
	 */
	public void setUsuarioUltimaAtualizacao(final String usuarioUltimaAtualizacao) {
		this.usuarioUltimaAtualizacao = usuarioUltimaAtualizacao;
	}

	/**
	 * M�todo get do atributo usuarioCriacao.
	 * @return usuarioCriacao - String - usu�rio da cria��o do registro.
	 */
	public String getUsuarioCriacao() {
		return this.usuarioCriacao;
	}

	/**
	 * M�todo set do atributo usuarioCriacao.
	 * @param usuarioCriacao - String -  usu�rio da cria��o do registro.
	 */
	public void setUsuarioCriacao(final String usuarioCriacao) {
		this.usuarioCriacao = usuarioCriacao;
	}

	/**
	 * M�todo get do atributo dataCriacao.
	 * @return dataCriacao - Date - data da cria��o do registro.
	 */
	public Date getDataCriacao() {
		return this.dataCriacao;
	}

	/**
	 * M�todo set do atributo dataCriacao.
	 * @param dataCriacao - Date - data da cria��o do registro.
	 */
	public void setDataCriacao(final Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	/**
	 * M�todo get do atributo customer.
	 * @return customer - Customer - representa o cliente.
	 */
	public Customer getCustomer() {
		return this.customer;
	}

	/**
	 * M�todo set do atributo customer.
	 * @param customer - Customer - representa o cliente.
	 */
	public void setCustomer(final Customer customer) {
		this.customer = customer;
	}

	/**
	 * M�todo get do atributo linhasDoPedido.
	 * @return linhasDoPedido - List<OrderLine> - pedidos.
	 */
	public List<OrderLine> getLinhasDoPedido() {
		return this.linhasDoPedido;
	}

	/**
	 * M�todo set do atributo linhasDoPedido.
	 * @param linhasDoPedido - List<OrderLine> - pedidos.
	 */
	public void setLinhasDoPedido(final List<OrderLine> linhasDoPedido) {
		this.linhasDoPedido = linhasDoPedido;
	}

	/**
	 * M�todo get do atributo valor.
	 * @return valor - BigDecimal - valor total do pedido.
	 */
	public BigDecimal getValor() {
		return this.valor;
	}

	/**
	 * M�todo set do atributo valor.
	 * @param valor - BigDecimal - valor total do pedido.
	 */
	public void setValor(final BigDecimal valor) {
		this.valor = valor;
	}

	/**
	 * M�todo get do atributo status.
	 * @return status - String - status do pedido.
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * M�todo set do atributo status.
	 * @param status - String - status do pedido.
	 */
	public void setStatus(final String status) {
		this.status = status;
	}

	/**
	 * M�todo get do atributo observ.
	 * @return observ - String - observa��o do pedido.
	 */
	public String getObserv() {
		return this.observ;
	}

	/**
	 * M�todo set do atributo observ.
	 * @param observ - String - observa��o do pedido.
	 */
	public void setObserv(final String observ) {
		this.observ = observ;
	}
	
}