package com.john.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Customer implements Serializable {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Id - chave prim�ria.
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private Long idNumber;
	
	/**
	 * Representa o nome de um determinado cliente
	 */
	@Column(name="NOME")
	private String nome;
	
	/**
	 * Representa os endere�os do cliente.
	 */
	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
	private List<Adress> enderecoLista;	
	
	/**
	 * Representa os pedidos do cliente.
	 */
	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
	private List<Order> pedidosLista;	
	
	/**
	 * Representa o documento principal cadastrado.
	 */
	@Column(name="DOCUMENTO")
	private String documento;
	
	/**
	 * Representa o telefone do cliente.
	 */
	@Column(name="TELEFONE")
	private String telefone;
	
	/**
	 * Representa o e-mail do cliente.
	 */
	@Column(name="EMAIL")
	private String email;
	
	/**
	 * Representa o ramo de atividade do cliente
	 */
	@Column(name="RAMO_ATIVIDADE")
	private String ramoAtividade;

	/**
	 * Indicador da �ltima atualiza��o do registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ULTIMA_ATUALIZACAO")
	private Date atualizacao;
	
	/**
	 * Usu�rio da �ltima atualiza��o de registro
	 */
	@Column(name="USUARIO_ULTIMA_ATUALIZACAO")
	private String usuarioUltimaAtualizacao;
	
	/**
	 * Usu�rio de cria��o do registro
	 */
	@Column(name="USUARIO_CRIACAO")
	private String usuarioCriacao;
	
	/**
	 * Data da cria��o do registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DATA_CRIACAO")
	private Date dataCriacao;

	/**
	 * M�todo get do atributo
	 * @return idNumber - Long - chave prim�ria. 
	 */
	public Long getIdNumber() {
		return this.idNumber;
	}

	/**
	 * M�todo set do atributo
	 * @param idNumber - Long - chave prim�ria. 
	 */
	public void setIdNumber(final Long idNumber) {
		this.idNumber = idNumber;
	}
	
	/**
	 * M�todo get do atributo nome.
	 * @return nome - String - representa o nome do cliente.
	 */
	public String getNome() {
		return this.nome;
	}

	/**
	 * M�todo set do atributo nome.
	 * @param nome - String - representa o nome do cliente.
	 */
	public void setNome(final String nome) {
		this.nome = nome;
	}

	/**
	 * Representa a lista de endere�os do cliente.
	 * @return enderecoLista - List<Adress> - lista de endere�os.
	 */
	public List<Adress> getEnderecoLista() {
		return this.enderecoLista;
	}

	/**
	 * Representa a lista de endere�os do cliente.
	 * @param enderecoLista - List<Adress> - lista de endere�os.
	 */
	public void setEnderecoLista(final List<Adress> enderecoLista) {
		this.enderecoLista = enderecoLista;
	}

	/**
	 * Representa o documento do cliente.
	 * @return documento - String - documento do cliente.
	 */
	public String getDocumento() {
		return this.documento;
	}

	/**
	 * Representa o documento do cliente.
	 * @param documento - String - documento do cliente.
	 */
	public void setDocumento(final String documento) {
		this.documento = documento;
	}

	/**
	 * Representa o telefone do cliente.
	 * @return telefone - String - Telefone do cliente.
	 */
	public String getTelefone() {
		return this.telefone;
	}

	/**
	 * Representa o telefone do cliente.
	 * @param telefone - String - Telefone do cliente.
	 */
	public void setTelefone(final String telefone) {
		this.telefone = telefone;
	}

	/**
	 * Representa o email do cliente.
	 * @return email - String - email do cliente.
	 */
	public String getEmail() {
		return this.email;
	}

	/**
	 * Representa o email do cliente.
	 * @param email - String - email do cliente.
	 */
	public void setEmail(final String email) {
		this.email = email;
	}

	/**
	 * Representa o ramo de atividade do cliente.
	 * @return ramoAtividade - String - ramo de atividade do cliente.
	 */
	public String getRamoAtividade() {
		return this.ramoAtividade;
	}

	/**
	 * Representa o ramo de atividade do cliente.
	 * @param ramoAtividade - String - ramo de atividade do cliente.
	 */
	public void setRamoAtividade(final String ramoAtividade) {
		this.ramoAtividade = ramoAtividade;
	}

	/**
	 * M�todo get do atributo atualizacao.
	 * @return atualizacao - Date - data da atualiza��o do registro.
	 */
	public Date getAtualizacao() {
		return this.atualizacao;
	}

	/**
	 * M�todo set do atributo atualizacao.
	 * @param atualizacao - Date - data da atualiza��o do registro.
	 */
	public void setAtualizacao(final Date atualizacao) {
		this.atualizacao = atualizacao;
	}

	/**
	 * M�todo get do atributo usuarioUltimaAtualizacao.
	 * @return usuarioUltimaAtualizacao - String - usu�rio que realizou a �ltima atualiza��o de registro.
	 */
	public String getUsuarioUltimaAtualizacao() {
		return this.usuarioUltimaAtualizacao;
	}

	/**
	 * M�todo set do atributo usuarioUltimaAtualizacao.
	 * @param usuarioUltimaAtualizacao - String - usu�rio que realizou a �ltima atualiza��o de registro.
	 */
	public void setUsuarioUltimaAtualizacao(final String usuarioUltimaAtualizacao) {
		this.usuarioUltimaAtualizacao = usuarioUltimaAtualizacao;
	}

	/**
	 * M�todo get do atributo usuarioCriacao.
	 * @return usuarioCriacao - String - usu�rio da cria��o do registro.
	 */
	public String getUsuarioCriacao() {
		return this.usuarioCriacao;
	}

	/**
	 * M�todo set do atributo usuarioCriacao.
	 * @param usuarioCriacao - String -  usu�rio da cria��o do registro.
	 */
	public void setUsuarioCriacao(final String usuarioCriacao) {
		this.usuarioCriacao = usuarioCriacao;
	}

	/**
	 * M�todo get do atributo dataCriacao.
	 * @return dataCriacao - Date - data da cria��o do registro.
	 */
	public Date getDataCriacao() {
		return this.dataCriacao;
	}

	/**
	 * M�todo set do atributo dataCriacao.
	 * @param dataCriacao - Date - data da cria��o do registro.
	 */
	public void setDataCriacao(final Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

}