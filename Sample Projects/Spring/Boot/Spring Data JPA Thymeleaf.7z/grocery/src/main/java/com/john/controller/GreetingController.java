package com.john.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.john.service.ProductCategoryRepository;
 
@Controller
public class GreetingController {

	private String teste = "alright";
	
	@Autowired
	private ProductCategoryRepository service;
	
	@GetMapping("/greeting")
    public String greeting(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {
        model.addAttribute("name", name);
        System.out.println(service.findAll().size());
        return "greeting";
    }
	
	@GetMapping("/index")
    public String index() {
        return "index";
    }

	public String getTeste() {
		return teste;
	}

	public void setTeste(String teste) {
		this.teste = teste;
	}
	
	
		
}