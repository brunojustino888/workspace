package validationform;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class PessoaForm {

    @NotNull
    @Size(min=2, max=30)
    private String nome;

    @NotNull
    @Min(18)
    private Integer idade;

	public String getNome() {
		return this.nome;
	}

	public void setNome(final String nome) {
		this.nome = nome;
	}

	public Integer getIdade() {
		return this.idade;
	}

	public void setIdade(final Integer idade) {
		this.idade = idade;
	}
	
    public String toString() {
        return "Pessoa(Nome: " + this.nome + ", Idade: " + this.idade + ")";
    }
    
}