/**
 * 
 */
package br.com.bradesco.config;

import br.com.bradesco.exception.AlterarSenhaException;

/**
 * @author edwin.costa
 * 
 */
public interface IAlterarSenhaService {
	public void trocarSenha(String usuario, String senhaAtual,
			String novaSenha, String confirmNovaSenha)
			throws AlterarSenhaException;
}