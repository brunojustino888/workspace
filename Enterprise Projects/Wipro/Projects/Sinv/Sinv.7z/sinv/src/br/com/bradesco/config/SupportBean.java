/*
* =========================================================================
* 
* Client:       Bradesco (BR)
* Project:      Arquitectura Bradesco Canal Web
* Development:  GFT Iberia (http://www.gft.com)
* -------------------------------------------------------------------------
* Revision - Last:
* $Source: /Repositorio/TIMelhorias_AQ/Projetos/PilotoIntranet/JavaSource/br/com/bradesco/web/piloto/example/view/bean/SupportBean.java,v $
* $Id: SupportBean.java,v 1.5 2009/05/18 16:50:45 corporate\alexandre.manduca Exp $
* $State: Exp $
* -------------------------------------------------------------------------
* Revision - History:
* $Log: SupportBean.java,v $
* Revision 1.5  2009/05/18 16:50:45  corporate\alexandre.manduca
* Criacao de um provider Mock para LDAP, de modo que os testes da aplicacao nao necessitem nem do AD e nem do LDAP Embedded, que nao e homologado no bradesco...
*
* Tambem fiz um correcao no SupportBean, referente ao redirecionamento do componente UIModalMessages
*
* Revision 1.4  2009/05/13 21:16:37  cpm.com.br\heslei.silva
* organizacao da version 2 para o head
*
* Revision 1.2  2009/04/30 19:49:12  corporate\edwin.costa
* Alterado o diret�rio de fontes para JavaSource
*
* Revision 1.4  2009/04/07 16:54:49  corporate\milena.santos
* Ajuste devido a mudan�a de nome de arquivo
*
* Revision 1.3  2009/03/26 18:06:50  corporate\alexandre.manduca
* Mudancas no layout do componente UIModalMessages para o PilotoInternet.
* Tambem contem mudancas no PilotoIntranet, para usar corretamente o botao.
*
* Revision 1.2  2009/03/23 13:23:26  corporate\alexandre.manduca
* Adiciona componentes UIAlcada e UIModalMessages ao projeto PilotoIntranet.
*
* Revision 1.1  2009/03/16 16:19:14  corporate\marcio.alves
* Adicionando o PilotoIntranet ao CVS
*
*
* =========================================================================
*/

package br.com.bradesco.config;

import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import br.com.bradesco.web.aq.application.error.BradescoViewException;
import br.com.bradesco.web.aq.application.error.BradescoViewException.BradescoViewExceptionActionType;
import br.com.bradesco.web.aq.application.pdc.adapter.exception.PdcAdapterFunctionalException;
import br.com.bradesco.web.aq.application.util.faces.BradescoFacesUtils;
import br.com.bradesco.web.aq.view.components.app.UIAgencia.AgenciaDataType;
import br.com.bradesco.web.aq.view.components.app.UIAgenciaConta.AgenciaContaDataType;
import br.com.bradesco.web.aq.view.components.app.UIAlcada.UIAlcada;
import br.com.bradesco.web.aq.view.components.app.UIBoletoCobranca.BoletoCobrancaDataType;
import br.com.bradesco.web.aq.view.components.app.UIBoletoPagamento.BoletoPagamentoDataType;
import br.com.bradesco.web.aq.view.components.app.UIConta.ContaDataType;
import br.com.bradesco.web.aq.view.components.app.UISecretPhrase.SecretPhraseDataType;
import br.com.bradesco.web.aq.view.util.FacesUtils;

/**
 * <p><b>Title:</b>        Arquitectura Bradesco Canal Web.</p>
 * <p><b>Description:</b></p>
 * <p>Insertar aqu� la descripci�n del Tipo.</p>
 * 
 * @author       GFT Iberia Solutions / Emagine <BR/>
 * copyright Copyright (c) 2006 <BR/>
 * created   Jul 7, 2006 <BR/>
 * @version      1.0
 */

public class SupportBean {

    //------------------------------------/
    //HTML COMPONENTS
    //------------------------------------/
    private String validatorLenght;
    private String car;  
    
    public SelectItem listaCoches1 = new SelectItem("BMW", "Audi", "Porsche");

    
    //------------------------------------/
    //ARCHITECTURE COMPONENTS
    //------------------------------------/   
    private String appletColor;
    private String appletBgColor;
    
    //------------------------------------/
    //APPLICATION COMPONENTS
    //------------------------------------/    
    private AgenciaContaDataType agenciaConta;
    private AgenciaDataType agencia;
    private ContaDataType conta;
    private String dc;
    
    private BoletoCobrancaDataType boletoCobranca;
    private BoletoPagamentoDataType boletoPagamento;
    
    private SecretPhraseDataType phrase;
    
    // Alcada
    private String alcadaNomeAutorizador;
    private String alcadaSenhaAutorizador;
    private UIAlcada alcadaBinding;

    private String textoArea="Texto desde el bean de soporte,...prueba....!!!!";
    
    public SupportBean(){
        agenciaConta = new AgenciaContaDataType();        
        agenciaConta.setAgencia("2516");
        agenciaConta.setConta("1418");
        agenciaConta.setDc("4");
        
        agencia = new AgenciaDataType();
        agencia.setAgencia("1418");
        agencia.setDc("4");
        
        conta = new ContaDataType();
        conta.setConta("1418");
        conta.setDc("4");
        
        phrase = new SecretPhraseDataType();
        
        boletoCobranca = new BoletoCobrancaDataType();
        boletoCobranca.setInput1("23792");
        boletoCobranca.setInput2("77409");
        boletoCobranca.setInput3("69900");
        boletoCobranca.setInput4("061453");
        boletoCobranca.setInput5("26000");
        boletoCobranca.setInput6("009501");
        boletoCobranca.setInput7("8");
        boletoCobranca.setInput8("31880000013167");
        
        
        boletoPagamento = new BoletoPagamentoDataType();
        boletoPagamento.setInput1("82620000000");
        boletoPagamento.setInput2("6");
        boletoPagamento.setInput3("74620097132");
        boletoPagamento.setInput4("1");
        boletoPagamento.setInput5("02037234391");
        boletoPagamento.setInput6("1");
        boletoPagamento.setInput7("41614306082");
        boletoPagamento.setInput8("8");
    }    
    
    
    public String action(){
        return "";
    }
    
    public String actionNext(){
        return "next";
    }
    
    // Acoes de Alcada
    // Esse metodo representaria um action listener que executa uma acao restrita a um determinado
    // perfil. Esse exemplo forca um erro de autorizacao. Na pratica, talvez um excecao fosse lancada
    // e seria tratada para mostrar o componente corretamente. Veja a documentacao do componente UIAlcada
    // para mais informacoes.
    public void alcadaEnviarActionListener(ActionEvent e) {
    	if (this.alcadaNomeAutorizador != null &&
    		this.alcadaSenhaAutorizador != null) {

    		if ("123".equals(this.alcadaSenhaAutorizador)) {
    			FacesUtils.addInfoMessage("Opera��o Efetuada com Sucesso");
    			
    			this.alcadaBinding.setSenhaIncorreta(false);
    			this.alcadaBinding.setRendered(false);
    			this.alcadaNomeAutorizador = null;
    			this.alcadaSenhaAutorizador = null;
    		} else {
    			FacesUtils.addErrorMessage("Senha Incorreta");
    			this.alcadaBinding.setSenhaIncorreta(true);	
    		}
    		
    	} else {    		
    		FacesUtils.addErrorMessage("Voc� n�o tem permiss�o para executar essa a��o.");
    		FacesUtils.addErrorMessage("Para continuar informa dados do autorizador.");
    		this.alcadaNomeAutorizador = "Andre Silva";
    		this.alcadaBinding.setRendered(true);
    	}
    }
    public String alcadaEnviarAction() {
    	// Aqui, poderiamos calcular de acordo com o parametros passados pelo usuario
    	// para onde ele seria redirecionado. No nosso caso, vamos apenas exibir a mesma pagina.
    	return null;
    }
    public void alcadaCancelarActionListener(ActionEvent e) {
    	// Aqui, poderia executar alguam acao referente ao cancelamento da acao executada pelo usuario.
    	// Nesse caso, vamos apenas exibir uma mensagem de cancelamento.
    	FacesUtils.addInfoMessage("A��o cancelado pelo usu�rio");
    	
    	this.alcadaBinding.setRendered(false);
    	this.alcadaBinding.setSenhaIncorreta(false);
    	this.alcadaNomeAutorizador = null;
    	this.alcadaSenhaAutorizador = null;
    	
    }
    public String alcadaCancelarAction() {
    	// Aqui, poderiamos calcular para onde o usuario seria redirecionado caso ele clicasse
    	// no botao de cancelar. Nesse caso, vamos apenas mostrar a mesma pagina.    	
    	return null;
    } 
    
    // UIModalMessages
	public String modalMessagesSucessoAction() {
		BradescoFacesUtils.addInfoModalMessage("Exemplo Mensagem Sucesso. Botao ira executar Action.", "#{supportBean.modalMessagesAction}", BradescoViewExceptionActionType.ACTION, false);
		return null;
	}
	public String modalMessagesViewException() {
		throw new BradescoViewException("Exemplo de BradescoViewException. Botao ira executar Action Listener", "bradescoViewException.message", "#{supportBean.modalMessagesActionListener}", BradescoViewExceptionActionType.ACTION_LISTENER);
	}
	public String modalMessagesException() {
		// essa exception foi configurada com um valor padrao no error-catalog.xml
		throw new PdcAdapterFunctionalException("session_expired_header", "Exemplo Erro PDC");
	}
	public String modalMessagesSucessoPath() {
		BradescoFacesUtils.addInfoModalMessage("Exemplo Mensagem Sucesso. Botao ira redirecionar usuario para outra P�gina.", "/presHome.jsf", BradescoViewExceptionActionType.PATH, false);
		return null;
	}
	public String modalMessagesAction() {
		FacesUtils.addInfoMessage("Mensagem adicionada pela action especificada no botao do componente UIModalMessages.");
		return null;
	}
	public void modalMessagesActionListener(ActionEvent e) {
		FacesUtils.addInfoMessage("Mensagem adicionada pelo action listener especificada no botao do componente UIModalMessages.");
	}
	public String modalMessagesDefaultAction() {
		FacesUtils.addInfoMessage("Mensagem adicionada pela action default especificada no arquivo error-catalog.xml.");
		return null;
	}
    
    //------------------------------------/
    //HTML COMPONENTS
    //------------------------------------/
    public String getValidatorLenght() {
        return validatorLenght;
    }
    public void setValidatorLenght(String validatorLenght) {
        this.validatorLenght = validatorLenght;
    }    
    public String getCar() {
        return car;
    }
    public void setCar(String car) {
        this.car = car;
    }
 
    public SelectItem getListaCoches1() {
        return listaCoches1;
    }
    public void setListaCoches1(SelectItem listaCoches1) {
        this.listaCoches1 = listaCoches1;
    }

    //------------------------------------/
    //ARCHITECTURE COMPONENTS
    //------------------------------------/  
    /**
     * @return Retorna el valor del campo 'appletBgColor'.
     */
    public String getAppletBgColor() {
        return appletBgColor;
    }

    /**
     * @param appletBgColor - El valor del campo 'appletBgColor' a determinar.
     */
    public void setAppletBgColor(String appletBgColor) {
        this.appletBgColor = appletBgColor;
    }

    /**
     * @return Retorna el valor del campo 'appletColor'.
     */
    public String getAppletColor() {
        return appletColor;
    }

    /**
     * @param appletColor - El valor del campo 'appletColor' a determinar.
     */
    public void setAppletColor(String appletColor) {
        this.appletColor = appletColor;
    }
   
    //------------------------------------/
    //APPLICATION COMPONENTS
    //------------------------------------/
    public AgenciaContaDataType getAgenciaConta() {
        return agenciaConta;
    }
    public void setAgenciaConta(AgenciaContaDataType newValue) {
        this.agenciaConta = newValue;
    }
    public String getDc() {
        return dc;
    }
    public void setDc(String dc) {
        this.dc = dc;
    }
    public AgenciaDataType getAgencia() {
        return agencia;
    }
    public void setAgencia(AgenciaDataType agencia) {
        this.agencia = agencia;
    }
    public ContaDataType getConta() {
        return conta;
    }
    public void setConta(ContaDataType conta) {
        this.conta = conta;
    }
    public String getTextoArea() {
        return textoArea;
    }
    public void setTextoArea(String textoArea) {
        this.textoArea = textoArea;
    }
    public SecretPhraseDataType getPhrase() {
        return phrase;
    }
    public void setPhrase(SecretPhraseDataType phrase) {
        this.phrase = phrase;
    }

    
    public BoletoCobrancaDataType getBoletoCobranca() {
        return boletoCobranca;
    }
    public void setBoletoCobranca(BoletoCobrancaDataType boletoCobranca) {
        this.boletoCobranca = boletoCobranca;
    }
    public BoletoPagamentoDataType getBoletoPagamento() {
        return boletoPagamento;
    }
    public void setBoletoPagamento(BoletoPagamentoDataType boletoPagamento) {
        this.boletoPagamento = boletoPagamento;
    }

    // Alcada
	public String getAlcadaNomeAutorizador() {
		return alcadaNomeAutorizador;
	}
	public void setAlcadaNomeAutorizador(String alcadaNomeAutorizador) {
		this.alcadaNomeAutorizador = alcadaNomeAutorizador;
	}
	public String getAlcadaSenhaAutorizador() {
		return alcadaSenhaAutorizador;
	}
	public void setAlcadaSenhaAutorizador(String alcadaSenhaAutorizador) {
		this.alcadaSenhaAutorizador = alcadaSenhaAutorizador;
	}
	public UIAlcada getAlcadaBinding() {
		return alcadaBinding;
	}
	public void setAlcadaBinding(UIAlcada alcadaBinding) {
		this.alcadaBinding = alcadaBinding;
	}
    
}

