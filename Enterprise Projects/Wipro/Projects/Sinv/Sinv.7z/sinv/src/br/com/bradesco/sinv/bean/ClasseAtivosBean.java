package br.com.bradesco.sinv.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Managed Bean da Carteira Recomendada.
 * @author Bruno Justino - Wipro 
 */
public class ClasseAtivosBean implements Serializable{

	/**
	 * Serial version UID.
	 */
	private static final long serialVersionUID = -8661700249127157349L;
	
	/**
	 * String para representar a navega��o para a view pageClasseDeAtivos.jsp
	 */
	public static final String PAGE_CLASSE_ATIVOS = "pageClasseDeAtivos";
	
	/**
	 * Lista de ativos exibida na view
	 */
	private List<String> listaAitvos;
	
	/**
	 * Construtor default inicializando a lista de ativos
	 */
	public ClasseAtivosBean() {
		this.listaAitvos = new ArrayList<String>();
		for(int i =0; i<500; i++){
			this.listaAitvos.add("1"+i);
		}		
	}
	
	/**
	 * M�todo para realizar a navega��o para a tela pageClasseDeAtivos.jsp
	 * @return PAGE_CLASSE_ATIVOS - String - tela da classe de ativos 
	 */
	public String navegarClasseAtivos(){
		return PAGE_CLASSE_ATIVOS;
	}

	/**
	 * M�todo get da lista de ativos.
	 * @return listaAitvos - List<String> - lista de ativos exibida na view
	 */
	public List<String> getListaAitvos() {
		return this.listaAitvos;
	}

	/**
	 * M�todo set da lista de ativos
	 * @param listaAitvos - List<String> - lista de ativos exibida na view
	 */
	public void setListaAitvos(final List<String> listaAitvos) {
		this.listaAitvos = listaAitvos;
	}
	
}