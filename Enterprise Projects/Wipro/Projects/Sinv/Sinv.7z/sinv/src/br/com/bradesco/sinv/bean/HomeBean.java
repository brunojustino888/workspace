/**
 * 
 */
package br.com.bradesco.sinv.bean;

import java.io.Serializable;
import java.util.List;

import br.com.bradesco.sinv.application.ApplicationItemServiceImpl;
import br.com.bradesco.sinv.dto.ApplicationItemDTO;
import br.com.bradesco.sinv.services.ApplicationItemService;

/**
 * Managed Bean da Migra��o WAS v8.5.
 * @author Bruno Justino - Wipro 
 */
public class HomeBean implements Serializable{

	/**
	 * Serial version UID.
	 */
	private static final long serialVersionUID = -8661700249127157349L;

	/**
	 * Servi�o respons�vel pelas a��es da tela. 
	 */
	private ApplicationItemService applicationItemService;
	
	/**
	 * Lista de aplicativos mostrada em tela
	 */
	private List<ApplicationItemDTO> appList;
	
	/**
	 * Construtor default do bean. 
	 * Respons�vel por carregar a tabela de aplicativos que dever�o ser migrados posteriormente.
	 */
	public HomeBean() {
		this.applicationItemService = new ApplicationItemServiceImpl();
		this.appList = applicationItemService.listar();
		System.out.println("Size da lista de aplicativos: "+appList.size());
	}
	
	/**
	 * Utilizado para navegar para a tela de aplicativos
	 * @return home-wasmigration - String - tela de aplicativos da migra��o
	 */
	public String navegarHome(){
		return "home-wasmigration";
	}
	
	/**
	 * Respons�vel pela navega��o da tela home-wasmigration.xhtml para a edi��o de um determinado registro.
	 * @param idOfItem - Long - Pk do registro
	 * @return edit-wasmigration.xhtml - String - nome da tela 
	 */
	public String edit(Long idOfItem) {
		return "edit-wasmigration.xhtml";
	}
	
	/**
	 * M�todo get da lista de projetos mostrada em tela no datatable
	 * @return appList - List<ApplicationItemDTO> - lista de projetos.
	 */
	public List<ApplicationItemDTO> getAppList() {
		return this.appList;
	}

	/**
	 * M�todo set da lista de projetos que s�o mostrados em tela
	 * @param appList - List<ApplicationItemDTO> - lista de projetos.
	 */
	public void setAppList(final List<ApplicationItemDTO> appList) {
		this.appList = appList;
	}
	
}