/*
 * @(#)NoDataFoundException.java       1.0 20/09/2004
 *
 * Copyright (c) 2004 Bradesco S/A.
 * Osasco, SP - Brazil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bradesco S/A. ("Confidential Information").  You shall not disclose 
 * such Confidential Information and shall not use, publish, alter 
 * or otherwise make it available, directly or indirectly, without the prior 
 * written consent of Bradesco S/A.
 */

package br.com.bradesco.exception;
/**
 * Exce��es retornadas pelos Data Access Objects em caso de n�o encontrar 
 * informa��es na pesquisa ao banco de dados.
 * @author Sergio Sussumu Takahashi
 * @version 1.0
 */
public class DataNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	/** Cria uma nova inst�ncia de DataNotFoundException. */
    public DataNotFoundException() {
        super();
    }

    /**
     * Cria uma nova inst�ncia de DataNotFoundException.
     * @param msg, String contendo a mensagem que ser� apresentada
     */ 
    public DataNotFoundException( String msg ) {
        super( msg );
    }

    /**
     * Cria uma nova inst�ncia de DataNotFoundException.
     * @param e, Exception contendo o erro ocorrido
     */
    public DataNotFoundException( Exception e ) {
        super( (e == null) ? null : e.toString() );
    }
}