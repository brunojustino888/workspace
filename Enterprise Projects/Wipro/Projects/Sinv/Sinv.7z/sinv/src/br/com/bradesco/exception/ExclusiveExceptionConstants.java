package br.com.bradesco.exception;

import br.com.bradesco.web.aq.application.error.ExceptionConstants;

/**
 * Classe de constantes exclusiva para tratamento das exceptions.
 * @author Bruno Justino - brunoj - Wipro
 */
public class ExclusiveExceptionConstants extends ExceptionConstants  {

    /**
     * Indica a instru��o ou fase do servi�o na qual � realizada a comunica��o
     * com ISD.
     */
    public static final String INSTRUCAO_COMUNICACAO_ISD = "02";
  
    /**
     * Indica a instru��o ou fase de servi�o na qual realiza-se a obten��o
     * de uma determinada configura��o.
     */
    public static final String INSTRUCAO_OBTENCAO_CONFIGURACAO = "16";

    /**
     * Indica a instru��o ou fase de servi�o na qual realiza-se a obten��o
     * da conta relacionada ao usu�rio.
     */
    public static final String INSTRUCAO_OBTENCAO_CONTA_ENTITY = "09";

    /**
     * Indica a instru��o ou fase de servi�o na qual realiza-se a obten��o
     * dos dados de sess�o de usu�rio.
     */
    public static final String INSTRUCAO_OBTENCAO_DADOS_SESSAO = "12";

    /**
     * Indica a instru��o ou fase de servi�o na qual realiza-se obten��o
     * da midia.
     */
    public static final String INSTRUCAO_OBTENCAO_MIDIA_ENTITY = "08";

    /**
     * Indica a instru��o ou fase de servi�o na qual � realizada a comprova��o
     * do resultado do acesso ao banco de dados.
     */
    public static final String INSTRUCAO_RETORNO_BANCO_DADOS = "03";

    /**
     * Indica a instru��o ou fase de servi�o na qual � realizada a comprova��o
     * do retorno de ISD.
     */
    public static final String INSTRUCAO_RETORNO_ISD = "04"; 

    /**
     * Indica a instru��o ou fase de servi�o na que realiza-se o parseado
     * a mensagem de retorno de uma determinada transa��o.
     */
    public static final String INSTRUCAO_RETORNO_MESSAGE_PARSER = "05";

    /**
     * Indica a instru��o ou fase de servi�o na que realizam-se v�rias valida��es
     * sobre os dados de entrada.
     */
    public static final String INSTRUCAO_VALIDACAO_DADOS_ENTRADA = "07";

    /**
     * Indica a instru��o ou fase de servi�o na qual � realizada a valida��o
     * da senha de usu�rio.
     */
    public static final String INSTRUCAO_VALIDACAO_SENHA = "13";

    /**
     * Indica a instru��o ou fase de servi�o na qual � realizada a valida��o
     * se o usu�rio tem um perfil de acesso adequado para a execu��o de uma
     * determinada a��o.
     */
    public static final String INSTRUCAO_VALIDACAO_PERFIL_ACESSO = "06";
    
    /**
     * Indica o tipo de erro ocorrido. Se for funcional ser� negocio, qualquer outro
     * erro ser� t�cnico.
     */
    public static final String FLAG_ERRO = "1";

    /**
     * Indica o tipo de erro ocorrido. Se for funcional ser� negocio, qualquer outro
     * erro ser� t�cnico.
     */
    public static final String FLAG_SUCESSO = "0";
    
    /**
     * Indica erro gen�rico no site.
     */    
    public static final String GENERAL_ERROR = "error.view.default";
    
    /**
     * Condicoes fora do padr�o do convenio.
     */    
    public static final String CONDICOES_FORA_PADRAO_CONVENIO = "error.service.data.condicoesForaPadraoConvenio";
    
    /**
     * Valor insuficiente de margem.
     */    
    public static final String VALOR_MARGEM_INSUFICIENTE = "error.service.econsig.margeminsuficiente";
    
    /**
     * Falta de senha do servidor.
     */
    public static final String SENHA_SERVIDOR_OBRIGATORIO_INCORRETA = "error.service.econsig.senhaIncorreta";
    
    /**
     * Falta de senha do servidor.
     */
    public static final String CONTA_SEM_CHEQUE_ESPECIAL = "error.service.chequeEspecial.clienteSemLimite";
    
    /**
     * N�o existem comprovantes com pagamento agendado.
     */
    public static final String NAO_EXISTE_COMPROVANTE_PAG_ANTECIPADO = 
            "error.service.data.pdc.functional.shopcredit.pagamento.listaPagamentos.100.cancelamento";
    
    /**
	 * Prefiro que tenham os codigos de error da capa do DAO
	 */
	public static final String PREFIX_EXCEPTION_CODE = "error.sevice.data.dao.sinv.";

	// CODIGOS ERROR RELACIONADOS COM O DATAACCESSEXCEPTION

	/**
	 * Agencia e conta Inexistentes.
	 */
	public static final String AGENCIA_CONTA_INEXISTENTES = PREFIX_EXCEPTION_CODE
			+ "agenciaContaInexistentes";

	/**
	 * Codigo de exce��o lan�ado quando el resultado de la llamada a un store
	 * procedure es una lista vacia
	 */
	public static final String LST_NULL_RESULT_EXCEPTION = PREFIX_EXCEPTION_CODE
			+ "lstResultNullException";

	/**
	 * Codigo de exce�ao lan�ado quando el resultado de la llamada a un store
	 * procedure de tipo insert update es erroneo
	 */
	public static final String NOT_SUCCESS_INSERT_UPDATE_EXCEPTION = PREFIX_EXCEPTION_CODE
			+ "notSuccessInsertUpdateException";

	/**
	 * Codigo de exce�ao lan�ado quando intentamos insertar una columna
	 */
	public static final String COLUMN_NOT_NULLABLE_EXCEPTION = PREFIX_EXCEPTION_CODE
			+ "columnNotNullableException";

	/**
	 * Codigo de exce�ao lan�ado quando tenta criar uma sess�o que j� existe
	 * para outro usu�rio
	 */
	public static final String SESSAO_JA_EXISTE_OUTRO_EXCEPTION = PREFIX_EXCEPTION_CODE
			+ "sessionErrorException";

	/**
	 * Codigo de exce�ao lan�ado quando tenta criar ag�ncia e conta virtual
	 */
	public static final String ERRO_CRIA_CV_EXCEPTION = PREFIX_EXCEPTION_CODE
			+ "criaCVException";

	/**
	 * Codigo de exce��o lan�ado quando um metodo foi chamado com um tempo
	 * ilegal ou inapropiado.(o estado da JVM N�o � o apropiado)
	 */
	public static final String ILLEGAL_STATE_EXCEPTION = PREFIX_EXCEPTION_CODE
			+ "illegalStateException";

	/**
	 * Codigo de exce��o lan�ado quando uma lista est� vazia
	 */
	public static final String LIST_EMPTY_EXCEPTION = PREFIX_EXCEPTION_CODE
			+ "listEmptyException";

	/**
	 * Codigo de exce��o lan�ado quando o error no processo do metodo do dao �
	 * generico: null pointer, illegalstate, arrayIndexbound,...
	 */
	public static final String DEFAULT_EXCEPTION = PREFIX_EXCEPTION_CODE
			+ "default";
    
}