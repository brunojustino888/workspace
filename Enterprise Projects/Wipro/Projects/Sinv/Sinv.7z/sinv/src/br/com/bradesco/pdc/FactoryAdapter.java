package br.com.bradesco.pdc;


/**
 * 
 * <p>
 * <b>T�tulo:</b> Arquitetura Bradesco Canal Internet.
 * </p>
 * <p>
 * <b>Descri��o:</b>
 * </p>
 * <p>
 * F�brica para criar os adaptadores definidos no sistema.
 * </p>
 * 
 * @author GFT Iberia Solutions / Emagine <BR/> copyright Copyright (c) 2006
 *         <BR/> created <BR/>
 * @version 1.0
 *
 * Esta classe foi automaticamente gerada com 
 * <a href="http://www.bradesco.com.br">Generador de Adaptadores</a>
 */
 
public class FactoryAdapter {

    /**
     * Vari�vel que cont�m uma inst�ncia do adaptador AuthenticationService.
     */
    private IAuthenticationServicePDCAdapter pdcAuthenticationService;
       
    /**
     * M�todo invocado para obter um adaptador AuthenticationService.
     * 
     * @return Adaptador AuthenticationService
     */
    public IAuthenticationServicePDCAdapter getAuthenticationServicePDCAdapter() {
        return pdcAuthenticationService;
    }

    /**
     * M�todo invocado para establecer um adaptador AuthenticationService.
     * 
     * @param pdcAuthenticationService
     *            Adaptador AuthenticationService
     */
    public void setAuthenticationServicePDCAdapter(IAuthenticationServicePDCAdapter pdcAuthenticationService) {
        this.pdcAuthenticationService = pdcAuthenticationService;
    }
   
    /**
     * Construtor.
     * 
     */
    private FactoryAdapter() {

    };

    /**
     * M�todo utilizado para obter uma inst�ncia da F�brica.
     * 
     * @return Objeto FactoryAdapter (a f�brica de adaptadores).
     */
    public static FactoryAdapter getInstance() {
        return new FactoryAdapter();
    }

}
