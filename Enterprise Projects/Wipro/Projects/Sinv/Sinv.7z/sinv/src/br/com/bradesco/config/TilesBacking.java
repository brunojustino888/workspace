package br.com.bradesco.config;

public class TilesBacking {
    
	private String testProperty;
	
    public String pressMe() {
		return ("nav_page4");
	}

	@SuppressWarnings("unused")
	public String getTestProperty() {	
		if(true) throw new NullPointerException("testeando excepciones en la fase de render");	
		return testProperty;
	}

	public void setTestProperty(String testProperty) {
		this.testProperty = testProperty;
	}  
    
}
