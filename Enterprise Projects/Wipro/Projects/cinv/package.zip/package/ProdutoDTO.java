package cinv.servlet.ivli;
 
import java.io.Serializable;

/**
 * Classe responsável por representar os DataTableObject's da tela de consultaProdutos
 * Origem 19/07/2018
 * @author brunoj - Bruno Justino - Wipro
 */
public class ProdutoDTO implements Serializable {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Representa o codigo do produto
	 */
	private String codigo;
	
	/**
	 * Representa o nome do produto
	 */
	private String produto;
	
	/**
	 * Representa o saldo total do produto
	 */
	private String saldoTotal;

	/**
	 * Método get do atributo codigo
	 * @return codigo - String - codigo do produto
	 */
	public String getCodigo() {
		return this.codigo;
	}

	/**
	 * Método set do atributo codigo
	 * @param codigo - String - codigo do produto
	 */
	public void setCodigo(final String codigo) {
		this.codigo = codigo;
	}

	/**
	 * Método get do atributo produto
	 * @return produto - String - nome do produto
	 */
	public String getProduto() {
		return this.produto;
	}

	/**
	 * Método set do atributo produto
	 * @param produto - String - nome do produto
	 */
	public void setProduto(final String produto) {
		this.produto = produto;
	}

	/**
	 * Método get do atributo saldoTotal
	 * @return saldoTotal - String - saldo total do produto
	 */
	public String getSaldoTotal() {
		return this.saldoTotal;
	}

	/**
	 * Método get do atributo saldoTotal
	 * @param saldoTotal - String - saldo total do produto
	 */
	public void setSaldoTotal(final String saldoTotal) {
		this.saldoTotal = saldoTotal;
	}
	
}