package cinv.servlet.ivli;

import java.io.IOException;
 
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Classe respons�vel por apresentar os DataTableObject's da tela de
 * consultaProdutos Origem 19/07/2018
 * @author brunoj - Bruno Justino - Wipro
 */
public class ConsultaProdutosDetalheServlet extends HttpServlet {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 1L;
 
	/**
	 * doGet()
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.process(request, response);
	}
	
	/**
	 * doPost()
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.process(request, response);
	}

	/**
	 * Métoodo responsável por processar a requisição
	 * @param request - HttpServletRequest - requisição http
	 * @param response - HttpServletResponse - resposta http
	 * @throws ServletException - erro de servlet
	 * @throws IOException - erro em recurso
	 */
	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			HttpSession sessao = request.getSession(true);
			if(sessao.getAttribute("viewObject")!=null) { 
				if(request.getParameter("codDet")!=null) {
					sessao.setAttribute("codDet", request.getParameter("codDet"));
//					CinvUtil.verificaUsuario(session, request, response);
					this.getServletContext().getRequestDispatcher("/jsp/AtendimentoInvestidorConsultas/ControleInformInvestimentos/ivli/consultaProdutosDetalhe.jsp?codOp=1").forward(request, response);
				}
			}
			
			if(request.getParameter("codOp")!=null) {
				sessao.setAttribute("codOp", request.getParameter("codOp"));
//				CinvUtil.verificaUsuario(session, request, response);
				this.getServletContext().getRequestDispatcher("/jsp/AtendimentoInvestidorConsultas/ControleInformInvestimentos/ivli/consultaProdutosDetalhe.jsp?codOp=1").forward(request, response);
			}
		} catch (Exception e) {
			request.setAttribute("msgErro01", "N�o foram encontrados produtos de investimentos para esta conta.");
			request.setAttribute("Classe", getClass().toString());
			request.setAttribute("Erro", e);
			this.getServletContext().getRequestDispatcher("/servlet/TrataErro").forward(request, response);
			e.printStackTrace();
		}
	}

}
