package cinv.servlet.ivli;

import java.io.Serializable;
 
/**
 * Classe respons�vel por representar o view object da tela produtosConsultados.jsp
 * Origem em 20/07/2018
 * @author brunoj - Bruno Justino - Wipro
 */
public class DadosCorrentistaVO implements Serializable{

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Representa a ag�ncia mostrada em tela
	 */
	private String agencia;
	
	/**
	 * Representa a ag�ncia mostrada em tela
	 */
	private String numAgencia;
	
	/**
	 * Representa a conta mostrada em tela
	 */
	private String conta;
	
	/**
	 * Representa a raz�o mostrada em tela
	 */
	private String razao;
	
	/**
	 * Representa o cpf cnpj mostrado em tela
	 */
	private String cpfCnpj;
	
	/**
	 * Representa o correntista cnpj mostrado em tela
	 */
	private String correntista;
	
	/**
	 * Representa o perfil do investidor cnpj mostrado em tela
	 */
	private String perfilInvestidor;
	
	/**
	 * Representa se a tela dever� buscar todos os produtos disponíveis
	 */
	private boolean checkTodosOn;

	/**
	 * Método get do atributo agencia
	 * @return agencia - String - representa a agencia
	 */
	public String getAgencia() {
		return this.agencia;
	}

	/**
	 * Método set do atributo agencia
	 * @param agencia - String - representa a agencia
	 */
	public void setAgencia(final String agencia) {
		this.agencia = agencia;
	}

	/**
	 * Método get do atributo conta
	 * @return agencia - String - representa a conta
	 */
	public String getConta() {
		return this.conta;
	}

	/**
	 * Método set do atributo conta
	 * @param conta - String - representa a conta
	 */
	public void setConta(final String conta) {
		this.conta = conta;
	}

	/**
	 * Representa se o checkbox foi marcado
	 * @return checkTodosOn - boolean - caso true trará todos os produtos de uma determinado correntista
	 */
	public boolean isCheckTodosOn() {
		return this.checkTodosOn;
	}

	/**
	 * Representa se o checkbox foi marcado
	 * @param checkTodosOn - boolean - caso true trará todos os produtos de uma determinado correntista
	 */
	public void setCheckTodosOn(final boolean checkTodosOn) {
		this.checkTodosOn = checkTodosOn;
	}

	/**
	 * Representa o cpf ou Cnpj do correntista
	 * @return cpfCnpj - String - documento do correntista
	 */
	public String getCpfCnpj() {
		return this.cpfCnpj;
	}

	/**
	 * Representa o cpf ou Cnpj do correntista
	 * @param cpfCnpj - String - documento do correntista
	 */
	public void setCpfCnpj(final String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	/**
	 * Representa o nome do correntista
	 * @return correntista - String - nome do correntista
	 */
	public String getCorrentista() {
		return this.correntista;
	}

	/**
	 * Representa o nome do correntista
	 * @param correntista - String - nome do correntista
	 */
	public void setCorrentista(String correntista) {
		this.correntista = correntista;
	}

	/**
	 * Representa o perfil do investidor
	 * @return perfilInvestidor - String - perfil do investidor
	 */
	public String getPerfilInvestidor() {
		return this.perfilInvestidor;
	}

	/**
	 * Representa o perfil do investidor
	 * @param perfilInvestidor - String - perfil do investidor
	 */
	public void setPerfilInvestidor(final String perfilInvestidor) {
		this.perfilInvestidor = perfilInvestidor;
	}

	/**
	 * Representa o numero da ag�ncia
	 * @return numAgencia - String - n�mero da ag�ncia
	 */
	public String getNumAgencia() {
		return this.numAgencia;
	}

	/**
	 * Representa o numero da ag�ncia
	 * @param numAgencia - String - n�mero da ag�ncia
	 */
	public void setNumAgencia(final String numAgencia) {
		this.numAgencia = numAgencia;
	}

	/**
	 * Representa a raz�o mostrada na tela 
	 * @return razao - String - razao
	 */
	public String getRazao() {
		return this.razao;
	}

	/**
	 * Representa a raz�o mostrada na tela 
	 * @param razao - String - razao
	 */
	public void setRazao(final String razao) {
		this.razao = razao;
	}
	
}