package cinv.servlet.ivli;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import javax.servlet.ServletException; 
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Classe respons�vel por apresentar os DataTableObject's da tela de
 * consultaProdutos Origem 19/07/2018
 * @author brunoj - Bruno Justino - Wipro
 */
public class ConsultaProdutosServlet extends HttpServlet {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 1L;
 
	/**
	 * doPost()
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.process(request, response);
	}

	/**
	 * doget()
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.process(request, response);
	}

	/**
	 * Métoodo respons�vel por processar a requisi��o
	 * @param request - HttpServletRequest - requisi��o http
	 * @param response - HttpServletResponse - resposta http
	 * @throws ServletException - erro de servlet
	 * @throws IOException - erro em recurso
	 */
	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			HttpSession sessao = request.getSession(true);
			sessao.setAttribute("dataAtual", new SimpleDateFormat("dd/MM/yyyy").format(new Date()));
//			CinvUtil.verificaUsuario(sessao, request, response);
			boolean isCheckedAll = false;
			if(request.getParameter("txtCheckAll")!=null) {
				isCheckedAll = true; 
			}
			GerenciamentoTransacaoMock mock = new GerenciamentoTransacaoMock(request.getParameter("txtAgencia"),request.getParameter("txtConta"),isCheckedAll);
			Vector<ProdutoDTO> produtosVector = mock.executarTransacaoConsultaProdutos();
			DadosCorrentistaVO correntistaVO = mock.getDadosVO();
			if(request.getParameter("txtFilter")!=null) {
				String pesquisa = request.getParameter("txtFilter");
				Vector<ProdutoDTO> produtosVectorAux = new Vector<ProdutoDTO>();
				for (int i =0; i< produtosVector.size();i++) {
					if(produtosVector.get(i).getProduto().contains(pesquisa)) {
						produtosVectorAux.add(produtosVector.get(i));
					}
				}
				produtosVector = produtosVectorAux;
			}
			sessao.setAttribute("viewObject", correntistaVO);
			sessao.setAttribute("totalRegistro", String.valueOf(produtosVector.size()));
			sessao.setAttribute("produtosVector", produtosVector);
			sessao.setAttribute("isCheckedAll", isCheckedAll);
			this.getServletContext().getRequestDispatcher("/jsp/AtendimentoInvestidorConsultas/ControleInformInvestimentos/ivli/consultaProdutos.jsp").forward(request, response);
		} catch (Exception e) {
			request.setAttribute("msgErro01", "N�o foram encontrados produtos de investimentos para esta conta.");
			request.setAttribute("Classe", getClass().toString());
			request.setAttribute("Erro", e);
			this.getServletContext().getRequestDispatcher("/servlet/TrataErro").forward(request, response);
			e.printStackTrace();
		}
	}

}