package cinv.servlet.ivli;
import java.io.Serializable;
import java.util.Vector;

/**
 * Classe respons�vel por mock da transa��o para a tela de consultaProdutos
 * Origem 19/07/2018
 * @author brunoj - Bruno Justino - Wipro
 */
public class GerenciamentoTransacaoMock implements Serializable{

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Representa a ag�ncia banc�ria
	 */
	private String agencia;
	
	/**
	 * Representa a conta-corrente
	 */
	private String conta;
	
	/**
	 * Representa se dever�o trazer todos os produtos
	 */
	private boolean isCheckAll;
	
	/**
	 * Construtor apenas recebe a sess�o da aplica��o
	 * @param session
	 */
	public GerenciamentoTransacaoMock(String agencia, String conta, boolean isCheckAll) {
		this.agencia = agencia;
		this.conta = conta;
		this.isCheckAll = isCheckAll;
	}

	/**
	 * Respons�vel por carregar a lista de produtos.
	 * @return produtosVector - Vector<ProdutoDTO> - lista de produtos
	 */
	public Vector<ProdutoDTO> executarTransacaoConsultaProdutos() {
		System.out.println("\nAg�ncia:"+agencia+" - - - Conta:"+conta+" - - - Check Todos: "+isCheckAll);
		Vector<ProdutoDTO> produtosVector = new Vector<ProdutoDTO>();
		if(agencia.equals("8888")&&conta.equals("8888888")) {
			for (int i =0; i<88;i++) {
				ProdutoDTO product = new ProdutoDTO();
				product.setCodigo(String.valueOf(i));
				product.setProduto("Produto mock de execu��o");
				product.setSaldoTotal(String.valueOf(i+i*128.5));
				if(isCheckAll) {
					produtosVector.add(product);
				}else {
					double doubleValue = 0.01;
					if(!(Double.parseDouble(product.getSaldoTotal())<doubleValue)){
						produtosVector.add(product);
					}
				}
			}
			ProdutoDTO product = new ProdutoDTO();
			product.setCodigo(String.valueOf("8888"));
			product.setProduto("Produto mock para teste espec�fico da filtragem");
			product.setSaldoTotal(String.valueOf(28.8));
			produtosVector.add(product);
		}
		return produtosVector;
	}

	/**
	 * Respons�vel por retornar um view objeto para preencher os campos na tela
	 * @return viewObject - DadosCorrentistaVO - representa os dados mostrados nos campos na tela
	 */
	public DadosCorrentistaVO getDadosVO() {
		DadosCorrentistaVO viewObject = new DadosCorrentistaVO();
		viewObject.setAgencia(this.agencia);
		viewObject.setCheckTodosOn(this.isCheckAll);
		viewObject.setConta(this.conta);
		viewObject.setCorrentista("En�as Ferreira Carneiro");
		viewObject.setCpfCnpj("126.043.057-04");
		return viewObject;
	}
	
}